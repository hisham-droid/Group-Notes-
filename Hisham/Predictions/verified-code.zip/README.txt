app/src   : the practice-hackathon base + every predicted feature (122 Java files)
app/test  : Task 5 test classes (white-box + black-box) for reports, reactions, votes, follow
verify/   : the extra verification tests used to check every prediction

Compile and run (from this folder, with junit-4.13.2.jar and hamcrest-core-1.3.jar next to it):
  javac -d out $(find app/src -name '*.java')
  javac -cp out:junit-4.13.2.jar:hamcrest-core-1.3.jar -d tout app/test/*.java $(find verify -name '*.java')
  java -cp tout:out:junit-4.13.2.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore ModerationToolsAddReportTests ModerationToolsGetReportsTests FeaturesVerify ExtrasVerify MoreExtrasVerify AllPersistenceVerify
(On Windows use ; instead of : in -cp.)
