package edits;

/**
 * One previous version of a message.
 * @param text     the text BEFORE the edit
 * @param editedAt when it was replaced
 */
public record Edit(String text, long editedAt) {}
