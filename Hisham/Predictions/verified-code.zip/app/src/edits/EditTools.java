package edits;

import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: editing messages with history (MEMENTO pattern: each Edit is a
 * saved snapshot of the old state).
 * Message is an immutable record, so an edit builds a NEW record with the same id, poster,
 * thread and timestamp (so it keeps its place in the tree) and swaps it in via Post.replaceMessage.
 */
public final class EditTools {
	private static final Map<UUID, List<Edit>> history = new HashMap<>();

	private EditTools() {}

	/**
	 * Only the author may edit.
	 * @return false if ids missing, not the author, new text null, or the text is unchanged
	 */
	public static boolean editMessage(UUID message, UUID user, String newText, long timestamp) {
		Message current = MessageIndex.getInstance().get(message);
		if (current == null || newText == null || UserDAO.getInstance().getByUUID(user) == null) return false;
		if (!user.equals(current.poster()) || newText.equals(current.message())) return false;

		Message edited = new Message(current.id(), current.poster(), current.thread(), current.timestamp(), newText);
		Post post = MessageIndex.getInstance().getPostOf(current);
		post.replaceMessage(current, edited);
		history.computeIfAbsent(message, k -> new ArrayList<>()).add(new Edit(current.message(), timestamp));
		return true;
	}

	/** @return previous versions, oldest first (empty if never edited) */
	public static List<Edit> getHistory(UUID message) {
		return Collections.unmodifiableList(history.getOrDefault(message, List.of()));
	}

	public static int getEditCount(UUID message) {
		return history.getOrDefault(message, List.of()).size();
	}

	public static boolean isEdited(UUID message) {
		return getEditCount(message) > 0;
	}

	/** Undo the last edit (back to the previous text). Author only. */
	public static boolean undoLastEdit(UUID message, UUID user) {
		List<Edit> edits = history.get(message);
		Message current = MessageIndex.getInstance().get(message);
		if (edits == null || edits.isEmpty() || current == null || !user.equals(current.poster())) return false;
		Edit last = edits.remove(edits.size() - 1);
		Message restored = new Message(current.id(), current.poster(), current.thread(), current.timestamp(), last.text());
		MessageIndex.getInstance().getPostOf(current).replaceMessage(current, restored);
		if (edits.isEmpty()) history.remove(message);
		return true;
	}

	/** persistence: message -> previous versions */
	public static Map<UUID, List<Edit>> all() {
		return Collections.unmodifiableMap(history);
	}

	public static void restore(UUID message, Edit edit) {
		history.computeIfAbsent(message, k -> new ArrayList<>()).add(edit);
	}

	public static void clear() {
		history.clear();
	}
}
