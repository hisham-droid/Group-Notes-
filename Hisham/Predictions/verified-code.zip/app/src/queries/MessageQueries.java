package queries;

import dao.MessageComparator;
import dao.MessageIndex;
import dao.PostDAO;
import dao.model.Message;
import dao.model.Post;
import sorteddata.SortedData;
import sorteddata.SortedDataRanges;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * PREDICTED Task 2 queries on a post's messages: by time range, position, pages.
 * <p>
 * Trick: MessageComparator orders by timestamp first and (after our null-safe fix) puts null
 * fields first, so new Message(null, null, null, t, null) is a "probe" that sorts BEFORE every
 * real message with timestamp t. That lets us search by time with the normal tree methods.
 */
public final class MessageQueries {
	private MessageQueries() {}

	/** A fake message that sorts before every real message with this timestamp. */
	static Message probe(long timestamp) {
		return new Message(null, null, null, timestamp, null);
	}

	// probe just after every message with timestamp t (null = no upper bound)
	private static Message probeAfter(long timestamp) {
		return timestamp == Long.MAX_VALUE ? null : probe(timestamp + 1);
	}

	/** Messages of a post with from <= timestamp <= to (inclusive), oldest first. */
	public static Iterator<Message> getMessagesBetween(UUID post, long from, long to, boolean isAdmin) {
		Post target = PostDAO.getInstance().get(new Post(post));
		if (target == null || from > to) return new ArrayList<Message>().iterator();
		return SortedDataRanges.range(target.getVisibleMessages(isAdmin), probe(from), probeAfter(to), MessageComparator.getInstance());
	}

	/** How many messages have from <= timestamp <= to, in O(log n). */
	public static int countMessagesBetween(UUID post, long from, long to, boolean isAdmin) {
		Post target = PostDAO.getInstance().get(new Post(post));
		if (target == null || from > to) return 0;
		return SortedDataRanges.count(target.getVisibleMessages(isAdmin), probe(from), probeAfter(to));
	}

	/** @return 0-based position of the message in its post (oldest = 0), or -1 if unknown. O(log n). */
	public static int getPosition(UUID message) {
		Message target = MessageIndex.getInstance().get(message);
		if (target == null) return -1;
		return MessageIndex.getInstance().getPostOf(target).messages.rank(target);
	}

	/**
	 * Pagination: page `page` (0-based) of `pageSize` messages, oldest first.
	 * Uses getAtIndex (O(log n) each) so earlier pages are never walked.
	 */
	public static List<Message> getPage(UUID post, int page, int pageSize, boolean isAdmin) {
		if (page < 0 || pageSize <= 0) throw new IllegalArgumentException("page must be >= 0 and pageSize > 0");
		List<Message> result = new ArrayList<>();
		Post target = PostDAO.getInstance().get(new Post(post));
		if (target == null) return result;
		SortedData<Message> source = target.getVisibleMessages(isAdmin);
		int start = page * pageSize;
		for (int i = start; i < Math.min(start + pageSize, source.size()); i++) result.add(source.getAtIndex(i));
		return result;
	}
}
