package audit;

import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED theme: audit log + undo for admin actions (COMMAND pattern).
 * Each admin has a stack of executed commands (undo pops the last one).
 * Every successful action and undo is appended to an append-only audit log.
 */
public final class AdminActions {
	private static final Map<UUID, Deque<AdminCommand>> history = new HashMap<>();
	private static final List<AuditEntry> log = new ArrayList<>();

	private AdminActions() {}

	/** @return false if not an admin or the command failed (nothing is logged) */
	public static boolean run(UUID admin, AdminCommand command, long timestamp) {
		User a = UserDAO.getInstance().getByUUID(admin);
		if (a == null || a.role() != User.Role.Admin || !command.execute()) return false;
		history.computeIfAbsent(admin, k -> new ArrayDeque<>()).push(command);
		log.add(new AuditEntry(admin, command.describe(), timestamp));
		return true;
	}

	/** Undo this admin's most recent action. @return false if there is nothing to undo */
	public static boolean undo(UUID admin, long timestamp) {
		Deque<AdminCommand> stack = history.get(admin);
		if (stack == null || stack.isEmpty()) return false;
		AdminCommand command = stack.pop();
		command.undo();
		log.add(new AuditEntry(admin, "UNDO " + command.describe(), timestamp));
		return true;
	}

	/** @return the whole log, oldest first (read-only) */
	public static List<AuditEntry> getLog() {
		return Collections.unmodifiableList(log);
	}

	/** persistence: the log is saved; undo stacks are not (undo only works within one run) */
	public static void restoreLog(AuditEntry entry) {
		log.add(entry);
	}

	public static void clear() {
		history.clear();
		log.clear();
	}

	// ----------------------------------------------------- concrete commands

	/** Hide (or unhide) a message, remembering the previous state for undo. */
	public static AdminCommand hide(UUID messageId, boolean hidden) {
		return new AdminCommand() {
			private Message message;
			private boolean previous;

			public boolean execute() {
				message = MessageIndex.getInstance().get(messageId);
				if (message == null) return false;
				Post post = MessageIndex.getInstance().getPostOf(message);
				previous = post.isHidden(messageId);
				post.setHidden(message, hidden);
				return true;
			}

			public void undo() {
				MessageIndex.getInstance().getPostOf(message).setHidden(message, previous);
			}

			public String describe() {
				return (hidden ? "HIDE " : "UNHIDE ") + messageId;
			}
		};
	}

	/** Lock (or unlock) a post. */
	public static AdminCommand lock(UUID postId, boolean locked) {
		return new AdminCommand() {
			private Post post;
			private boolean previous;

			public boolean execute() {
				post = PostDAO.getInstance().get(new Post(postId));
				if (post == null) return false;
				previous = post.isLocked();
				post.setLocked(locked);
				return true;
			}

			public void undo() {
				post.setLocked(previous);
			}

			public String describe() {
				return (locked ? "LOCK " : "UNLOCK ") + postId;
			}
		};
	}
}
