package audit;

/** COMMAND pattern: an admin action that can be undone. */
public interface AdminCommand {
	/** @return false if the action could not be done (nothing changes) */
	boolean execute();

	/** reverses a successful execute() */
	void undo();

	/** human-readable, for the audit log */
	String describe();
}
