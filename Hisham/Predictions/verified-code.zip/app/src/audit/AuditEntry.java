package audit;

import java.util.UUID;

/** One line of the audit log: who did what, when. */
public record AuditEntry(UUID admin, String action, long timestamp) {}
