package relations;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * HACKATHON (generic Task 1 building block): a many-to-many relation "A -> B",
 * stored in BOTH directions so every question is O(1):
 *   follows (user -> user), blocks (user -> user), bookmarks (user -> post),
 *   subscriptions (user -> post), mutes, friend requests, tags (post -> tag) ...
 * @param <A> source type (usually a UUID)
 * @param <B> target type
 */
public class RelationStore<A, B> {
	private final Map<A, Set<B>> forward = new HashMap<>();
	private final Map<B, Set<A>> backward = new HashMap<>();

	/** @return false if the pair already existed */
	public boolean add(A source, B target) {
		if (!forward.computeIfAbsent(source, k -> new HashSet<>()).add(target)) return false;
		backward.computeIfAbsent(target, k -> new HashSet<>()).add(source);
		return true;
	}

	/** @return false if the pair did not exist */
	public boolean remove(A source, B target) {
		Set<B> targets = forward.get(source);
		if (targets == null || !targets.remove(target)) return false;
		if (targets.isEmpty()) forward.remove(source);
		Set<A> sources = backward.get(target);
		sources.remove(source);
		if (sources.isEmpty()) backward.remove(target);
		return true;
	}

	public boolean contains(A source, B target) {
		Set<B> targets = forward.get(source);
		return targets != null && targets.contains(target);
	}

	/** e.g. "who does this user follow" */
	public Set<B> targetsOf(A source) {
		return Collections.unmodifiableSet(forward.getOrDefault(source, Collections.emptySet()));
	}

	/** e.g. "who follows this user" */
	public Set<A> sourcesOf(B target) {
		return Collections.unmodifiableSet(backward.getOrDefault(target, Collections.emptySet()));
	}

	public int countTargets(A source) {
		return forward.getOrDefault(source, Collections.emptySet()).size();
	}

	public int countSources(B target) {
		return backward.getOrDefault(target, Collections.emptySet()).size();
	}

	/** Removes every pair whose SOURCE is this value. @return how many were removed */
	public int removeSource(A source) {
		Set<B> targets = forward.get(source);
		if (targets == null) return 0;
		int removed = 0;
		for (B target : Set.copyOf(targets)) if (remove(source, target)) removed++;
		return removed;
	}

	/** Removes every pair whose TARGET is this value. @return how many were removed */
	public int removeTarget(B target) {
		Set<A> sources = backward.get(target);
		if (sources == null) return 0;
		int removed = 0;
		for (A source : Set.copyOf(sources)) if (remove(source, target)) removed++;
		return removed;
	}

	/** @return every source that has at least one target (read-only), for persistence */
	public Set<A> sources() {
		return Collections.unmodifiableSet(forward.keySet());
	}

	public void clear() {
		forward.clear();
		backward.clear();
	}
}
