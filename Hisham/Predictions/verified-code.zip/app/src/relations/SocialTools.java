package relations;

import dao.MessageComparator;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import sorteddata.SortedData;
import sorteddata.SortedDataViews;

import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED hackathon facades built on RelationStore: follow, block, bookmark.
 * Every check is O(1); the "visible to viewer" view reuses SortedDataViews.filter.
 */
public class SocialTools {
	private static final RelationStore<UUID, UUID> follows = new RelationStore<>();   // user -> user
	private static final RelationStore<UUID, UUID> blocks = new RelationStore<>();    // user -> user
	private static final RelationStore<UUID, UUID> bookmarks = new RelationStore<>(); // user -> post
	private static final RelationStore<UUID, UUID> postLikes = new RelationStore<>(); // user -> post

	private SocialTools() {}

	// ---------------- follow ----------------
	/** @return false if either user is missing, self-follow, or already following */
	public static boolean follow(UUID follower, UUID followee) {
		if (!usersExist(follower, followee) || follower.equals(followee)) return false;
		return follows.add(follower, followee);
	}
	public static boolean unfollow(UUID follower, UUID followee) { return follows.remove(follower, followee); }
	public static boolean isFollowing(UUID follower, UUID followee) { return follows.contains(follower, followee); }
	public static Set<UUID> getFollowers(UUID user) { return follows.sourcesOf(user); }
	public static int followerCount(UUID user) { return follows.countSources(user); }

	// ---------------- block ----------------
	public static boolean block(UUID blocker, UUID blocked) {
		if (!usersExist(blocker, blocked) || blocker.equals(blocked)) return false;
		return blocks.add(blocker, blocked);
	}
	public static boolean unblock(UUID blocker, UUID blocked) { return blocks.remove(blocker, blocked); }
	public static boolean isBlocked(UUID blocker, UUID blocked) { return blocks.contains(blocker, blocked); }

	/** Messages on a post that `viewer` should see (authors they blocked are filtered out). */
	public static SortedData<Message> getMessagesFor(Post post, UUID viewer) {
		return SortedDataViews.filter(post.messages, MessageComparator.getInstance(),
				m -> m.poster() == null || !blocks.contains(viewer, m.poster()));
	}

	// ---------------- bookmark ----------------
	public static boolean bookmark(UUID user, UUID post) {
		if (UserDAO.getInstance().getByUUID(user) == null || PostDAO.getInstance().get(new Post(post)) == null) return false;
		return bookmarks.add(user, post);
	}
	public static boolean unbookmark(UUID user, UUID post) { return bookmarks.remove(user, post); }
	public static boolean isBookmarked(UUID user, UUID post) { return bookmarks.contains(user, post); }
	public static Set<UUID> getBookmarks(UUID user) { return bookmarks.targetsOf(user); }

	// ---------------- likes on posts ----------------
	/** @return false if user/post missing or already liked */
	public static boolean likePost(UUID user, UUID post) {
		if (UserDAO.getInstance().getByUUID(user) == null || PostDAO.getInstance().get(new Post(post)) == null) return false;
		return postLikes.add(user, post);
	}
	public static boolean unlikePost(UUID user, UUID post) { return postLikes.remove(user, post); }
	public static boolean hasLikedPost(UUID user, UUID post) { return postLikes.contains(user, post); }
	public static int getPostLikeCount(UUID post) { return postLikes.countSources(post); }

	// ---------------- account deletion + persistence access ----------------
	/** Removes the user from every relation, on both sides. */
	public static void forgetUser(UUID user) {
		follows.removeSource(user); follows.removeTarget(user);
		blocks.removeSource(user); blocks.removeTarget(user);
		bookmarks.removeSource(user);
		postLikes.removeSource(user);
	}

	/** The raw stores, so the persistence layer can save/load them. */
	public static RelationStore<UUID, UUID> follows() { return follows; }
	public static RelationStore<UUID, UUID> blocks() { return blocks; }
	public static RelationStore<UUID, UUID> bookmarks() { return bookmarks; }
	public static RelationStore<UUID, UUID> postLikes() { return postLikes; }

	public static void clearAll() { follows.clear(); blocks.clear(); bookmarks.clear(); postLikes.clear(); }

	private static boolean usersExist(UUID a, UUID b) {
		return UserDAO.getInstance().getByUUID(a) != null && UserDAO.getInstance().getByUUID(b) != null;
	}
}
