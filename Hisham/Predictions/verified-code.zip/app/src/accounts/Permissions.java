package accounts;

import dao.UserDAO;
import dao.model.User;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED theme: a Moderator role between Member and Admin.
 * Adding a constant to User.Role would also need changes in UserSerializer (its switch),
 * GuestState.createStateFromUser and every "== Admin" check. Keeping moderators as a
 * separate set avoids touching the enum, and all permission checks live in ONE place.
 * If the spec says "add a Moderator role to User.Role", do that instead and update those spots.
 */
public final class Permissions {
	private static final Set<UUID> moderators = new HashSet<>();

	private Permissions() {}

	public static boolean isAdmin(UUID user) {
		User u = UserDAO.getInstance().getByUUID(user);
		return u != null && u.role() == User.Role.Admin;
	}

	/** Admins can always moderate; moderators too. */
	public static boolean canModerate(UUID user) {
		return isAdmin(user) || (moderators.contains(user) && UserDAO.getInstance().getByUUID(user) != null);
	}

	/** Admin only; cannot target admins. */
	public static boolean setModerator(UUID admin, UUID user, boolean moderator) {
		if (!isAdmin(admin) || UserDAO.getInstance().getByUUID(user) == null || isAdmin(user)) return false;
		return moderator ? moderators.add(user) : moderators.remove(user);
	}

	public static Set<UUID> moderators() {
		return java.util.Collections.unmodifiableSet(moderators);
	}

	/** persistence */
	public static void restore(UUID user) {
		moderators.add(user);
	}

	public static void clear() {
		moderators.clear();
	}
}
