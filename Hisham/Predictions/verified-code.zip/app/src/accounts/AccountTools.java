package accounts;

import bans.BanTools;
import dao.UserDAO;
import dao.model.User;
import friends.FriendTools;
import mentions.MentionTools;
import moderation.ReportStore;
import notifications.NotificationTools;
import polls.PollTools;
import reactions.ReactionStore;
import readtracking.ReadTracker;
import relations.SocialTools;
import votes.VoteTools;

import java.util.UUID;

/**
 * PREDICTED Task 1 theme: account deletion and account changes.
 * Deletion follows the week 2 briefing: the User is removed (privacy / GDPR), but their
 * Messages stay, still holding the poster UUID, shown as "[deleted]".
 * Every feature store gets a forget/remove call so nothing points at a ghost user.
 */
public final class AccountTools {
	public static final String DELETED_NAME = "[deleted]";

	private AccountTools() {}

	/** Needs the correct password. @return false if unknown user or wrong password */
	public static boolean deleteAccount(UUID user, String password) {
		User u = UserDAO.getInstance().getByUUID(user);
		if (u == null || password == null || !password.equals(u.password())) return false;
		UserDAO.getInstance().remove(u);
		ReportStore.getInstance().removeAllByUser(user);
		ReactionStore.getInstance().removeAllByUser(user);
		VoteTools.removeAllByUser(user);
		PollTools.removeVotesBy(user);
		SocialTools.forgetUser(user);
		FriendTools.forgetUser(user);
		NotificationTools.forgetUser(user);
		MentionTools.forgetUser(user);
		ReadTracker.forgetUser(user);
		BanTools.forgetUser(user);
		return true;
	}

	/** @return the username, or "[deleted]" for a removed / unknown user */
	public static String displayName(UUID user) {
		User u = UserDAO.getInstance().getByUUID(user);
		return u == null ? DELETED_NAME : u.username();
	}

	/**
	 * User is an immutable record: a change = remove the old record + add a new one
	 * with the SAME UUID (so messages, reports... still point at them).
	 */
	public static boolean changePassword(UUID user, String oldPassword, String newPassword) {
		User u = UserDAO.getInstance().getByUUID(user);
		if (u == null || !u.password().equals(oldPassword) || !UserDAO.isValidPassword(newPassword)) return false;
		return replace(u, new User(u.id(), u.role(), u.username(), newPassword));
	}

	/** @return false if the name is invalid or taken by someone else (case-insensitive) */
	public static boolean changeUsername(UUID user, String newUsername) {
		User u = UserDAO.getInstance().getByUUID(user);
		if (u == null || !UserDAO.isValidUsername(newUsername)) return false;
		User existing = UserDAO.getInstance().get(new User(newUsername));
		if (existing != null && !existing.id().equals(user)) return false;
		return replace(u, new User(u.id(), u.role(), newUsername, u.password()));
	}

	/** Admin promotes / demotes another user. */
	public static boolean setRole(UUID admin, UUID user, User.Role role) {
		User a = UserDAO.getInstance().getByUUID(admin);
		User u = UserDAO.getInstance().getByUUID(user);
		if (a == null || u == null || role == null || a.role() != User.Role.Admin || a.id().equals(user)) return false;
		return replace(u, new User(u.id(), role, u.username(), u.password()));
	}

	private static boolean replace(User oldUser, User newUser) {
		UserDAO.getInstance().remove(oldUser);
		return UserDAO.getInstance().add(newUser);
	}
}
