package votes;

import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import util.TopKIterator;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: up/down votes on messages (Reddit-style score).
 *  vote(msg, user, +1 or -1): new vote or switch direction; same vote twice -> false.
 */
public final class VoteTools {
	public static final int UP = 1;
	public static final int DOWN = -1;

	private static final Map<UUID, MessageVotes> votesByMessage = new HashMap<>();

	private VoteTools() {}

	/** @return false if ids missing, direction not +1/-1, or the user already voted this way */
	public static boolean vote(UUID message, UUID user, int direction, long timestamp) {
		if ((direction != UP && direction != DOWN) || !exists(message, user)) return false;
		return votesByMessage.computeIfAbsent(message, MessageVotes::new).set(user, direction, timestamp);
	}

	/** @return false if the user had no vote on that message */
	public static boolean removeVote(UUID message, UUID user) {
		MessageVotes votes = votesByMessage.get(message);
		if (votes == null || !votes.remove(user)) return false;
		if (votes.isEmpty()) votesByMessage.remove(message);
		return true;
	}

	/** @return +1, -1 or 0 */
	public static int getVote(UUID message, UUID user) {
		MessageVotes votes = votesByMessage.get(message);
		return votes == null ? 0 : votes.getVote(user);
	}

	public static int getScore(UUID message) {
		MessageVotes votes = votesByMessage.get(message);
		return votes == null ? 0 : votes.score();
	}

	public static int getUpvotes(UUID message) {
		MessageVotes votes = votesByMessage.get(message);
		return votes == null ? 0 : votes.up();
	}

	public static int getDownvotes(UUID message) {
		MessageVotes votes = votesByMessage.get(message);
		return votes == null ? 0 : votes.down();
	}

	/**
	 * Factory for vote rankings (Strategy = Comparator):
	 *  "TOP"           highest score first
	 *  "CONTROVERSIAL" most votes on BOTH sides first (min(up, down)), then most votes
	 *  "NEWEST"        most recently voted first
	 */
	static Comparator<MessageVotes> ordering(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null");
		return switch (strategy) {
			case "TOP" -> Comparator.comparingInt(MessageVotes::score).reversed();
			case "CONTROVERSIAL" -> Comparator.comparingInt((MessageVotes v) -> Math.min(v.up(), v.down())).reversed()
					.thenComparing(Comparator.comparingInt(MessageVotes::total).reversed());
			case "NEWEST" -> Comparator.comparingLong(MessageVotes::latestTimestamp).reversed();
			default -> throw new IllegalArgumentException("Unknown strategy: " + strategy);
		};
	}

	/** Top messages (each once, only messages with at least one vote). */
	public static Iterator<Message> getTopMessages(String strategy, int amount) {
		return new TopKIterator<>(votesByMessage.values(), ordering(strategy), v -> !v.isEmpty(),
				v -> MessageIndex.getInstance().get(v.getMessageId()), amount);
	}

	/** Account deletion. */
	public static void removeAllByUser(UUID user) {
		votesByMessage.values().removeIf(votes -> votes.remove(user) && votes.isEmpty());
	}

	/** read-only, for persistence */
	public static Collection<MessageVotes> all() {
		return Collections.unmodifiableCollection(votesByMessage.values());
	}

	/** restore one saved vote without existence checks (persistence) */
	public static void restore(UUID message, UUID user, int direction, long timestamp) {
		votesByMessage.computeIfAbsent(message, MessageVotes::new).set(user, direction, timestamp);
	}

	public static void clear() {
		votesByMessage.clear();
	}

	private static boolean exists(UUID message, UUID user) {
		return MessageIndex.getInstance().get(message) != null && UserDAO.getInstance().getByUUID(user) != null;
	}
}
