package votes;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Up/down votes on ONE message. HashMap user -> +1/-1 for O(1) checks,
 * plus up/down counters kept in sync so score() is O(1).
 */
public class MessageVotes {
	private final UUID messageId;
	private final Map<UUID, Integer> votesByUser = new HashMap<>();
	private int up = 0;
	private int down = 0;
	private long latestTimestamp = Long.MIN_VALUE;

	public MessageVotes(UUID messageId) {
		this.messageId = messageId;
	}

	/** Records or switches a vote. @return false if the user already has this exact vote */
	public boolean set(UUID user, int direction, long timestamp) {
		Integer previous = votesByUser.put(user, direction);
		if (previous != null && previous == direction) return false;
		if (previous != null) count(previous, -1); // switching: undo the old vote
		count(direction, +1);
		latestTimestamp = Math.max(latestTimestamp, timestamp);
		return true;
	}

	/** @return false if the user had not voted */
	public boolean remove(UUID user) {
		Integer previous = votesByUser.remove(user);
		if (previous == null) return false;
		count(previous, -1);
		return true;
	}

	private void count(int direction, int delta) {
		if (direction > 0) up += delta;
		else down += delta;
	}

	/** @return +1, -1, or 0 if the user has not voted */
	public int getVote(UUID user) {
		return votesByUser.getOrDefault(user, 0);
	}

	public int score() { return up - down; }
	public int up() { return up; }
	public int down() { return down; }
	public int total() { return up + down; }
	public boolean isEmpty() { return votesByUser.isEmpty(); }
	public long latestTimestamp() { return latestTimestamp; }
	public UUID getMessageId() { return messageId; }

	/** read-only user -> direction, for persistence */
	public Map<UUID, Integer> getVotes() {
		return Collections.unmodifiableMap(votesByUser);
	}
}
