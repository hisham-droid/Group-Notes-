package scheduled;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;
import java.util.Comparator;

/**
 * PREDICTED theme: scheduled (delayed) messages.
 * A min-heap ordered by publish time: the next one due is always at the top, so
 * publishDue(now) only looks at messages that are actually due: O(k log n).
 * Cancelling marks the id; cancelled entries are skipped when they reach the top
 * ("lazy deletion": avoids an O(n) removal from the heap).
 */
public final class ScheduledMessages {
	private static final PriorityQueue<Message> queue =
			new PriorityQueue<>(Comparator.comparingLong(Message::timestamp).thenComparing(Message::id));
	private static final Set<UUID> cancelled = new HashSet<>();

	private ScheduledMessages() {}

	/** @return the id of the scheduled message, or null if post/user missing */
	public static UUID schedule(UUID post, UUID user, String text, long publishAt) {
		if (PostDAO.getInstance().get(new Post(post)) == null || UserDAO.getInstance().getByUUID(user) == null || text == null) return null;
		Message message = new Message(UUID.randomUUID(), user, post, publishAt, text);
		queue.add(message);
		return message.id();
	}

	public static boolean cancel(UUID scheduledId) {
		for (Message m : queue) {
			if (m.id().equals(scheduledId) && !cancelled.contains(scheduledId)) return cancelled.add(scheduledId);
		}
		return false;
	}

	/** Publishes every message with publish time <= now into its post. @return what was published */
	public static List<Message> publishDue(long now) {
		List<Message> published = new ArrayList<>();
		while (!queue.isEmpty() && queue.peek().timestamp() <= now) {
			Message m = queue.poll();
			if (cancelled.remove(m.id())) continue;
			Post post = PostDAO.getInstance().get(new Post(m.thread()));
			if (post != null && post.messages.insert(m)) published.add(m);
		}
		return published;
	}

	public static int pendingCount() {
		return queue.size() - cancelled.size();
	}

	/** persistence: pending (not cancelled) scheduled messages */
	public static List<Message> pending() {
		List<Message> result = new ArrayList<>();
		for (Message m : queue) if (!cancelled.contains(m.id())) result.add(m);
		return result;
	}

	public static void restore(Message message) {
		queue.add(message);
	}

	public static void clear() {
		queue.clear();
		cancelled.clear();
	}
}
