package dao;

import dao.model.User;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class UserDAO extends DAO<User> {
	// TODO: apply the Singleton design pattern to this class.
	// You may modify the existing constructor, add new constructors,
	// and add new helper method and private fields.
	/**
	 * Generates a UserDAO. We enforce uniqueness in usernames (but not in passwords),
	 * and further two usernames are considered identical if they are equal, ignoring case
	 */
	private UserDAO() { // HACKATHON: private, so it is a real Singleton
		super((o1, o2) -> o1.username().compareToIgnoreCase(o2.username()));
	}
	
	private static UserDAO instance;
	public static UserDAO getInstance() {
		if (instance == null) instance = new UserDAO();
		return instance;
	}

	/**
	 * Attempts to authenticate as a particular user. If the user exists
	 * and their passwords match, the login is considered successful.
	 * @param username the username
	 * @param password the password
	 * @return the User if successful, null otherwise
	 */
	public User login(String username, String password) {
		User user = data.get(new User(username));
		return (user != null && user.password().equals(password)) ? user : null;
	}

	/**
	 * Attempts to register a new user. Users must have unique usernames,
	 * and their usernames must contain only alphanumeric characters.
	 * Usernames can be between 4 and 20 characters long.
	 * Passwords must be at least four characters long, and can include
	 * any codepoints.
	 * @param username the desired username
	 * @param password the desired password
	 * @return the newly-created User if successful, null otherwise
	 */
	public User register(String username, String password) {
		if (!isValidUsername(username) || !isValidPassword(password)) return null;
		if (data.get(new User(username)) != null) return null; // taken (case-insensitive)

		User newUser = new User(UUID.randomUUID(), User.Role.Member, username, password);
		return add(newUser) ? newUser : null; // HACKATHON: go through add() so the UUID index is updated
	}

	/** HACKATHON: shared by register and AccountTools (no duplicated rules). 4-20 letters/digits. */
	public static boolean isValidUsername(String username) {
		if (username == null || username.length() < 4 || username.length() > 20) return false;
		for (char c : username.toCharArray()) {
			if (!Character.isLetterOrDigit(c)) return false;
		}
		return true;
	}

	/** HACKATHON: at least 4 characters, any code points. */
	public static boolean isValidPassword(String password) {
		return password != null && password.length() >= 4;
	}

	// ---------------------------------------------------------------------
	// HACKATHON: O(1) lookup by UUID (the original getByUUID scanned every user)
	// ---------------------------------------------------------------------

	// NOT final and NOT initialised here on purpose: DAO's constructor calls clear()
	// BEFORE this class's field initialisers run, so clear() creates the map instead.
	private Map<UUID, User> usersById;

	@Override
	public boolean add(User user) {
		if (!super.add(user)) return false;      // duplicate username -> nothing to index
		if (user.id() != null) usersById.put(user.id(), user);
		return true;
	}

	@Override
	public boolean remove(User user) {
		User stored = get(user);                 // the comparator matches by username
		if (stored == null || !super.remove(stored)) return false;
		if (stored.id() != null) usersById.remove(stored.id());
		return true;
	}

	@Override
	public void clear() {
		super.clear();
		usersById = new HashMap<>();
	}

	/**
	 * Fetches a User by just a UUID, in O(1).
	 * @param id the UUID to search for
	 * @return the user if they exist, else null
	 */
	public User getByUUID(UUID id) {
		if (id == null) return null;
		return usersById.get(id);
	}
}
