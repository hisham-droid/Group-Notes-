package dao;

import dao.model.Message;
import dao.model.Post;
import sorteddata.SortedDataSubject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * HACKATHON: finds a Message from just its UUID in O(1) (expected).
 * <p>
 * Why it is needed: messages live inside each Post's SortedData, which is ordered by
 * (timestamp, thread, poster, id). You cannot search it by id alone, so without an
 * index "does this message exist?" means scanning every message of every post: O(n).
 * <p>
 * How it stays up to date: every Post registers this index as a listener on its
 * messages (Observer pattern), so any insert anywhere, including test code calling
 * post.messages.insert(...) directly, is recorded automatically.
 * <p>
 * Singleton, like the other DAOs.
 */
public class MessageIndex implements SortedDataSubject<Message> {
	private static MessageIndex instance;

	public static MessageIndex getInstance() {
		if (instance == null) instance = new MessageIndex();
		return instance;
	}

	private final Map<UUID, Message> messagesById = new HashMap<>();

	private MessageIndex() {}

	// Other features (mentions, notifications, ...) that want to hear about EVERY new
	// message in EVERY post subscribe here once, instead of registering on each Post.
	private final List<SortedDataSubject<Message>> messageListeners = new ArrayList<>();

	/** Subscribe to every message added anywhere (Observer). */
	public void addMessageListener(SortedDataSubject<Message> listener) {
		messageListeners.add(listener);
	}

	public void removeMessageListener(SortedDataSubject<Message> listener) {
		messageListeners.remove(listener);
	}

	// Listeners that also want EDITS (a re-inserted message with a known id),
	// e.g. a search index that must learn the new words.
	private final List<SortedDataSubject<Message>> changeListeners = new ArrayList<>();

	/** Subscribe to every new OR edited message. */
	public void addChangeListener(SortedDataSubject<Message> listener) {
		changeListeners.add(listener);
	}

	@Override
	public void onAdd(Message message) {
		if (message.id() == null) return;
		boolean isNew = messagesById.put(message.id(), message) == null;
		// an edit re-inserts a message with a known id: update the index, but do not
		// tell listeners about a "new" message (no duplicate notifications)
		if (isNew) {
			for (SortedDataSubject<Message> listener : messageListeners) listener.onAdd(message);
		}
		for (SortedDataSubject<Message> listener : changeListeners) listener.onAdd(message);
	}

	/** Forget a message that was permanently removed (hard delete / edit replacement). */
	public void forget(UUID id) {
		messagesById.remove(id);
	}

	/**
	 * Finds a message by UUID.
	 * The index can contain "stale" messages from posts that were later removed
	 * (e.g. PostDAO.clear() between tests), so we double-check the message's post
	 * is still stored. That check is an O(log n) PostDAO lookup.
	 * @param id the message UUID
	 * @return the Message, or null if it does not exist in the application
	 */
	public Message get(UUID id) {
		if (id == null) return null;
		Message message = messagesById.get(id);
		if (message == null || message.thread() == null) return null;
		Post post = PostDAO.getInstance().get(new Post(message.thread()));
		if (post == null || post.messages.get(message) == null) return null;
		return message;
	}

	/**
	 * @param message a message that exists
	 * @return the Post the message belongs to, or null
	 */
	public Post getPostOf(Message message) {
		if (message == null || message.thread() == null) return null;
		return PostDAO.getInstance().get(new Post(message.thread()));
	}

	/** Forget everything (useful in tests). */
	public void clear() {
		messagesById.clear();
	}
}
