package dao;

import dao.model.Message;

import java.util.Comparator;

public class MessageComparator implements Comparator<Message> {
	private static MessageComparator instance;

	/**
	 * Implements the Singleton design pattern. Because creating multiple instances
	 * of the MessageComparator would simply waste memory, we may use the Singleton
	 * design pattern to ensure only a single instance exists.
	 * @return the instance
	 */
	public static MessageComparator getInstance() {
		if (instance == null) instance = new MessageComparator();
		return instance;
	}
	private MessageComparator() {}

	/**
	 * Checks if two Messages are identical in these fields: timestamp, thread, poster, and ID.
	 * @param o1 the first object to be compared.
	 * @param o2 the second object to be compared.
	 * @return the result of the comparison, in line with standard Java comparison rules
	 */
	@Override
	public int compare(Message o1, Message o2) {
		int delta = Long.compare(o1.timestamp(), o2.timestamp());
		if (delta != 0) return delta;

		delta = compareNullable(o1.thread(), o2.thread());
		if (delta != 0) return delta;

		delta = compareNullable(o1.poster(), o2.poster());
		if (delta != 0) return delta;

		delta = compareNullable(o1.id(), o2.id());
		return delta;
	}

	// HACKATHON: test code often builds Messages with a null poster/thread.
	// Without this, two such messages with the same timestamp throw NullPointerException.
	private static <C extends Comparable<C>> int compareNullable(C a, C b) {
		if (a == b) return 0;
		if (a == null) return -1;
		if (b == null) return 1;
		return a.compareTo(b);
	}
}
