package dao.model;

import dao.MessageComparator;
import dao.MessageIndex;
import sorteddata.SortedData;
import sorteddata.SortedDataFactory;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

/**
 * A forum post and its messages.
 * HACKATHON additions (Task 2 predictions), all on the post because the post owns its messages:
 *  - hidden messages        (admin moderation)        -> not visible to non-admins
 *  - soft-deleted messages  (author or admin)         -> not visible to non-admins, can be restored
 *  - pinned messages        (admin)                   -> listed first
 *  - locked post            (admin)                   -> members cannot reply
 *  - replace / remove a message (edit history, hard delete)
 * A message is visible to non-admins when it is neither hidden nor deleted.
 */
public class Post implements HasUUID {
	public final UUID id;
	public final UUID poster;
	public final String topic;
	public final SortedData<Message> messages;

	// Second tree with only the messages non-admins may see, kept in sync by
	// listening to `messages` and by refreshVisibility(...).
	//   getVisibleMessages(false) O(1); hide/delete/restore O(log n); costs extra memory.
	private final SortedData<Message> visibleMessages;
	private final SortedData<Message> pinnedMessages;
	private final Set<UUID> hiddenMessageIds = new HashSet<>();
	private final Set<UUID> deletedMessageIds = new HashSet<>();
	private boolean locked = false;

	public Post(UUID id, UUID poster, String topic) {
		this.id = id;
		this.poster = poster;
		this.topic = topic;
		this.messages = SortedDataFactory.makeSortedData(MessageComparator.getInstance());
		this.visibleMessages = SortedDataFactory.makeSortedData(MessageComparator.getInstance());
		this.pinnedMessages = SortedDataFactory.makeSortedData(MessageComparator.getInstance());

		// every new message: index it by UUID, and show it unless it is hidden/deleted
		this.messages.registerListener(MessageIndex.getInstance());
		this.messages.registerListener(this::refreshVisibility);
	}

	public Post(UUID id) {
		this(id, null, null);
	}

	// ------------------------------------------------------------ visibility

	/** @return true if non-admins may see this message (not hidden and not deleted) */
	public boolean isVisibleToMembers(UUID messageId) {
		return !hiddenMessageIds.contains(messageId) && !deletedMessageIds.contains(messageId);
	}

	// puts the message into / takes it out of the visible tree to match its flags.
	// insert of an existing element and remove of a missing one both do nothing, so this is idempotent.
	private void refreshVisibility(Message message) {
		if (isVisibleToMembers(message.id())) visibleMessages.insert(message);
		else visibleMessages.remove(message);
	}

	/** Hide or unhide (admin moderation). Doing it twice is harmless. */
	public void setHidden(Message message, boolean hidden) {
		if (hidden) hiddenMessageIds.add(message.id());
		else hiddenMessageIds.remove(message.id());
		refreshVisibility(message);
	}

	/** Soft-delete or restore. The message stays in `messages`, so admins still see it. */
	public void setDeleted(Message message, boolean deleted) {
		if (deleted) deletedMessageIds.add(message.id());
		else deletedMessageIds.remove(message.id());
		refreshVisibility(message);
	}

	public boolean isHidden(UUID messageId) {
		return hiddenMessageIds.contains(messageId);
	}

	public boolean isDeleted(UUID messageId) {
		return deletedMessageIds.contains(messageId);
	}

	/** @return read-only view of hidden message ids (for persistence) */
	public Set<UUID> getHiddenMessageIds() {
		return Collections.unmodifiableSet(hiddenMessageIds);
	}

	/** @return read-only view of soft-deleted message ids (for persistence) */
	public Set<UUID> getDeletedMessageIds() {
		return Collections.unmodifiableSet(deletedMessageIds);
	}

	/**
	 * Admins see everything; everyone else sees only non-hidden, non-deleted messages.
	 * The returned structure is live: do not insert into it directly.
	 */
	public SortedData<Message> getVisibleMessages(boolean isAdmin) {
		return isAdmin ? messages : visibleMessages;
	}

	// ------------------------------------------------------------ pinning

	public void setPinned(Message message, boolean pinned) {
		if (pinned) pinnedMessages.insert(message);
		else pinnedMessages.remove(message);
	}

	public boolean isPinned(Message message) {
		return pinnedMessages.get(message) != null;
	}

	/** @return pinned messages in time order (includes hidden ones; callers filter for non-admins) */
	public Iterator<Message> getPinnedMessages() {
		return pinnedMessages.getAll();
	}

	// ------------------------------------------------------------ locking

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	// ------------------------------------------------------------ replace / remove

	/**
	 * Permanently removes a message from every structure of this post.
	 * @return false if the message was not in this post
	 */
	public boolean removeMessage(Message message) {
		if (!messages.remove(message)) return false;
		visibleMessages.remove(message);
		pinnedMessages.remove(message);
		hiddenMessageIds.remove(message.id());
		deletedMessageIds.remove(message.id());
		return true;
	}

	/**
	 * Swaps a message for a new version with the same id/timestamp/thread/poster (an edit).
	 * Needed because Message is an immutable record: an edit is a NEW record.
	 * The comparator ignores the text, so old and new compare as equal: we must remove
	 * the old one first, otherwise insert() thinks it is a duplicate and does nothing.
	 * Flags (hidden/deleted/pinned) are kept because they are stored by id.
	 */
	public void replaceMessage(Message oldVersion, Message newVersion) {
		boolean wasPinned = isPinned(oldVersion);
		messages.remove(oldVersion);
		visibleMessages.remove(oldVersion);
		pinnedMessages.remove(oldVersion);
		messages.insert(newVersion);  // listeners re-index it and refresh visibility
		if (wasPinned) pinnedMessages.insert(newVersion);
	}

	public UUID getUUID() { return id; }
}
