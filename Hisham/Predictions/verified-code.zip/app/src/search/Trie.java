package search;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * PREDICTED: prefix search (e.g. username autocomplete). A trie stores words letter by letter;
 * all words with a prefix live under the prefix's node. Lookup is O(prefix length + results).
 * Lower-cases everything; children in a TreeMap so results come out alphabetically.
 */
public class Trie {
	private static final class Node {
		final Map<Character, Node> children = new TreeMap<>();
		String word; // non-null if a word ends here (stored with its original case)
	}

	private final Node root = new Node();

	public void add(String word) {
		Node node = root;
		for (char c : word.toLowerCase().toCharArray()) node = node.children.computeIfAbsent(c, k -> new Node());
		node.word = word;
	}

	/** @return false if the word was not stored */
	public boolean remove(String word) {
		Node node = find(word.toLowerCase());
		if (node == null || node.word == null) return false;
		node.word = null; // (empty branches are left in place: simpler, still correct)
		return true;
	}

	public boolean contains(String word) {
		Node node = find(word.toLowerCase());
		return node != null && node.word != null;
	}

	/** @return up to `limit` stored words starting with prefix (case-insensitive), alphabetical */
	public List<String> startingWith(String prefix, int limit) {
		List<String> result = new ArrayList<>();
		Node node = find(prefix.toLowerCase());
		if (node != null) collect(node, result, limit);
		return result;
	}

	private Node find(String key) {
		Node node = root;
		for (char c : key.toCharArray()) {
			node = node.children.get(c);
			if (node == null) return null;
		}
		return node;
	}

	private void collect(Node node, List<String> out, int limit) {
		if (out.size() >= limit) return;
		if (node.word != null) out.add(node.word);
		for (Node child : node.children.values()) collect(child, out, limit);
	}
}
