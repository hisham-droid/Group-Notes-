package search;

import dao.MessageComparator;
import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import dao.model.User;
import sorteddata.SortedDataSubject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED theme: search.
 *  - Messages: INVERTED INDEX word -> message ids, filled once per new message (Observer).
 *    search("design patterns") returns messages containing ALL words (AND), newest first.
 *    We intersect starting from the rarest word, so the cost depends on the result size,
 *    not on the number of messages.
 *  - Usernames: Trie for autocomplete (rebuilt from UserDAO on demand).
 */
public final class SearchTools {
	private static final Map<String, Set<UUID>> index = new HashMap<>();
	private static final SortedDataSubject<Message> LISTENER = SearchTools::indexMessage;
	static {
		MessageIndex.getInstance().addChangeListener(LISTENER); // new AND edited messages
	}

	private SearchTools() {}

	/** Call at start-up so early messages are indexed. */
	public static void init() {}

	/** lower-case words made of letters/digits */
	static List<String> words(String text) {
		List<String> result = new ArrayList<>();
		if (text == null) return result;
		for (String w : text.toLowerCase().split("[^\\p{L}\\p{N}]+")) if (!w.isEmpty()) result.add(w);
		return result;
	}

	private static void indexMessage(Message message) {
		for (String word : words(message.message())) index.computeIfAbsent(word, k -> new HashSet<>()).add(message.id());
	}

	/** @return messages containing every word of the query, newest first (deleted/edited-away hits dropped) */
	public static List<Message> search(String query) {
		List<String> terms = words(query);
		List<Message> result = new ArrayList<>();
		if (terms.isEmpty()) return result;
		terms.sort((x, y) -> Integer.compare(index.getOrDefault(x, Set.of()).size(), index.getOrDefault(y, Set.of()).size()));
		Set<UUID> candidates = new HashSet<>(index.getOrDefault(terms.get(0), Set.of()));
		for (int i = 1; i < terms.size() && !candidates.isEmpty(); i++) candidates.retainAll(index.getOrDefault(terms.get(i), Set.of()));
		for (UUID id : candidates) {
			Message m = MessageIndex.getInstance().get(id);
			// re-check the CURRENT text: an edit may have removed the word
			if (m != null && new HashSet<>(words(m.message())).containsAll(terms)) result.add(m);
		}
		result.sort(MessageComparator.getInstance().reversed());
		return result;
	}

	/** Username autocomplete, alphabetical, case-insensitive. */
	public static List<String> autocompleteUsername(String prefix, int limit) {
		Trie trie = new Trie();
		for (Iterator<User> it = UserDAO.getInstance().getAll(); it.hasNext(); ) trie.add(it.next().username());
		return trie.startingWith(prefix, limit);
	}

	public static void clear() {
		index.clear();
	}
}
