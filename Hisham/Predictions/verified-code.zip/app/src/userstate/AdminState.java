package userstate;

import dao.model.Post;
import dao.model.User;

public class AdminState extends MemberState {
	public AdminState(User user) {
		super(user);
	}

	/** HACKATHON: admins may reply even to locked posts. */
	@Override
	protected boolean canReplyTo(Post post) {
		return true;
	}
}
