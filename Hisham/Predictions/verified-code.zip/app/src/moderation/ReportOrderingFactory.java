package moderation;

import java.util.Comparator;

/**
 * HACKATHON (Task 4): FACTORY pattern.
 * Turns the strategy string into an ordering (a Comparator is a STRATEGY object).
 * Adding a new strategy later means adding one case here and nothing else.
 */
public final class ReportOrderingFactory {
	public static final String OLDEST = "OLDEST";
	public static final String MOST = "MOST";

	private ReportOrderingFactory() {} // static factory, no instances

	/**
	 * @param strategy "OLDEST" (oldest active report first) or "MOST" (most active reports first)
	 * @return the matching ordering
	 * @throws IllegalArgumentException for null or any other string (case-sensitive)
	 */
	public static Comparator<MessageReports> create(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null");
		return switch (strategy) {
			case OLDEST -> Comparator.comparingLong(MessageReports::oldestTimestamp);
			case MOST -> Comparator.comparingInt(MessageReports::activeCount).reversed();
			default -> throw new IllegalArgumentException("Unknown strategy: " + strategy);
		};
	}
}
