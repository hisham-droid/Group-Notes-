package moderation;

import java.util.UUID;

/**
 * HACKATHON (Task 1): one user's report on one message.
 * A record = immutable value class with equals/hashCode/toString for free.
 * @param message   the reported message's UUID
 * @param user      the reporting user's UUID
 * @param timestamp when the report was made (UNIX ms)
 */
public record Report(UUID message, UUID user, long timestamp) {}
