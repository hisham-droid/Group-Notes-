package moderation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * HACKATHON (Task 1): every report in the application, grouped by message.
 * HashMap message -> MessageReports, so finding a message's reports is O(1).
 * Singleton, like the DAOs (one shared store for the whole app).
 * <p>
 * Reports stay here even if the message is hidden (spec requirement).
 */
public class ReportStore {
	private static ReportStore instance;

	public static ReportStore getInstance() {
		if (instance == null) instance = new ReportStore();
		return instance;
	}

	private final Map<UUID, MessageReports> reportsByMessage = new HashMap<>();

	private ReportStore() {}

	/** @return false if this user already reported this message */
	public boolean add(Report report) {
		return reportsByMessage
				.computeIfAbsent(report.message(), MessageReports::new)
				.add(report);
	}

	/** @return false if there was no such active report */
	public boolean remove(UUID message, UUID user) {
		MessageReports reports = reportsByMessage.get(message);
		if (reports == null || !reports.remove(user)) return false;
		// drop empty entries so Task 4 never sees messages with zero active reports
		if (reports.isEmpty()) reportsByMessage.remove(message);
		return true;
	}

	public boolean hasReported(UUID message, UUID user) {
		MessageReports reports = reportsByMessage.get(message);
		return reports != null && reports.hasReported(user);
	}

	/** @return the per-message report groups (read-only), used by Task 4 */
	public Collection<MessageReports> getAllMessageReports() {
		return Collections.unmodifiableCollection(reportsByMessage.values());
	}

	/** @return every individual report, used for persistence (Task 3) */
	public Iterator<Report> getAllReports() {
		List<Report> all = new ArrayList<>();
		for (MessageReports reports : reportsByMessage.values()) all.addAll(reports.getReports());
		return all.iterator();
	}

	/** Account deletion: drops every report made by this user. O(number of reported messages). */
	public void removeAllByUser(UUID user) {
		reportsByMessage.values().removeIf(reports -> reports.remove(user) && reports.isEmpty());
	}

	/** Hard delete: drops every report on this message. */
	public void removeAllForMessage(UUID message) {
		reportsByMessage.remove(message);
	}

	public void clear() {
		reportsByMessage.clear();
	}
}
