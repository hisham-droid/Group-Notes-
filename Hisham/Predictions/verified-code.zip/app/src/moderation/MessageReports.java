package moderation;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;

/**
 * HACKATHON (Task 1): all ACTIVE reports on ONE message.
 * <p>
 * Two structures, each picked for one job:
 * <ul>
 *   <li>HashMap user -> Report: add / remove / hasReported in O(1)</li>
 *   <li>TreeSet ordered by time: "oldest active report" in O(log k), and it stays
 *       correct after a removal (a plain "first timestamp" field would go stale)</li>
 * </ul>
 * activeCount() is O(1) (the map's size), which Task 4's "MOST" strategy needs.
 */
public class MessageReports {
	// ties on timestamp are broken by user so two different reports are never "equal"
	private static final Comparator<Report> BY_TIME =
			Comparator.comparingLong(Report::timestamp).thenComparing(Report::user);

	private final UUID messageId;
	private final Map<UUID, Report> reportsByUser = new HashMap<>();
	private final TreeSet<Report> reportsByTime = new TreeSet<>(BY_TIME);

	public MessageReports(UUID messageId) {
		this.messageId = messageId;
	}

	/** @return false if this user already reported the message */
	public boolean add(Report report) {
		if (reportsByUser.putIfAbsent(report.user(), report) != null) return false;
		reportsByTime.add(report);
		return true;
	}

	/** @return false if this user had no active report */
	public boolean remove(UUID user) {
		Report removed = reportsByUser.remove(user);
		if (removed == null) return false;
		reportsByTime.remove(removed);
		return true;
	}

	public boolean hasReported(UUID user) {
		return reportsByUser.containsKey(user);
	}

	public int activeCount() {
		return reportsByUser.size();
	}

	public boolean isEmpty() {
		return reportsByUser.isEmpty();
	}

	/** @return timestamp of the oldest ACTIVE report; only call when not empty */
	public long oldestTimestamp() {
		return reportsByTime.first().timestamp();
	}

	/** @return timestamp of the newest ACTIVE report; only call when not empty */
	public long newestTimestamp() {
		return reportsByTime.last().timestamp();
	}

	public UUID getMessageId() {
		return messageId;
	}

	/** @return every active report (read-only), used for persistence */
	public Collection<Report> getReports() {
		return Collections.unmodifiableCollection(reportsByUser.values());
	}
}
