package moderation;

import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;

import java.util.Iterator;
import java.util.UUID;

/**
 * HACKATHON: entry point for the moderation module (a FACADE over the classes
 * in this package). Every method validates its input, then delegates.
 */
public class ModerationTools {
	private ModerationTools() {} // static-only

	// ---------------------------------------------------------------- Task 1

	/**
	 * @return true if recorded; false if message/user does not exist or the user already reported it
	 */
	public static boolean addReport(UUID message, UUID user, long timestamp) {
		if (!messageAndUserExist(message, user)) return false;
		return ReportStore.getInstance().add(new Report(message, user, timestamp));
	}

	/**
	 * The timestamp parameter is required by the given signature but not needed:
	 * a user has at most one active report per message.
	 * @return true if removed; false if no such report or either UUID does not exist
	 */
	public static boolean removeReport(UUID message, UUID user, long timestamp) {
		if (!messageAndUserExist(message, user)) return false;
		return ReportStore.getInstance().remove(message, user);
	}

	/** @return true if this user currently has an active report on this message */
	public static boolean hasReported(UUID message, UUID user) {
		return ReportStore.getInstance().hasReported(message, user);
	}

	// ---------------------------------------------------------------- Task 2

	/**
	 * @return false (and change nothing) if either UUID does not exist or the user is not an Admin
	 */
	public static boolean setHidden(UUID message, UUID user, boolean hidden) {
		Message target = MessageIndex.getInstance().get(message);
		User moderator = UserDAO.getInstance().getByUUID(user);
		if (target == null || moderator == null || moderator.role() != User.Role.Admin) return false;

		Post post = MessageIndex.getInstance().getPostOf(target);
		post.setHidden(target, hidden);
		return true;
	}

	// ---------------------------------------------------------------- Task 4

	/**
	 * @param strategy "OLDEST" or "MOST"
	 * @param amount   maximum number of messages to return (must be positive)
	 * @throws IllegalArgumentException for an unknown strategy or a non-positive amount
	 */
	public static Iterator<Message> getReportedMessages(String strategy, int amount) {
		if (amount <= 0) throw new IllegalArgumentException("amount must be positive, was " + amount);
		return new ReportedMessageIterator(
				ReportStore.getInstance().getAllMessageReports(),
				ReportOrderingFactory.create(strategy),
				amount);
	}

	// ---------------------------------------------------------------- helpers

	// both lookups are O(1) thanks to MessageIndex and UserDAO's UUID index
	private static boolean messageAndUserExist(UUID message, UUID user) {
		return MessageIndex.getInstance().get(message) != null
				&& UserDAO.getInstance().getByUUID(user) != null;
	}
}
