package moderation;

import dao.MessageIndex;
import dao.model.Message;
import util.TopKIterator;

import java.util.Comparator;
import java.util.Iterator;

/**
 * PREDICTED Task 4 variants beyond the practice spec (kept separate so the practice
 * getReportedMessages still throws for "NEWEST", as its spec requires).
 *  "OLDEST"           oldest active report first
 *  "NEWEST"           newest active report first
 *  "MOST"             most active reports first
 *  "MOST_THEN_OLDEST" most reports first; ties broken by oldest report (two-key ordering)
 *  "LEAST"            fewest reports first
 */
public final class ReportQueries {
	private ReportQueries() {}

	/** FACTORY: strategy name -> ordering (STRATEGY object) */
	public static Comparator<MessageReports> ordering(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null");
		return switch (strategy) {
			case "OLDEST" -> Comparator.comparingLong(MessageReports::oldestTimestamp);
			case "NEWEST" -> Comparator.comparingLong(MessageReports::newestTimestamp).reversed();
			case "MOST" -> Comparator.comparingInt(MessageReports::activeCount).reversed();
			case "MOST_THEN_OLDEST" -> Comparator.comparingInt(MessageReports::activeCount).reversed()
					.thenComparingLong(MessageReports::oldestTimestamp);
			case "LEAST" -> Comparator.comparingInt(MessageReports::activeCount);
			default -> throw new IllegalArgumentException("Unknown strategy: " + strategy);
		};
	}

	/** Same rules as getReportedMessages (amount > 0, no zero-report messages, each once). */
	public static Iterator<Message> getReportedMessages(String strategy, int amount) {
		return new TopKIterator<>(ReportStore.getInstance().getAllMessageReports(), ordering(strategy),
				r -> !r.isEmpty(), r -> MessageIndex.getInstance().get(r.getMessageId()), amount);
	}
}
