package moderation;

import dao.MessageIndex;
import dao.model.Message;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;

/**
 * HACKATHON (Task 4): ITERATOR pattern.
 * Yields at most `amount` reported messages, best first, each at most once.
 * <p>
 * Efficiency: building the heap is O(m); each next() is O(log m). So asking for the
 * top k of m reported messages costs O(m + k log m), cheaper than sorting all m.
 * Messages that no longer exist are skipped silently.
 */
public class ReportedMessageIterator implements Iterator<Message> {
	private final PriorityQueue<MessageReports> queue;
	private int remaining;
	private Message next; // look-ahead: the message next() will return, or null when done

	public ReportedMessageIterator(Collection<MessageReports> reported, Comparator<MessageReports> order, int amount) {
		this.queue = new PriorityQueue<>(Math.max(1, reported.size()), order);
		for (MessageReports reports : reported) {
			if (!reports.isEmpty()) queue.add(reports); // never return zero-report messages
		}
		this.remaining = amount;
		advance();
	}

	// moves `next` to the next existing message, respecting the amount limit
	private void advance() {
		next = null;
		while (remaining > 0 && !queue.isEmpty()) {
			Message candidate = MessageIndex.getInstance().get(queue.poll().getMessageId());
			if (candidate != null) {
				next = candidate;
				remaining--;
				return;
			}
		}
	}

	@Override
	public boolean hasNext() {
		return next != null;
	}

	@Override
	public Message next() {
		if (next == null) throw new NoSuchElementException();
		Message result = next;
		advance();
		return result;
	}
}
