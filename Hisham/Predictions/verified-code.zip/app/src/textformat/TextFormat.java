package textformat;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PREDICTED theme: rich text in messages.
 *  - emoji shortcodes ":smile:" -> "😄" (unknown codes are left as they are)
 *  - markdown to plain text: **bold**, *italic*, `code`, [text](url) -> text (url)
 *  - preview: first N characters, cut at a word boundary, with "..."
 */
public final class TextFormat {
	private static final Map<String, String> EMOJI = Map.of(
			"smile", "😄", "heart", "❤️", "thumbsup", "👍",
			"laugh", "😂", "sad", "😢", "fire", "🔥");
	private static final Pattern SHORTCODE = Pattern.compile(":([a-z]+):");

	private TextFormat() {}

	public static String replaceEmoji(String text) {
		if (text == null) return null;
		Matcher m = SHORTCODE.matcher(text);
		StringBuilder out = new StringBuilder();
		while (m.find()) m.appendReplacement(out, Matcher.quoteReplacement(EMOJI.getOrDefault(m.group(1), m.group())));
		m.appendTail(out);
		return out.toString();
	}

	public static String markdownToPlain(String text) {
		if (text == null) return null;
		return text.replaceAll("\\[([^\\]]+)\\]\\(([^)]+)\\)", "$1 ($2)")
				.replaceAll("\\*\\*(.+?)\\*\\*", "$1")
				.replaceAll("\\*(.+?)\\*", "$1")
				.replaceAll("`(.+?)`", "$1");
	}

	public static String preview(String text, int maxLength) {
		if (text == null || text.length() <= maxLength) return text;
		int cut = text.lastIndexOf(' ', maxLength);
		if (cut <= 0) cut = maxLength;
		return text.substring(0, cut) + "...";
	}
}
