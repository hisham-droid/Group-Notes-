package stats;

import dao.PostDAO;
import dao.model.Message;
import dao.model.Post;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * PREDICTED theme: statistics. Each method is one pass over all messages (O(n)).
 */
public final class StatsTools {
	private StatsTools() {}

	public static int totalMessages() {
		int total = 0;
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) total += it.next().messages.size();
		return total;
	}

	/** user -> number of messages written (null posters ignored) */
	public static Map<UUID, Integer> messagesPerUser() {
		Map<UUID, Integer> counts = new HashMap<>();
		forEachMessage(m -> { if (m.poster() != null) counts.merge(m.poster(), 1, Integer::sum); });
		return counts;
	}

	/** UTC day -> messages that day, in date order */
	public static Map<LocalDate, Integer> messagesPerDay() {
		Map<LocalDate, Integer> counts = new TreeMap<>();
		forEachMessage(m -> counts.merge(LocalDate.ofInstant(Instant.ofEpochMilli(m.timestamp()), ZoneOffset.UTC), 1, Integer::sum));
		return counts;
	}

	/** @return average text length, 0 if there are no messages */
	public static double averageMessageLength() {
		long[] sumAndCount = new long[2];
		forEachMessage(m -> { sumAndCount[0] += m.message() == null ? 0 : m.message().length(); sumAndCount[1]++; });
		return sumAndCount[1] == 0 ? 0 : (double) sumAndCount[0] / sumAndCount[1];
	}

	/** @return the post with the most messages, or null if there are none */
	public static Post busiestPost() {
		Post best = null;
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) {
			Post p = it.next();
			if (best == null || p.messages.size() > best.messages.size()) best = p;
		}
		return best == null || best.messages.size() == 0 ? null : best;
	}

	private static void forEachMessage(java.util.function.Consumer<Message> action) {
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) it.next().messages.getAll().forEachRemaining(action);
	}
}
