package dms;

import java.util.UUID;

/** A private message between two users. */
public record DirectMessage(UUID id, UUID from, UUID to, long timestamp, String text) {}
