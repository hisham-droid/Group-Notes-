package dms;

import dao.UserDAO;
import relations.SocialTools;
import sorteddata.SortedData;
import sorteddata.SortedDataFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED theme: private / direct messages.
 * One conversation per PAIR of users, keyed the same way regardless of who sends
 * (smaller UUID first). Each conversation is a SortedData ordered by time, so
 * reading the latest k messages is O(log n + k) with getRange(..., backwards).
 * Privacy: only the two participants may read; blocked senders are refused.
 */
public final class DirectMessageTools {
	private static final Comparator<DirectMessage> BY_TIME =
			Comparator.comparingLong(DirectMessage::timestamp).thenComparing(DirectMessage::id);
	private static final Map<String, SortedData<DirectMessage>> conversations = new HashMap<>();

	private DirectMessageTools() {}

	private static String key(UUID a, UUID b) {
		return a.compareTo(b) <= 0 ? a + ":" + b : b + ":" + a;
	}

	/** @return the message, or null if a user is missing, self-message, empty text, or the receiver blocked the sender */
	public static DirectMessage send(UUID from, UUID to, String text, long timestamp) {
		if (UserDAO.getInstance().getByUUID(from) == null || UserDAO.getInstance().getByUUID(to) == null) return null;
		if (from.equals(to) || text == null || text.isBlank() || SocialTools.isBlocked(to, from)) return null;
		DirectMessage dm = new DirectMessage(UUID.randomUUID(), from, to, timestamp, text);
		conversations.computeIfAbsent(key(from, to), k -> SortedDataFactory.makeSortedData(BY_TIME)).insert(dm);
		return dm;
	}

	/** @return the conversation oldest first; empty if `viewer` is not one of the two users */
	public static List<DirectMessage> getConversation(UUID viewer, UUID other) {
		List<DirectMessage> result = new ArrayList<>();
		SortedData<DirectMessage> c = conversations.get(key(viewer, other));
		if (c != null) c.getAll().forEachRemaining(result::add);
		return result;
	}

	/** @return the newest `count` messages, newest first */
	public static List<DirectMessage> getLatest(UUID viewer, UUID other, int count) {
		List<DirectMessage> result = new ArrayList<>();
		SortedData<DirectMessage> c = conversations.get(key(viewer, other));
		if (c != null) c.getRange(null, count, true).forEachRemaining(result::add);
		return result;
	}

	/** @return everyone this user has a conversation with */
	public static List<UUID> getPartners(UUID user) {
		List<UUID> partners = new ArrayList<>();
		for (Map.Entry<String, SortedData<DirectMessage>> e : conversations.entrySet()) {
			Iterator<DirectMessage> it = e.getValue().getAll();
			if (!it.hasNext()) continue;
			DirectMessage any = it.next();
			if (any.from().equals(user)) partners.add(any.to());
			else if (any.to().equals(user)) partners.add(any.from());
		}
		return partners;
	}

	/** persistence: every direct message */
	public static List<DirectMessage> all() {
		List<DirectMessage> result = new ArrayList<>();
		for (SortedData<DirectMessage> c : conversations.values()) c.getAll().forEachRemaining(result::add);
		return result;
	}

	/** persistence: restore without checks */
	public static void restore(DirectMessage dm) {
		conversations.computeIfAbsent(key(dm.from(), dm.to()), k -> SortedDataFactory.makeSortedData(BY_TIME)).insert(dm);
	}

	public static void clear() {
		conversations.clear();
	}
}
