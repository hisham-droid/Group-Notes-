package friends;

import dao.UserDAO;
import relations.RelationStore;

import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: friend requests (pending -> accepted).
 * Two RelationStores:
 *  - requests: from -> to (pending, one direction)
 *  - friends:  stored BOTH ways (a->b and b->a) so "friends of x" is one lookup
 */
public final class FriendTools {
	private static final RelationStore<UUID, UUID> requests = new RelationStore<>();
	private static final RelationStore<UUID, UUID> friends = new RelationStore<>();

	private FriendTools() {}

	/**
	 * @return false if a user is missing, self-request, already friends, or already requested.
	 * If `to` had already asked `from`, this accepts that request instead (both wanted it).
	 */
	public static boolean sendRequest(UUID from, UUID to) {
		if (!exist(from, to) || from.equals(to) || areFriends(from, to)) return false;
		if (requests.contains(to, from)) return accept(from, to);
		return requests.add(from, to);
	}

	/** `user` accepts the request sent by `from`. */
	public static boolean accept(UUID user, UUID from) {
		if (!requests.remove(from, user)) return false;
		friends.add(user, from);
		friends.add(from, user);
		return true;
	}

	public static boolean decline(UUID user, UUID from) {
		return requests.remove(from, user);
	}

	public static boolean removeFriend(UUID user, UUID other) {
		if (!friends.remove(user, other)) return false;
		friends.remove(other, user);
		return true;
	}

	public static boolean areFriends(UUID a, UUID b) {
		return friends.contains(a, b);
	}

	public static Set<UUID> getFriends(UUID user) {
		return friends.targetsOf(user);
	}

	/** requests waiting for this user to answer */
	public static Set<UUID> getIncomingRequests(UUID user) {
		return requests.sourcesOf(user);
	}

	public static Set<UUID> getOutgoingRequests(UUID user) {
		return requests.targetsOf(user);
	}

	public static void forgetUser(UUID user) {
		requests.removeSource(user);
		requests.removeTarget(user);
		friends.removeSource(user);
		friends.removeTarget(user);
	}

	/** persistence */
	public static RelationStore<UUID, UUID> requests() { return requests; }
	public static RelationStore<UUID, UUID> friends() { return friends; }

	public static void clear() {
		requests.clear();
		friends.clear();
	}

	private static boolean exist(UUID a, UUID b) {
		return UserDAO.getInstance().getByUUID(a) != null && UserDAO.getInstance().getByUUID(b) != null;
	}
}
