package censor;

/** STRATEGY: how a banned word is replaced. */
public interface CensorStrategy {
	String replace(String word);
}
