package censor;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PREDICTED theme (week 8 has a censor refactor): replaces banned WHOLE words,
 * case-insensitively ("class" does not censor "classic"), using a strategy.
 * Censors can be chained (DECORATOR): new Censor(words2, strategy, new Censor(words1, ...)).
 */
public class Censor {
	private static final Pattern WORD = Pattern.compile("[\\p{L}\\p{N}']+");

	private final Set<String> banned = new HashSet<>();
	private final CensorStrategy strategy;
	private final Censor inner; // the censor applied first (may be null)

	public Censor(Set<String> bannedWords, CensorStrategy strategy) {
		this(bannedWords, strategy, null);
	}

	public Censor(Set<String> bannedWords, CensorStrategy strategy, Censor inner) {
		for (String w : bannedWords) banned.add(w.toLowerCase());
		this.strategy = strategy;
		this.inner = inner;
	}

	public String apply(String text) {
		if (text == null) return null;
		String input = inner == null ? text : inner.apply(text);
		StringBuilder out = new StringBuilder();
		Matcher m = WORD.matcher(input);
		int last = 0;
		while (m.find()) {
			out.append(input, last, m.start());
			String word = m.group();
			out.append(banned.contains(word.toLowerCase()) ? strategy.replace(word) : word);
			last = m.end();
		}
		return out.append(input.substring(last)).toString();
	}

	/** @return true if the text contains any banned word */
	public boolean containsBanned(String text) {
		if (text == null) return false;
		Matcher m = WORD.matcher(text);
		while (m.find()) if (banned.contains(m.group().toLowerCase())) return true;
		return inner != null && inner.containsBanned(text);
	}
}
