package censor;

/**
 * FACTORY for censor strategies:
 *  "STAR"    -> "****" (same length)
 *  "FIRST"   -> "d***" (keep the first letter)
 *  "REMOVE"  -> ""
 *  "REPLACE" -> "[censored]"
 */
public final class CensorFactory {
	private CensorFactory() {}

	public static CensorStrategy create(String name) {
		if (name == null) throw new IllegalArgumentException("strategy must not be null");
		return switch (name) {
			case "STAR" -> word -> "*".repeat(word.length());
			case "FIRST" -> word -> word.charAt(0) + "*".repeat(word.length() - 1);
			case "REMOVE" -> word -> "";
			case "REPLACE" -> word -> "[censored]";
			default -> throw new IllegalArgumentException("Unknown strategy: " + name);
		};
	}
}
