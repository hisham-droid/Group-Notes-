package bans;

import dao.UserDAO;
import dao.model.User;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: temporary bans (suspensions).
 * One number per banned user: the time the ban ends. isBanned is O(1).
 */
public final class BanTools {
	private static final Map<UUID, Long> bannedUntil = new HashMap<>();

	private BanTools() {}

	/**
	 * Admin only; admins cannot ban themselves or other admins.
	 * Banning an already-banned user replaces the end time.
	 */
	public static boolean ban(UUID admin, UUID user, long untilTimestamp) {
		User a = UserDAO.getInstance().getByUUID(admin);
		User target = UserDAO.getInstance().getByUUID(user);
		if (a == null || target == null || a.role() != User.Role.Admin || target.role() == User.Role.Admin) return false;
		bannedUntil.put(user, untilTimestamp);
		return true;
	}

	/** @return false if not an admin or the user was not banned */
	public static boolean unban(UUID admin, UUID user) {
		User a = UserDAO.getInstance().getByUUID(admin);
		if (a == null || a.role() != User.Role.Admin) return false;
		return bannedUntil.remove(user) != null;
	}

	/** @return true while now < end of ban */
	public static boolean isBanned(UUID user, long now) {
		Long until = bannedUntil.get(user);
		return until != null && now < until;
	}

	public static void forgetUser(UUID user) {
		bannedUntil.remove(user);
	}

	/** persistence */
	public static Map<UUID, Long> all() {
		return Collections.unmodifiableMap(bannedUntil);
	}

	public static void restore(UUID user, long until) {
		bannedUntil.put(user, until);
	}

	public static void clear() {
		bannedUntil.clear();
	}
}
