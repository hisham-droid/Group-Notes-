package access;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Post;
import dao.model.User;
import relations.RelationStore;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED theme: private / invite-only posts (an access control list per post).
 * A post is public unless marked private. A private post can be seen by its author,
 * admins, and invited users. invites is a RelationStore post -> user (O(1) checks).
 */
public final class AccessTools {
	private static final Set<UUID> privatePosts = new HashSet<>();
	private static final RelationStore<UUID, UUID> invites = new RelationStore<>(); // post -> user

	private AccessTools() {}

	/** Author or Admin. */
	public static boolean setPrivate(UUID post, UUID user, boolean isPrivate) {
		if (!isOwnerOrAdmin(post, user)) return false;
		if (isPrivate) privatePosts.add(post);
		else privatePosts.remove(post);
		return true;
	}

	/** Author or Admin invites someone. @return false if not allowed, user missing, or already invited */
	public static boolean invite(UUID post, UUID owner, UUID guest) {
		if (!isOwnerOrAdmin(post, owner) || UserDAO.getInstance().getByUUID(guest) == null) return false;
		return invites.add(post, guest);
	}

	public static boolean uninvite(UUID post, UUID owner, UUID guest) {
		return isOwnerOrAdmin(post, owner) && invites.remove(post, guest);
	}

	/** @return true if this user (null = guest) may read the post */
	public static boolean canView(UUID post, UUID user) {
		Post p = post == null ? null : PostDAO.getInstance().get(new Post(post));
		if (p == null) return false;
		if (!privatePosts.contains(post)) return true;
		if (user == null) return false;
		User u = UserDAO.getInstance().getByUUID(user);
		if (u == null) return false;
		return u.role() == User.Role.Admin || u.id().equals(p.poster) || invites.contains(post, user);
	}

	public static boolean isPrivate(UUID post) {
		return privatePosts.contains(post);
	}

	/** persistence */
	public static Set<UUID> privatePosts() { return Collections.unmodifiableSet(privatePosts); }
	public static RelationStore<UUID, UUID> invites() { return invites; }
	public static void restorePrivate(UUID post) { privatePosts.add(post); }

	public static void clear() {
		privatePosts.clear();
		invites.clear();
	}

	private static boolean isOwnerOrAdmin(UUID post, UUID user) {
		Post p = post == null ? null : PostDAO.getInstance().get(new Post(post));
		User u = UserDAO.getInstance().getByUUID(user);
		return p != null && u != null && (u.role() == User.Role.Admin || u.id().equals(p.poster));
	}
}
