package readtracking;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Post;
import dao.model.User;
import queries.MessageQueries;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: read / unread tracking.
 * We store ONE number per (user, post): the timestamp up to which they have read.
 * Unread = messages with a later timestamp, counted in O(log n) with the tree's rank
 * (MessageQueries.countMessagesBetween), never by scanning.
 */
public final class ReadTracker {
	private static final Map<UUID, Map<UUID, Long>> lastRead = new HashMap<>(); // user -> (post -> timestamp)

	private ReadTracker() {}

	/** Marks everything up to `timestamp` as read. Never moves backwards. */
	public static boolean markRead(UUID user, UUID post, long timestamp) {
		if (UserDAO.getInstance().getByUUID(user) == null || PostDAO.getInstance().get(new Post(post)) == null) return false;
		lastRead.computeIfAbsent(user, k -> new HashMap<>()).merge(post, timestamp, Math::max);
		return true;
	}

	/** @return the read-up-to timestamp, or Long.MIN_VALUE if never read */
	public static long getLastRead(UUID user, UUID post) {
		return lastRead.getOrDefault(user, Map.of()).getOrDefault(post, Long.MIN_VALUE);
	}

	/** @return number of messages the user can see that are newer than what they have read */
	public static int getUnreadCount(UUID user, UUID post) {
		User u = UserDAO.getInstance().getByUUID(user);
		if (u == null) return 0;
		long from = getLastRead(user, post);
		if (from == Long.MAX_VALUE) return 0;
		long start = from == Long.MIN_VALUE ? Long.MIN_VALUE : from + 1;
		return MessageQueries.countMessagesBetween(post, start, Long.MAX_VALUE, u.role() == User.Role.Admin);
	}

	public static void forgetUser(UUID user) {
		lastRead.remove(user);
	}

	/** persistence: user -> post -> timestamp (read-only) */
	public static Map<UUID, Map<UUID, Long>> all() {
		return Collections.unmodifiableMap(lastRead);
	}

	/** persistence: restore without existence checks */
	public static void restore(UUID user, UUID post, long timestamp) {
		lastRead.computeIfAbsent(user, k -> new HashMap<>()).merge(post, timestamp, Math::max);
	}

	public static void clear() {
		lastRead.clear();
	}
}
