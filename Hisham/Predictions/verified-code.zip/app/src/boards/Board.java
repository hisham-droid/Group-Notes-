package boards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED theme: categories / boards / subforums (COMPOSITE pattern).
 * A board holds posts AND sub-boards; "all posts" and "count" work the same on a
 * leaf board and on a whole tree of boards.
 */
public class Board {
	private final String name;
	private final List<Board> children = new ArrayList<>();
	private final Set<UUID> posts = new LinkedHashSet<>();

	public Board(String name) {
		this.name = name;
	}

	public Board addChild(Board child) {
		children.add(child);
		return child;
	}

	public boolean addPost(UUID post) { return posts.add(post); }
	public boolean removePost(UUID post) { return posts.remove(post); }
	public String getName() { return name; }
	/** posts directly on this board (not sub-boards) */
	public Set<UUID> getOwnPosts() { return Collections.unmodifiableSet(posts); }
	public List<Board> getChildren() { return Collections.unmodifiableList(children); }

	/** posts on this board and every board below it */
	public List<UUID> getAllPosts() {
		List<UUID> result = new ArrayList<>(posts);
		for (Board child : children) result.addAll(child.getAllPosts());
		return result;
	}

	public int countPosts() {
		int total = posts.size();
		for (Board child : children) total += child.countPosts();
		return total;
	}

	/** @return the board with this name in the subtree (depth-first), or null */
	public Board find(String boardName) {
		if (name.equalsIgnoreCase(boardName)) return this;
		for (Board child : children) {
			Board found = child.find(boardName);
			if (found != null) return found;
		}
		return null;
	}

	/** Moves a post from wherever it is in this subtree to `target`. */
	public boolean movePost(UUID post, Board target) {
		if (!removeFromSubtree(post)) return false;
		return target.addPost(post);
	}

	private boolean removeFromSubtree(UUID post) {
		if (posts.remove(post)) return true;
		for (Board child : children) if (child.removeFromSubtree(post)) return true;
		return false;
	}
}
