package boards;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Singleton home for the board tree (so it can be saved / loaded).
 * Board names are assumed unique (find() searches by name).
 */
public final class BoardTools {
	public static final String ROOT_NAME = "All";
	private static Board root = new Board(ROOT_NAME);

	private BoardTools() {}

	public static Board root() {
		return root;
	}

	/** @return the new board, or null if the parent is missing or the name is taken */
	public static Board createBoard(String name, String parentName) {
		Board parent = root.find(parentName);
		if (parent == null || name == null || name.isBlank() || root.find(name) != null) return null;
		return parent.addChild(new Board(name));
	}

	/** persistence: (board, parent) for every board except the root, parents before children */
	public static List<String[]> boardRows() {
		List<String[]> rows = new ArrayList<>();
		addRows(root, rows);
		return rows;
	}

	private static void addRows(Board board, List<String[]> rows) {
		for (Board child : board.getChildren()) {
			rows.add(new String[] {child.getName(), board.getName()});
			addRows(child, rows);
		}
	}

	/** persistence: (board, post) for every post placed on a board */
	public static List<String[]> postRows() {
		List<String[]> rows = new ArrayList<>();
		addPostRows(root, rows);
		return rows;
	}

	private static void addPostRows(Board board, List<String[]> rows) {
		for (UUID post : board.getOwnPosts()) rows.add(new String[] {board.getName(), post.toString()});
		for (Board child : board.getChildren()) addPostRows(child, rows);
	}

	public static void clear() {
		root = new Board(ROOT_NAME);
	}
}
