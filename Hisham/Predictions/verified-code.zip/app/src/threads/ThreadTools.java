package threads;

import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED theme: replies to a specific message (nested threads) and quoting.
 * The reply is a normal Message in the same post (so everything else keeps working);
 * we only store the parent/child links:  child -> parent  and  parent -> children.
 * The messages form a TREE; getThread walks it depth-first (pre-order), like a forum view.
 */
public final class ThreadTools {
	private static final Map<UUID, UUID> parentOf = new HashMap<>();
	private static final Map<UUID, List<UUID>> childrenOf = new HashMap<>();

	private ThreadTools() {}

	/** One line of a thread view: the message and how deep it is (0 = the root you asked for). */
	public record ThreadEntry(Message message, int depth) {}

	/** @return the new reply, or null if the parent/user is missing or text is null */
	public static Message reply(UUID parent, UUID user, String text, long timestamp) {
		Message target = MessageIndex.getInstance().get(parent);
		if (target == null || text == null || UserDAO.getInstance().getByUUID(user) == null) return null;
		Post post = MessageIndex.getInstance().getPostOf(target);
		Message reply = new Message(UUID.randomUUID(), user, target.thread(), timestamp, text);
		post.messages.insert(reply);
		link(parent, reply.id());
		return reply;
	}

	/** persistence + reply(): record that child replies to parent */
	public static void link(UUID parent, UUID child) {
		parentOf.put(child, parent);
		childrenOf.computeIfAbsent(parent, k -> new ArrayList<>()).add(child);
	}

	/** @return the message this one replies to, or null for a top-level message */
	public static UUID getParent(UUID message) {
		return parentOf.get(message);
	}

	/** @return direct replies, oldest first (deleted ones skipped) */
	public static List<Message> getReplies(UUID message) {
		List<Message> result = new ArrayList<>();
		for (UUID id : childrenOf.getOrDefault(message, List.of())) {
			Message m = MessageIndex.getInstance().get(id);
			if (m != null) result.add(m);
		}
		result.sort(Comparator.comparingLong(Message::timestamp));
		return result;
	}

	/** @return the message and all replies below it, depth-first (pre-order), oldest replies first */
	public static List<ThreadEntry> getThread(UUID root) {
		List<ThreadEntry> result = new ArrayList<>();
		Message m = MessageIndex.getInstance().get(root);
		if (m != null) walk(m, 0, result);
		return result;
	}

	private static void walk(Message message, int depth, List<ThreadEntry> out) {
		out.add(new ThreadEntry(message, depth));
		for (Message child : getReplies(message.id())) walk(child, depth + 1, out);
	}

	/** @return how many replies deep this message is (0 = top level) */
	public static int getDepth(UUID message) {
		int depth = 0;
		for (UUID p = parentOf.get(message); p != null; p = parentOf.get(p)) depth++;
		return depth;
	}

	/** @return the text of a reply that quotes the message: "> original\n\nyour text" */
	public static String quote(UUID message, String yourText) {
		Message m = MessageIndex.getInstance().get(message);
		if (m == null) return yourText;
		StringBuilder quoted = new StringBuilder();
		for (String line : m.message().split("\n", -1)) quoted.append("> ").append(line).append('\n');
		return quoted.append('\n').append(yourText).toString();
	}

	/** persistence: child -> parent */
	public static Map<UUID, UUID> allLinks() {
		return java.util.Collections.unmodifiableMap(parentOf);
	}

	public static void clear() {
		parentOf.clear();
		childrenOf.clear();
	}
}
