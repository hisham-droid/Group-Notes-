package persistentdata;

import persistentdata.formatted.FormattedFactory;
import persistentdata.formatted.FormattedReader;
import persistentdata.formatted.FormattedWriter;
import persistentdata.io.IOFactory;
import persistentdata.serialization.Serializer;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Iterator;
import java.util.function.Consumer;

/**
 * Moves objects of type T to/from one file:  IO  <->  format (e.g. CSV)  <->  serializer.
 * HACKATHON refactor (Task 3 "code smells"):
 *  - removed unused static UserDAO/PostDAO fields (dead code + hidden coupling)
 *  - try-with-resources: the file is closed even when an exception is thrown
 *  - putHeader()/putFooter() are now actually called (needed by formats like JSON)
 *  - the custom AddToDAO interface is replaced by the standard java.util.function.Consumer
 */
public class DataPipeline<T, S> {
	private final IOFactory ioFactory;
	private final FormattedFactory<S> formattedFactory;
	private final Serializer<T, S> serializer;
	private final String filename;

	public DataPipeline(IOFactory ioFactory, FormattedFactory<S> formattedFactory, Serializer<T, S> serializer, String filename) {
		this.ioFactory = ioFactory;
		this.formattedFactory = formattedFactory;
		this.serializer = serializer;
		this.filename = filename;
	}

	/** Writes every element of the iterator to this pipeline's file (replacing it). */
	public void writeFrom(Iterator<T> iterator) {
		try (Writer writer = ioFactory.writer(filename)) {
			if (writer == null) throw new PersistentDataException("Cannot open " + filename + " for writing");
			FormattedWriter<S> formattedWriter = formattedFactory.writer(writer);
			formattedWriter.putHeader();
			while (iterator.hasNext()) {
				formattedWriter.putNext(serializer.serialize(iterator.next()));
			}
			formattedWriter.putFooter();
		} catch (IOException e) {
			throw new PersistentDataException(e.getMessage());
		}
	}

	/** Reads every entry in this pipeline's file and hands each object to the callback. */
	public void readTo(Consumer<T> callback) {
		Reader reader = ioFactory.reader(filename);
		if (reader == null) return; // file does not exist yet: nothing to load
		try (reader) {
			FormattedReader<S> formattedReader = formattedFactory.reader(reader);
			while (formattedReader.hasNext()) {
				callback.accept(serializer.deserialize(formattedReader.getNext()));
			}
		} catch (IOException e) {
			throw new PersistentDataException(e.getMessage());
		}
	}
}
