package persistentdata;

import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.Report;
import moderation.ReportStore;
import persistentdata.formatted.CSVFormat;
import persistentdata.features.Features;
import persistentdata.features.PersistentFeature;
import persistentdata.features.RowSerializer;
import persistentdata.formatted.CSVFormattedFactory;
import persistentdata.io.ComputerIOFactory;
import persistentdata.io.IOFactory;
import persistentdata.serialization.HiddenMessage;
import persistentdata.serialization.HiddenMessageSerializer;
import persistentdata.serialization.MessageSerializer;
import persistentdata.serialization.PostSerializer;
import persistentdata.serialization.ReportSerializer;
import persistentdata.serialization.Serializer;
import persistentdata.serialization.UserSerializer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Saves and loads the whole application.
 * HACKATHON (Task 3): adds reports and hidden flags, and refactors:
 *  - column counts are named constants (no magic numbers)
 *  - one helper builds every pipeline (no copy-pasted constructor calls)
 *  - the IOFactory can be injected, so tests can save to memory or a temp folder
 *  - load order is documented, because later files refer to earlier ones
 */
public class DataManager {
	private static final int USER_COLUMNS = 4;    // id, role, username, password
	private static final int POST_COLUMNS = 3;    // id, poster, topic
	private static final int MESSAGE_COLUMNS = 5; // id, poster, thread, timestamp, text

	private static DataManager instance;

	public static DataManager getInstance() {
		if (instance == null) instance = new DataManager(new ComputerIOFactory());
		return instance;
	}

	private final DataPipeline<User, String[]> userPipeline;
	private final DataPipeline<Post, String[]> postPipeline;
	private final DataPipeline<Message, String[]> messagePipeline;
	private final DataPipeline<Report, String[]> reportPipeline;
	private final DataPipeline<HiddenMessage, String[]> hiddenPipeline;

	// every other feature: one pipeline each, built from the Features list
	private final List<PersistentFeature> features = Features.all();
	private final List<DataPipeline<String[], String[]>> featurePipelines = new ArrayList<>();

	private final UserDAO users = UserDAO.getInstance();
	private final PostDAO posts = PostDAO.getInstance();
	private final ReportStore reports = ReportStore.getInstance();

	/** @param io where files live (public so tests can pass an in-memory implementation) */
	public DataManager(IOFactory io) {
		userPipeline = pipeline(io, new UserSerializer(), USER_COLUMNS, "users");
		postPipeline = pipeline(io, new PostSerializer(), POST_COLUMNS, "posts");
		messagePipeline = pipeline(io, new MessageSerializer(), MESSAGE_COLUMNS, "messages");
		reportPipeline = pipeline(io, new ReportSerializer(), ReportSerializer.COLUMNS, "reports");
		hiddenPipeline = pipeline(io, new HiddenMessageSerializer(), HiddenMessageSerializer.COLUMNS, "hidden");
		for (PersistentFeature feature : features) {
			featurePipelines.add(pipeline(io, new RowSerializer(), feature.columns(), feature.fileName()));
		}
	}

	private static <T> DataPipeline<T, String[]> pipeline(IOFactory io, Serializer<T, String[]> serializer, int columns, String file) {
		return new DataPipeline<>(io, new CSVFormattedFactory(new CSVFormat(columns)), serializer, file);
	}

	/**
	 * Load order matters: users and posts first, then messages (they need their post),
	 * then hidden flags (need the message's post), then reports.
	 */
	public void readAll() {
		users.clear();
		posts.clear();
		reports.clear();
		MessageIndex.getInstance().clear(); // so reloaded messages count as new (rebuilds derived data like mentions)
		mentions.MentionTools.clear();      // derived data: rebuilt from the messages as they load
		search.SearchTools.clear();
		userPipeline.readTo(users::add);
		postPipeline.readTo(posts::add);
		messagePipeline.readTo(this::restoreMessage);
		hiddenPipeline.readTo(this::restoreHidden);
		reportPipeline.readTo(reports::add);
		for (int i = 0; i < features.size(); i++) {
			PersistentFeature feature = features.get(i);
			feature.clear();
			featurePipelines.get(i).readTo(feature::restore);
			feature.afterLoad();
		}
	}

	public void writeAll() {
		userPipeline.writeFrom(users.getAll());
		postPipeline.writeFrom(posts.getAll());
		messagePipeline.writeFrom(posts.getAllMessages());
		hiddenPipeline.writeFrom(allHiddenMessages());
		reportPipeline.writeFrom(reports.getAllReports());
		for (int i = 0; i < features.size(); i++) {
			featurePipelines.get(i).writeFrom(features.get(i).rows());
		}
	}

	private void restoreMessage(Message message) {
		Post post = posts.get(new Post(message.thread()));
		if (post != null) post.messages.insert(message); // skip orphans instead of crashing
	}

	private void restoreHidden(HiddenMessage hidden) {
		Post post = posts.get(new Post(hidden.post()));
		// messages were loaded first, so the index already knows this message (O(1))
		Message message = MessageIndex.getInstance().get(hidden.message());
		if (post != null && message != null) post.setHidden(message, true);
	}

	private Iterator<HiddenMessage> allHiddenMessages() {
		List<HiddenMessage> result = new ArrayList<>();
		for (Iterator<Post> it = posts.getAll(); it.hasNext(); ) {
			Post post = it.next();
			for (UUID messageId : post.getHiddenMessageIds()) {
				result.add(new HiddenMessage(messageId, post.id));
			}
		}
		return result.iterator();
	}
}
