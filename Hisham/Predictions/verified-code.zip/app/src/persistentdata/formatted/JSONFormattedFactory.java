package persistentdata.formatted;

import java.io.Reader;
import java.io.Writer;

/**
 * HACKATHON (Task 3 alternative): JSON instead of CSV, with NO library.
 * Because DataPipeline only talks to FormattedFactory<String[]>, swapping CSV for JSON
 * is ONE line in DataManager:  new CSVFormattedFactory(new CSVFormat(n))  ->  new JSONFormattedFactory(n)
 * File shape (an array of rows, each row an array of strings):
 *   [
 *   ["id1","member","alice","pw"],
 *   ["id2","admin","bob","pw2"]
 *   ]
 */
public class JSONFormattedFactory implements FormattedFactory<String[]> {
	private final int columns;

	public JSONFormattedFactory(int columns) {
		this.columns = columns;
	}

	@Override
	public FormattedWriter<String[]> writer(Writer documentWriter) {
		return new JSONWriter(documentWriter, columns);
	}

	@Override
	public FormattedReader<String[]> reader(Reader documentReader) {
		return new JSONReader(documentReader, columns);
	}
}
