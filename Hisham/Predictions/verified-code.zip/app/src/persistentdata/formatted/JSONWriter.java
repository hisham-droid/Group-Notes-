package persistentdata.formatted;

import persistentdata.PersistentDataException;

import java.io.IOException;
import java.io.Writer;

/**
 * HACKATHON: writes rows as a JSON array of string arrays.
 * putHeader writes "[", putFooter writes "]" (this is why DataPipeline must call them).
 */
public class JSONWriter implements FormattedWriter<String[]> {
	private final Writer writer;
	private final int columns;
	private boolean firstRow = true;

	public JSONWriter(Writer writer, int columns) {
		this.writer = writer;
		this.columns = columns;
	}

	@Override
	public void putHeader() {
		write("[");
	}

	@Override
	public void putNext(String[] row) {
		if (row.length != columns) throw new PersistentDataException("Expected " + columns + " columns, got " + row.length);
		StringBuilder line = new StringBuilder(firstRow ? "\n[" : ",\n[");
		firstRow = false;
		for (int i = 0; i < row.length; i++) {
			if (i > 0) line.append(',');
			line.append(quote(row[i]));
		}
		write(line.append(']').toString());
	}

	@Override
	public void putFooter() {
		write("\n]\n");
	}

	// JSON string escaping: backslash, quote and control characters
	static String quote(String value) {
		StringBuilder out = new StringBuilder("\"");
		for (char c : value.toCharArray()) {
			switch (c) {
				case '"' -> out.append("\\\"");
				case '\\' -> out.append("\\\\");
				case '\n' -> out.append("\\n");
				case '\r' -> out.append("\\r");
				case '\t' -> out.append("\\t");
				default -> {
					if (c < 0x20) out.append(String.format("\\u%04x", (int) c));
					else out.append(c);
				}
			}
		}
		return out.append('"').toString();
	}

	private void write(String text) {
		try {
			writer.write(text);
		} catch (IOException e) {
			throw new PersistentDataException(e.getMessage());
		}
	}
}
