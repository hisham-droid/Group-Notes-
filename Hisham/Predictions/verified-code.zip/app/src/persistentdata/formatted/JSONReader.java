package persistentdata.formatted;

import persistentdata.PersistentDataException;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * HACKATHON: reads the format written by JSONWriter: [ [ "a", "b" ], ... ]
 * A tiny hand-written parser (no libraries). Whitespace between tokens is ignored.
 */
public class JSONReader implements FormattedReader<String[]> {
	private final PushbackReader reader;
	private final int columns;
	private boolean started = false; // have we consumed the outer '[' yet?
	private boolean finished = false; // have we seen the outer ']'?

	public JSONReader(Reader reader, int columns) {
		this.reader = new PushbackReader(reader);
		this.columns = columns;
	}

	@Override
	public boolean hasNext() {
		if (finished) return false;
		if (!started) {
			int c = skipWhitespace();
			if (c == -1) { finished = true; return false; } // empty file = no rows
			expect(c, '[');
			started = true;
		}
		int c = skipWhitespace();
		if (c == ',') c = skipWhitespace();
		if (c == ']') { finished = true; return false; }
		if (c == -1) throw new PersistentDataException("Unexpected end of JSON");
		unread(c);
		return true;
	}

	@Override
	public String[] getNext() {
		if (!hasNext()) throw new PersistentDataException("No more rows");
		expect(skipWhitespace(), '[');
		List<String> row = new ArrayList<>();
		int c = skipWhitespace();
		while (c != ']') {
			if (c == ',') c = skipWhitespace();
			expect(c, '"');
			row.add(readString());
			c = skipWhitespace();
		}
		if (row.size() != columns) throw new PersistentDataException("Expected " + columns + " columns, got " + row.size());
		return row.toArray(new String[0]);
	}

	// reads the rest of a string after its opening quote, undoing the escapes
	private String readString() {
		StringBuilder out = new StringBuilder();
		while (true) {
			int c = read();
			if (c == -1) throw new PersistentDataException("Unterminated string");
			if (c == '"') return out.toString();
			if (c != '\\') { out.append((char) c); continue; }
			int e = read();
			switch (e) {
				case '"' -> out.append('"');
				case '\\' -> out.append('\\');
				case '/' -> out.append('/');
				case 'n' -> out.append('\n');
				case 'r' -> out.append('\r');
				case 't' -> out.append('\t');
				case 'b' -> out.append('\b');
				case 'f' -> out.append('\f');
				case 'u' -> {
					char[] hex = new char[4];
					for (int i = 0; i < 4; i++) hex[i] = (char) read();
					out.append((char) Integer.parseInt(new String(hex), 16));
				}
				default -> throw new PersistentDataException("Bad escape \\" + (char) e);
			}
		}
	}

	private int skipWhitespace() {
		int c;
		do { c = read(); } while (c == ' ' || c == '\n' || c == '\r' || c == '\t');
		return c;
	}

	private void expect(int actual, char expected) {
		if (actual != expected) throw new PersistentDataException("Expected '" + expected + "' but found '" + (char) actual + "'");
	}

	private int read() {
		try { return reader.read(); } catch (IOException e) { throw new PersistentDataException(e.getMessage()); }
	}

	private void unread(int c) {
		try { reader.unread(c); } catch (IOException e) { throw new PersistentDataException(e.getMessage()); }
	}
}
