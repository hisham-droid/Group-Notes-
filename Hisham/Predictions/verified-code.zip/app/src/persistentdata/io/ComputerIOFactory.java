package persistentdata.io;

import java.io.*;

/**
 * Reads/writes text files on a desktop OS.
 * HACKATHON changes:
 *  - removed the "if (System.currentTimeMillis() > ...) throw" check. It made every
 *    read return null after Dec 2025, so NOTHING was ever loaded.
 *  - the folder is created if missing (FileWriter fails if "saved/" does not exist)
 *  - the folder is a constructor parameter so tests can use a temporary folder
 */
public class ComputerIOFactory implements IOFactory {
	private static final String DEFAULT_FOLDER = "saved";
	private static final String FILE_EXTENSION = ".txt";

	private final File folder;

	public ComputerIOFactory() {
		this(new File(DEFAULT_FOLDER));
	}

	public ComputerIOFactory(File folder) {
		this.folder = folder;
	}

	private File fileFor(String name) {
		return new File(folder, name + FILE_EXTENSION);
	}

	@Override
	public Writer writer(String filename) {
		try {
			if (!folder.exists() && !folder.mkdirs()) return null;
			return new FileWriter(fileFor(filename));
		} catch (IOException ignored) {
			return null;
		}
	}

	@Override
	public Reader reader(String filename) {
		try {
			return new FileReader(fileFor(filename));
		} catch (IOException ignored) {
			return null; // no file yet = nothing saved yet
		}
	}
}
