package persistentdata.serialization;

import dao.model.Message;

import java.util.UUID;

/**
 * Converts between Messages and String[]: (UUID, poster, thread, timestamp, message).
 * HACKATHON: poster may be null (e.g. deleted user, test data), written as an empty field.
 */
public class MessageSerializer implements Serializer<Message, String[]> {

	@Override
	public String[] serialize(Message object) {
		return new String[] {object.id().toString(), Nullable.write(object.poster()), object.thread().toString(),
				String.valueOf(object.timestamp()), Nullable.write(object.message())};
	}

	@Override
	public Message deserialize(String[] data) {
		return new Message(UUID.fromString(data[0]), Nullable.readUUID(data[1]), UUID.fromString(data[2]),
				Long.parseLong(data[3]), Nullable.readString(data[4]));
	}
}
