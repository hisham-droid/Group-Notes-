package persistentdata.serialization;

import moderation.Report;

import java.util.UUID;

/**
 * HACKATHON (Task 3): one CSV row per active report.
 * Schema (3 columns): messageUUID, userUUID, timestamp (UNIX ms as a decimal string)
 * Plain strings and numbers only, so any language can read it.
 */
public class ReportSerializer implements Serializer<Report, String[]> {
	public static final int COLUMNS = 3;

	@Override
	public String[] serialize(Report report) {
		return new String[] {report.message().toString(), report.user().toString(), Long.toString(report.timestamp())};
	}

	@Override
	public Report deserialize(String[] data) {
		return new Report(UUID.fromString(data[0]), UUID.fromString(data[1]), Long.parseLong(data[2]));
	}
}
