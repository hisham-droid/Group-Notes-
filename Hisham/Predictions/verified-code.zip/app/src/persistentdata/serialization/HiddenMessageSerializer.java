package persistentdata.serialization;

import java.util.UUID;

/**
 * HACKATHON (Task 3): one CSV row per hidden message.
 * Schema (2 columns): messageUUID, postUUID
 * A separate file (instead of a 6th "hidden" column in messages.txt) means the
 * existing messages file format does not change, so other programs reading it keep working.
 */
public class HiddenMessageSerializer implements Serializer<HiddenMessage, String[]> {
	public static final int COLUMNS = 2;

	@Override
	public String[] serialize(HiddenMessage hidden) {
		return new String[] {hidden.message().toString(), hidden.post().toString()};
	}

	@Override
	public HiddenMessage deserialize(String[] data) {
		return new HiddenMessage(UUID.fromString(data[0]), UUID.fromString(data[1]));
	}
}
