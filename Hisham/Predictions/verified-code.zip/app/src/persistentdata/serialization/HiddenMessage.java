package persistentdata.serialization;

import java.util.UUID;

/**
 * HACKATHON (Task 3): "this message is hidden". We store the post id too, so on
 * load we can find the post in O(log n) without scanning for the message.
 * @param message the hidden message's UUID
 * @param post    the UUID of the post that message belongs to
 */
public record HiddenMessage(UUID message, UUID post) {}
