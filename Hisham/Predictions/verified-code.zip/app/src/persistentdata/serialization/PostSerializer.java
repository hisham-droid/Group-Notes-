package persistentdata.serialization;
import dao.model.Post;

import java.util.UUID;

/**
 * Converts between Posts and String[]: (UUID, poster, topic).
 * HACKATHON: poster/topic may be null, written as an empty field.
 */
public class PostSerializer implements Serializer<Post, String[]> {

	@Override
	public String[] serialize(Post object) {
		return new String[] {object.id.toString(), Nullable.write(object.poster), Nullable.write(object.topic)};
	}

	@Override
	public Post deserialize(String[] data) {
		return new Post(UUID.fromString(data[0]), Nullable.readUUID(data[1]), Nullable.readString(data[2]));
	}
}
