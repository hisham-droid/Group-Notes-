package persistentdata.serialization;

import java.util.UUID;

/**
 * HACKATHON (Task 3 refactor): shared null handling for serializers.
 * Posts made with new Post(uuid) have a null poster and topic, and test messages often
 * have a null poster: the original serializers crashed on those with NullPointerException.
 * Convention: null is written as an empty field.
 */
final class Nullable {
	private Nullable() {}

	static String write(Object value) {
		return value == null ? "" : value.toString();
	}

	static UUID readUUID(String field) {
		return field.isEmpty() ? null : UUID.fromString(field);
	}

	static String readString(String field) {
		return field.isEmpty() ? null : field;
	}
}
