package persistentdata.features;

import java.util.Iterator;

/**
 * HACKATHON (Task 3 refactor): one saved file = one feature.
 * A feature turns its state into rows of strings and back. DataManager loops over a
 * list of features, so adding persistence for a new feature is ONE new class + ONE line
 * in the list, instead of a new serializer, pipeline field, read call and write call.
 * (Strategy pattern: each feature is a strategy for saving one kind of data.)
 */
public interface PersistentFeature {
	/** file name without extension, e.g. "votes" */
	String fileName();

	/** number of columns in every row */
	int columns();

	/** the rows to save */
	Iterator<String[]> rows();

	/** rebuild state from one saved row */
	void restore(String[] row);

	/** empty the feature before loading */
	void clear();

	/** called after all rows were restored (for features that need every row first) */
	default void afterLoad() {}
}
