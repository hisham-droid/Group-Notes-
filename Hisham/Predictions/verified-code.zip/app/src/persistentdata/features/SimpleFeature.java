package persistentdata.features;

import java.util.Iterator;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * A feature built from three lambdas (rows / restore / clear), for the small cases.
 * Keeps the feature list in Features.java short and readable.
 */
public class SimpleFeature implements PersistentFeature {
	private final String fileName;
	private final int columns;
	private final Supplier<Iterator<String[]>> rows;
	private final Consumer<String[]> restore;
	private final Runnable clear;
	private final Runnable afterLoad;

	public SimpleFeature(String fileName, int columns, Supplier<Iterator<String[]>> rows, Consumer<String[]> restore, Runnable clear) {
		this(fileName, columns, rows, restore, clear, () -> {});
	}

	public SimpleFeature(String fileName, int columns, Supplier<Iterator<String[]>> rows, Consumer<String[]> restore, Runnable clear, Runnable afterLoad) {
		this.fileName = fileName;
		this.columns = columns;
		this.rows = rows;
		this.restore = restore;
		this.clear = clear;
		this.afterLoad = afterLoad;
	}

	@Override public String fileName() { return fileName; }
	@Override public int columns() { return columns; }
	@Override public Iterator<String[]> rows() { return rows.get(); }
	@Override public void restore(String[] row) { restore.accept(row); }
	@Override public void clear() { clear.run(); }
	@Override public void afterLoad() { afterLoad.run(); }
}
