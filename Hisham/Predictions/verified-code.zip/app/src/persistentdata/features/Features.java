package persistentdata.features;

import accounts.Permissions;
import audit.AdminActions;
import audit.AuditEntry;
import bans.BanTools;
import boards.Board;
import boards.BoardTools;
import dao.MessageIndex;
import dao.PostDAO;
import dao.model.Message;
import dao.model.Post;
import dms.DirectMessage;
import dms.DirectMessageTools;
import edits.Edit;
import edits.EditTools;
import friends.FriendTools;
import notifications.NotificationTools;
import polls.Poll;
import polls.PollTools;
import reactions.MessageReactions;
import reactions.Reaction;
import reactions.ReactionStore;
import reactions.ReactionType;
import readtracking.ReadTracker;
import relations.SocialTools;
import scheduled.ScheduledMessages;
import tags.TagTools;
import votes.MessageVotes;
import votes.VoteTools;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.function.Function;

/**
 * HACKATHON (Task 3): every predicted feature's persistence, in LOAD ORDER.
 * Each file is plain CSV of strings/numbers (portable). Enums are saved by name().
 * NOT saved on purpose: notifications and rate-limit/duplicate windows (temporary),
 * mentions and the search index (rebuilt automatically when messages load).
 */
public final class Features {
	private Features() {}

	private static final Function<String, UUID> ID = UUID::fromString;

	public static List<PersistentFeature> all() {
		List<PersistentFeature> f = new ArrayList<>();

		// ---- message flags (need posts + messages, which DataManager loads first) ----
		f.add(new SimpleFeature("deleted", 2, () -> postFlagRows(Post::getDeletedMessageIds),
				row -> withMessage(row, (post, m) -> post.setDeleted(m, true)), () -> {}));
		f.add(new SimpleFeature("pinned", 2, Features::pinnedRows,
				row -> withMessage(row, (post, m) -> post.setPinned(m, true)), () -> {}));
		f.add(new SimpleFeature("locked", 1, Features::lockedRows,
				row -> { Post p = PostDAO.getInstance().get(new Post(ID.apply(row[0]))); if (p != null) p.setLocked(true); }, () -> {}));

		// ---- per-message, per-user data ----
		f.add(new SimpleFeature("reactions", 4, Features::reactionRows,
				row -> ReactionStore.getInstance().forMessage(ID.apply(row[0]))
						.add(new Reaction(ID.apply(row[0]), ID.apply(row[1]), ReactionType.valueOf(row[2]), Long.parseLong(row[3]))),
				ReactionStore.getInstance()::clear));
		f.add(new SimpleFeature("votes", 4, Features::voteRows,
				row -> VoteTools.restore(ID.apply(row[0]), ID.apply(row[1]), Integer.parseInt(row[2]), Long.parseLong(row[3])),
				VoteTools::clear));
		f.add(new SimpleFeature("edits", 4, Features::editRows,
				row -> EditTools.restore(ID.apply(row[0]), new Edit(row[2], Long.parseLong(row[3]))), EditTools::clear));

		// ---- relations: one generic class for all of them ----
		f.add(new RelationFeature<>("follows", SocialTools.follows(), ID, ID));
		f.add(new RelationFeature<>("blocks", SocialTools.blocks(), ID, ID));
		f.add(new RelationFeature<>("bookmarks", SocialTools.bookmarks(), ID, ID));
		f.add(new RelationFeature<>("postlikes", SocialTools.postLikes(), ID, ID));
		f.add(new RelationFeature<>("subscriptions", NotificationTools.subscriptions(), ID, ID));
		f.add(new RelationFeature<>("friendrequests", FriendTools.requests(), ID, ID));
		f.add(new RelationFeature<>("friends", FriendTools.friends(), ID, ID));
		f.add(new RelationFeature<>("tags", TagTools.store(), ID, s -> s));

		// ---- polls: options first (built in afterLoad), then votes ----
		Map<UUID, List<String[]>> pendingPolls = new TreeMap<>();
		f.add(new SimpleFeature("polls", 5, Features::pollRows,
				row -> pendingPolls.computeIfAbsent(ID.apply(row[0]), k -> new ArrayList<>()).add(row),
				() -> { PollTools.clear(); pendingPolls.clear(); },
				() -> { buildPolls(pendingPolls); pendingPolls.clear(); }));
		f.add(new SimpleFeature("pollvotes", 3, Features::pollVoteRows,
				row -> PollTools.restoreVote(ID.apply(row[0]), ID.apply(row[1]), Integer.parseInt(row[2])), () -> {}));

		// ---- per-user data ----
		f.add(new SimpleFeature("readmarkers", 3, Features::readRows,
				row -> ReadTracker.restore(ID.apply(row[0]), ID.apply(row[1]), Long.parseLong(row[2])), ReadTracker::clear));
		f.add(new SimpleFeature("bans", 2, () -> BanTools.all().entrySet().stream()
				.map(e -> new String[] {e.getKey().toString(), e.getValue().toString()}).iterator(),
				row -> BanTools.restore(ID.apply(row[0]), Long.parseLong(row[1])), BanTools::clear));
		f.add(new SimpleFeature("moderators", 1, () -> Permissions.moderators().stream().map(u -> new String[] {u.toString()}).iterator(),
				row -> Permissions.restore(ID.apply(row[0])), Permissions::clear));

		// ---- other stores ----
		f.add(new SimpleFeature("directmessages", 5, () -> DirectMessageTools.all().stream()
				.map(d -> new String[] {d.id().toString(), d.from().toString(), d.to().toString(), Long.toString(d.timestamp()), d.text()}).iterator(),
				row -> DirectMessageTools.restore(new DirectMessage(ID.apply(row[0]), ID.apply(row[1]), ID.apply(row[2]), Long.parseLong(row[3]), row[4])),
				DirectMessageTools::clear));
		f.add(new SimpleFeature("scheduled", 5, () -> ScheduledMessages.pending().stream()
				.map(m -> new String[] {m.id().toString(), m.poster().toString(), m.thread().toString(), Long.toString(m.timestamp()), m.message()}).iterator(),
				row -> ScheduledMessages.restore(new Message(ID.apply(row[0]), ID.apply(row[1]), ID.apply(row[2]), Long.parseLong(row[3]), row[4])),
				ScheduledMessages::clear));
		f.add(new SimpleFeature("auditlog", 3, () -> AdminActions.getLog().stream()
				.map(e -> new String[] {e.admin().toString(), e.action(), Long.toString(e.timestamp())}).iterator(),
				row -> AdminActions.restoreLog(new AuditEntry(ID.apply(row[0]), row[1], Long.parseLong(row[2]))), AdminActions::clear));
		f.add(new SimpleFeature("boards", 2, () -> BoardTools.boardRows().iterator(),
				row -> BoardTools.createBoard(row[0], row[1]), BoardTools::clear));
		f.add(new SimpleFeature("boardposts", 2, () -> BoardTools.postRows().iterator(),
				row -> { Board b = BoardTools.root().find(row[0]); if (b != null) b.addPost(ID.apply(row[1])); }, () -> {}));
		f.add(new SimpleFeature("replies", 2, () -> threads.ThreadTools.allLinks().entrySet().stream()
				.map(e -> new String[] {e.getValue().toString(), e.getKey().toString()}).iterator(),
				row -> threads.ThreadTools.link(ID.apply(row[0]), ID.apply(row[1])), threads.ThreadTools::clear));
		f.add(new SimpleFeature("privateposts", 1, () -> access.AccessTools.privatePosts().stream().map(p -> new String[] {p.toString()}).iterator(),
				row -> access.AccessTools.restorePrivate(ID.apply(row[0])), access.AccessTools::clear));
		f.add(new RelationFeature<>("invites", access.AccessTools.invites(), ID, ID));
		return f;
	}

	// ------------------------------------------------------------ row builders

	private static Iterator<String[]> postFlagRows(Function<Post, java.util.Set<UUID>> flags) {
		List<String[]> rows = new ArrayList<>();
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) {
			Post post = it.next();
			for (UUID id : flags.apply(post)) rows.add(new String[] {id.toString(), post.id.toString()});
		}
		return rows.iterator();
	}

	private static Iterator<String[]> pinnedRows() {
		List<String[]> rows = new ArrayList<>();
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) {
			Post post = it.next();
			for (Iterator<Message> pins = post.getPinnedMessages(); pins.hasNext(); )
				rows.add(new String[] {pins.next().id().toString(), post.id.toString()});
		}
		return rows.iterator();
	}

	private static Iterator<String[]> lockedRows() {
		List<String[]> rows = new ArrayList<>();
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) {
			Post post = it.next();
			if (post.isLocked()) rows.add(new String[] {post.id.toString()});
		}
		return rows.iterator();
	}

	private static Iterator<String[]> reactionRows() {
		List<String[]> rows = new ArrayList<>();
		for (MessageReactions group : ReactionStore.getInstance().all())
			for (Reaction r : group.getReactions())
				rows.add(new String[] {r.message().toString(), r.user().toString(), r.type().name(), Long.toString(r.timestamp())});
		return rows.iterator();
	}

	private static Iterator<String[]> voteRows() {
		List<String[]> rows = new ArrayList<>();
		for (MessageVotes votes : VoteTools.all())
			for (Map.Entry<UUID, Integer> v : votes.getVotes().entrySet())
				rows.add(new String[] {votes.getMessageId().toString(), v.getKey().toString(), v.getValue().toString(), Long.toString(votes.latestTimestamp())});
		return rows.iterator();
	}

	private static Iterator<String[]> editRows() {
		List<String[]> rows = new ArrayList<>();
		for (Map.Entry<UUID, List<Edit>> e : EditTools.all().entrySet())
			for (int i = 0; i < e.getValue().size(); i++) // index column keeps the order readable for other programs
				rows.add(new String[] {e.getKey().toString(), Integer.toString(i), e.getValue().get(i).text(), Long.toString(e.getValue().get(i).editedAt())});
		return rows.iterator();
	}

	// one row per OPTION (CSV has fixed columns, a poll has a variable number of options)
	private static Iterator<String[]> pollRows() {
		List<String[]> rows = new ArrayList<>();
		for (Poll poll : PollTools.all())
			for (int i = 0; i < poll.getOptions().size(); i++)
				rows.add(new String[] {poll.getId().toString(), poll.getPost().toString(), poll.getCreator().toString(), Integer.toString(i), poll.getOptions().get(i)});
		return rows.iterator();
	}

	private static void buildPolls(Map<UUID, List<String[]>> rowsByPoll) {
		for (Map.Entry<UUID, List<String[]>> e : rowsByPoll.entrySet()) {
			List<String[]> rows = new ArrayList<>(e.getValue());
			rows.sort((x, y) -> Integer.compare(Integer.parseInt(x[3]), Integer.parseInt(y[3])));
			List<String> options = new ArrayList<>();
			for (String[] row : rows) options.add(row[4]);
			String[] first = rows.get(0);
			PollTools.restore(new Poll(e.getKey(), ID.apply(first[1]), ID.apply(first[2]), options));
		}
	}

	private static Iterator<String[]> pollVoteRows() {
		List<String[]> rows = new ArrayList<>();
		for (Poll poll : PollTools.all())
			for (Map.Entry<UUID, Integer> v : poll.getVotes().entrySet())
				rows.add(new String[] {poll.getId().toString(), v.getKey().toString(), v.getValue().toString()});
		return rows.iterator();
	}

	private static Iterator<String[]> readRows() {
		List<String[]> rows = new ArrayList<>();
		for (Map.Entry<UUID, Map<UUID, Long>> user : ReadTracker.all().entrySet())
			for (Map.Entry<UUID, Long> post : user.getValue().entrySet())
				rows.add(new String[] {user.getKey().toString(), post.getKey().toString(), post.getValue().toString()});
		return rows.iterator();
	}

	// finds the message by id and hands it to the action together with its post
	private static void withMessage(String[] row, java.util.function.BiConsumer<Post, Message> action) {
		Message m = MessageIndex.getInstance().get(ID.apply(row[0]));
		Post post = PostDAO.getInstance().get(new Post(ID.apply(row[1])));
		if (m != null && post != null) action.accept(post, m);
	}
}
