package persistentdata.features;

import relations.RelationStore;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;

/**
 * Saves ANY RelationStore (follows, blocks, bookmarks, likes, tags, subscriptions, friends...)
 * as rows "source,target". One generic class instead of eight copies.
 */
public class RelationFeature<A, B> implements PersistentFeature {
	private final String fileName;
	private final RelationStore<A, B> store;
	private final Function<String, A> parseSource;
	private final Function<String, B> parseTarget;

	public RelationFeature(String fileName, RelationStore<A, B> store, Function<String, A> parseSource, Function<String, B> parseTarget) {
		this.fileName = fileName;
		this.store = store;
		this.parseSource = parseSource;
		this.parseTarget = parseTarget;
	}

	@Override public String fileName() { return fileName; }
	@Override public int columns() { return 2; }

	@Override
	public Iterator<String[]> rows() {
		List<String[]> rows = new ArrayList<>();
		for (A source : store.sources())
			for (B target : store.targetsOf(source)) rows.add(new String[] {source.toString(), target.toString()});
		return rows.iterator();
	}

	@Override
	public void restore(String[] row) {
		store.add(parseSource.apply(row[0]), parseTarget.apply(row[1]));
	}

	@Override
	public void clear() {
		store.clear();
	}
}
