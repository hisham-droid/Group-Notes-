package persistentdata.features;

import persistentdata.serialization.Serializer;

/** Rows are already String[], so serializing is the identity. */
public class RowSerializer implements Serializer<String[], String[]> {
	@Override
	public String[] serialize(String[] row) {
		return row;
	}

	@Override
	public String[] deserialize(String[] row) {
		return row;
	}
}
