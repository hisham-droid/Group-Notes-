package mentions;

import dao.MessageComparator;
import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import dao.model.User;
import relations.RelationStore;
import sorteddata.SortedDataSubject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PREDICTED Task 1 theme: @mentions.
 * Every new message is scanned ONCE when it is added (Observer via MessageIndex), and
 * mentioned users are stored in a RelationStore user -> message. Asking "where was I
 * mentioned" is then a lookup, not a scan of every message.
 * This is DERIVED data: rebuilt automatically when messages are loaded, so it needs no file.
 */
public final class MentionTools {
	// same rules as usernames: 4-20 letters/digits
	private static final Pattern MENTION = Pattern.compile("@([A-Za-z0-9]{4,20})(?![A-Za-z0-9])");
	private static final RelationStore<UUID, UUID> mentions = new RelationStore<>(); // user -> message
	private static final SortedDataSubject<Message> LISTENER = MentionTools::onMessage;
	static {
		MessageIndex.getInstance().addChangeListener(LISTENER); // new AND edited messages
	}

	private MentionTools() {}

	/** Call once at start-up (e.g. in main / a test @Before) so no early message is missed. */
	public static void init() {
		// running the static block above is all that is needed
	}

	/** @return usernames mentioned in the text, in order, without duplicates (not checked against UserDAO) */
	public static List<String> extractUsernames(String text) {
		Set<String> names = new LinkedHashSet<>();
		if (text == null) return new ArrayList<>();
		Matcher m = MENTION.matcher(text);
		while (m.find()) names.add(m.group(1));
		return new ArrayList<>(names);
	}

	private static void onMessage(Message message) {
		for (String name : extractUsernames(message.message())) {
			User user = UserDAO.getInstance().get(new User(name)); // comparator ignores case
			if (user != null && user.id() != null) mentions.add(user.id(), message.id());
		}
	}

	/** @return messages that mention this user and still exist, newest first */
	public static List<Message> getMentions(UUID user) {
		List<Message> result = new ArrayList<>();
		for (UUID id : mentions.targetsOf(user)) {
			Message m = MessageIndex.getInstance().get(id);
			if (m != null) result.add(m);
		}
		result.sort(MessageComparator.getInstance().reversed());
		return result;
	}

	public static void forgetUser(UUID user) {
		mentions.removeSource(user);
	}

	public static void clear() {
		mentions.clear();
	}
}
