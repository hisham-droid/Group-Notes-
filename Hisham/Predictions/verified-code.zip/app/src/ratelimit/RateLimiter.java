package ratelimit;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: spam protection, "at most N actions per W milliseconds per user".
 * SLIDING WINDOW: each user has a queue of their recent action times. Old times fall off
 * the front, new ones go on the back. Each call is O(1) amortised (every time is added
 * once and removed once).
 */
public class RateLimiter {
	private final int maxActions;
	private final long windowMillis;
	private final Map<UUID, Deque<Long>> recent = new HashMap<>();

	public RateLimiter(int maxActions, long windowMillis) {
		if (maxActions <= 0 || windowMillis <= 0) throw new IllegalArgumentException("limits must be positive");
		this.maxActions = maxActions;
		this.windowMillis = windowMillis;
	}

	/**
	 * Records an action if allowed.
	 * @param now current time; calls must not go backwards in time per user
	 * @return true if the user is under the limit (and the action is counted)
	 */
	public boolean tryAcquire(UUID user, long now) {
		Deque<Long> times = recent.computeIfAbsent(user, k -> new ArrayDeque<>());
		while (!times.isEmpty() && times.peekFirst() <= now - windowMillis) times.pollFirst(); // drop expired
		if (times.size() >= maxActions) return false;
		times.addLast(now);
		return true;
	}

	/** @return actions the user may still do right now */
	public int remaining(UUID user, long now) {
		Deque<Long> times = recent.get(user);
		if (times == null) return maxActions;
		int active = 0;
		for (long t : times) if (t > now - windowMillis) active++;
		return maxActions - active;
	}

	public void reset(UUID user) {
		recent.remove(user);
	}
}
