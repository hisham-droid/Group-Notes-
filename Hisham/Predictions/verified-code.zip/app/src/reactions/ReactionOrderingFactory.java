package reactions;

import java.util.Comparator;

/**
 * FACTORY for reaction rankings (STRATEGY = the Comparator).
 *   "MOST"      -> most reactions of any type first
 *   "NEWEST"    -> most recent reaction first
 *   "LIKE", "LOVE", ... (any ReactionType name) -> most reactions of that type first
 */
public final class ReactionOrderingFactory {
	private ReactionOrderingFactory() {}

	public static Comparator<MessageReactions> create(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null");
		switch (strategy) {
			case "MOST":
				return Comparator.comparingInt(MessageReactions::total).reversed();
			case "NEWEST":
				return Comparator.comparingLong(MessageReactions::latestTimestamp).reversed();
			default:
				ReactionType type = parseType(strategy);
				return Comparator.comparingInt((MessageReactions r) -> r.count(type)).reversed();
		}
	}

	/** @return a predicate-friendly type, or null for MOST/NEWEST */
	public static ReactionType typeFilter(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null"); // valueOf(null) would throw NullPointerException
		return ("MOST".equals(strategy) || "NEWEST".equals(strategy)) ? null : parseType(strategy);
	}

	private static ReactionType parseType(String strategy) {
		if (strategy == null) throw new IllegalArgumentException("strategy must not be null");
		try {
			return ReactionType.valueOf(strategy);
		} catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Unknown strategy: " + strategy);
		}
	}
}
