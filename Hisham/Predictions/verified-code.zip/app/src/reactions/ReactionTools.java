package reactions;

import dao.MessageIndex;
import dao.UserDAO;
import dao.model.Message;
import util.TopKIterator;

import java.util.Iterator;
import java.util.UUID;

/**
 * PREDICTED hackathon facade: reactions on messages.
 * Same shape as ModerationTools: validate, then delegate to O(1) structures.
 */
public class ReactionTools {
	private ReactionTools() {}

	/** @return false if message/user missing, type null, or user already reacted */
	public static boolean addReaction(UUID message, UUID user, ReactionType type, long timestamp) {
		if (type == null || !exists(message, user)) return false;
		return ReactionStore.getInstance().forMessage(message).add(new Reaction(message, user, type, timestamp));
	}

	/** Switch an existing reaction to another type. @return false if none existed or nothing changed */
	public static boolean changeReaction(UUID message, UUID user, ReactionType type, long timestamp) {
		if (type == null || !exists(message, user)) return false;
		MessageReactions reactions = ReactionStore.getInstance().find(message);
		if (reactions == null || reactions.getReaction(user) == null || reactions.getReaction(user) == type) return false;
		return reactions.change(new Reaction(message, user, type, timestamp));
	}

	/** @return false if message/user missing or the user had no reaction */
	public static boolean removeReaction(UUID message, UUID user) {
		if (!exists(message, user)) return false;
		MessageReactions reactions = ReactionStore.getInstance().find(message);
		if (reactions == null || !reactions.remove(user)) return false;
		ReactionStore.getInstance().dropIfEmpty(message);
		return true;
	}

	/** @return the user's reaction, or null if none */
	public static ReactionType getReaction(UUID message, UUID user) {
		MessageReactions reactions = ReactionStore.getInstance().find(message);
		return reactions == null ? null : reactions.getReaction(user);
	}

	public static boolean hasReacted(UUID message, UUID user) {
		return getReaction(message, user) != null;
	}

	/** @return how many reactions of this type the message has (0 if none / unknown) */
	public static int countReactions(UUID message, ReactionType type) {
		MessageReactions reactions = ReactionStore.getInstance().find(message);
		return reactions == null ? 0 : reactions.count(type);
	}

	/**
	 * Top messages by a strategy, using the Factory + the reusable TopKIterator.
	 * Messages with zero relevant reactions are never returned.
	 */
	public static Iterator<Message> getTopMessages(String strategy, int amount) {
		ReactionType type = ReactionOrderingFactory.typeFilter(strategy); // validates too
		return new TopKIterator<>(
				ReactionStore.getInstance().all(),
				ReactionOrderingFactory.create(strategy),
				group -> type == null ? !group.isEmpty() : group.count(type) > 0,
				group -> MessageIndex.getInstance().get(group.getMessageId()),
				amount);
	}

	private static boolean exists(UUID message, UUID user) {
		return MessageIndex.getInstance().get(message) != null && UserDAO.getInstance().getByUUID(user) != null;
	}
}
