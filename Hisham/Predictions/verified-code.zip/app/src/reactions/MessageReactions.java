package reactions;

import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * All reactions on ONE message.
 *  - HashMap user -> Reaction: add / remove / getReaction in O(1)
 *  - EnumMap type -> count: countReactions in O(1) (kept up to date, never recounted)
 * EnumMap is an array indexed by the enum's ordinal: fast and memory-light.
 */
public class MessageReactions {
	private final UUID messageId;
	private final Map<UUID, Reaction> byUser = new HashMap<>();
	private final EnumMap<ReactionType, Integer> counts = new EnumMap<>(ReactionType.class);
	private long latestTimestamp = Long.MIN_VALUE;

	public MessageReactions(UUID messageId) {
		this.messageId = messageId;
	}

	/** @return false if this user already reacted (use change() to switch type) */
	public boolean add(Reaction reaction) {
		if (byUser.putIfAbsent(reaction.user(), reaction) != null) return false;
		counts.merge(reaction.type(), 1, Integer::sum);
		latestTimestamp = Math.max(latestTimestamp, reaction.timestamp());
		return true;
	}

	/** @return false if the user had no reaction */
	public boolean remove(UUID user) {
		Reaction removed = byUser.remove(user);
		if (removed == null) return false;
		// decrement; drop the key at zero so counts never holds zeros
		counts.computeIfPresent(removed.type(), (type, count) -> count == 1 ? null : count - 1);
		return true;
	}

	/** Replace a user's reaction with a different type. @return false if they had none */
	public boolean change(Reaction replacement) {
		if (!remove(replacement.user())) return false;
		return add(replacement);
	}

	public ReactionType getReaction(UUID user) {
		Reaction reaction = byUser.get(user);
		return reaction == null ? null : reaction.type();
	}

	public int count(ReactionType type) {
		return counts.getOrDefault(type, 0);
	}

	public int total() {
		return byUser.size();
	}

	public boolean isEmpty() {
		return byUser.isEmpty();
	}

	/** Note: not lowered by remove() (would need a TreeSet like MessageReports). */
	public long latestTimestamp() {
		return latestTimestamp;
	}

	public UUID getMessageId() {
		return messageId;
	}

	public Collection<Reaction> getReactions() {
		return Collections.unmodifiableCollection(byUser.values());
	}
}
