package reactions;

import java.util.UUID;

/** One user's reaction to one message. */
public record Reaction(UUID message, UUID user, ReactionType type, long timestamp) {}
