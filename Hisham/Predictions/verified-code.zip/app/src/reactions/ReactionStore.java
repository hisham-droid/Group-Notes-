package reactions;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Singleton: message UUID -> its reactions. */
public class ReactionStore {
	private static ReactionStore instance;

	public static ReactionStore getInstance() {
		if (instance == null) instance = new ReactionStore();
		return instance;
	}

	private final Map<UUID, MessageReactions> byMessage = new HashMap<>();

	private ReactionStore() {}

	public MessageReactions forMessage(UUID message) {
		return byMessage.computeIfAbsent(message, MessageReactions::new);
	}

	public MessageReactions find(UUID message) {
		return byMessage.get(message);
	}

	/** call after a removal so empty groups disappear */
	public void dropIfEmpty(UUID message) {
		MessageReactions reactions = byMessage.get(message);
		if (reactions != null && reactions.isEmpty()) byMessage.remove(message);
	}

	public Collection<MessageReactions> all() {
		return Collections.unmodifiableCollection(byMessage.values());
	}

	/** Account deletion: drops every reaction by this user. */
	public void removeAllByUser(java.util.UUID user) {
		byMessage.values().removeIf(reactions -> reactions.remove(user) && reactions.isEmpty());
	}

	public void clear() {
		byMessage.clear();
	}
}
