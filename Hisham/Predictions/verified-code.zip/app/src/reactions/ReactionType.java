package reactions;

/**
 * PREDICTION: the practice spec says "Do not modify the ReactionType enum", so a real
 * version ships this enum. The constants below are a guess; your code must work for ANY
 * constants, so never hard-code them (use EnumMap / values()).
 */
public enum ReactionType { LIKE, LOVE, LAUGH, WOW, SAD, ANGRY }
