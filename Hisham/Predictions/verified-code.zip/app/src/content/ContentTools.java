package content;

import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * PREDICTED Task 2 facades (same shape as ModerationTools.setHidden):
 *  soft delete / restore, hard delete, lock / unlock + reply, pin / unpin + pinned-first listing.
 * Every method: validate (exists? allowed?) -> return false without changing anything, else act.
 */
public final class ContentTools {
	private ContentTools() {}

	// ------------------------------------------------------------ soft delete

	/** Author or Admin may soft-delete. @return false if ids missing or not allowed */
	public static boolean deleteMessage(UUID message, UUID user) {
		return setDeleted(message, user, true);
	}

	/** Author or Admin may restore a soft-deleted message. */
	public static boolean restoreMessage(UUID message, UUID user) {
		return setDeleted(message, user, false);
	}

	private static boolean setDeleted(UUID message, UUID user, boolean deleted) {
		Message target = MessageIndex.getInstance().get(message);
		User actor = UserDAO.getInstance().getByUUID(user);
		if (target == null || actor == null || !isAuthorOrAdmin(target, actor)) return false;
		MessageIndex.getInstance().getPostOf(target).setDeleted(target, deleted);
		return true;
	}

	// ------------------------------------------------------------ hard delete

	/** Admin only. The message is gone for everyone (reports etc. may also need cleaning). */
	public static boolean removeMessage(UUID message, UUID admin) {
		Message target = MessageIndex.getInstance().get(message);
		if (target == null || !isAdmin(admin)) return false;
		MessageIndex.getInstance().getPostOf(target).removeMessage(target);
		MessageIndex.getInstance().forget(message);
		return true;
	}

	// ------------------------------------------------------------ locking

	/** Admin only. @return false if the post or admin does not exist / is not an admin */
	public static boolean setLocked(UUID post, UUID admin, boolean locked) {
		Post target = findPost(post);
		if (target == null || !isAdmin(admin)) return false;
		target.setLocked(locked);
		return true;
	}

	/**
	 * Adds a reply. Members cannot reply to a locked post; admins can.
	 * @return the new message, or null if not allowed
	 */
	public static Message reply(UUID post, UUID user, String text, long timestamp) {
		Post target = findPost(post);
		User author = UserDAO.getInstance().getByUUID(user);
		if (target == null || author == null || text == null) return null;
		if (target.isLocked() && author.role() != User.Role.Admin) return null;
		if (bans.BanTools.isBanned(user, timestamp)) return null; // banned users cannot post
		Message message = new Message(UUID.randomUUID(), user, post, timestamp, text);
		target.messages.insert(message);
		return message;
	}

	// ------------------------------------------------------------ pinning

	/** Admin only. */
	public static boolean setPinned(UUID message, UUID admin, boolean pinned) {
		Message target = MessageIndex.getInstance().get(message);
		if (target == null || !isAdmin(admin)) return false;
		MessageIndex.getInstance().getPostOf(target).setPinned(target, pinned);
		return true;
	}

	/**
	 * Pinned messages first (in time order), then every other message (in time order).
	 * Non-admins only see visible ones. Each message appears once.
	 */
	public static Iterator<Message> getMessagesPinnedFirst(UUID post, boolean isAdmin) {
		Post target = findPost(post);
		List<Message> result = new ArrayList<>();
		if (target == null) return result.iterator();
		for (Iterator<Message> it = target.getPinnedMessages(); it.hasNext(); ) {
			Message m = it.next();
			if (isAdmin || target.isVisibleToMembers(m.id())) result.add(m);
		}
		for (Iterator<Message> it = target.getVisibleMessages(isAdmin).getAll(); it.hasNext(); ) {
			Message m = it.next();
			if (!target.isPinned(m)) result.add(m);
		}
		return result.iterator();
	}

	// ------------------------------------------------------------ helpers

	private static Post findPost(UUID post) {
		return post == null ? null : PostDAO.getInstance().get(new Post(post));
	}

	static boolean isAdmin(UUID user) {
		User u = UserDAO.getInstance().getByUUID(user);
		return u != null && u.role() == User.Role.Admin;
	}

	private static boolean isAuthorOrAdmin(Message message, User user) {
		return user.role() == User.Role.Admin || user.id().equals(message.poster());
	}
}
