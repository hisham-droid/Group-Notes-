package content;

import dao.MessageIndex;
import dao.PostDAO;
import dao.model.Message;
import dao.model.Post;

import java.util.UUID;

/**
 * PREDICTED theme: move a message to another post (admin).
 * Message is immutable and its post id (thread) is part of the record, so moving =
 * remove from the old post + insert a copy with the new thread. Same id, so reports,
 * reactions, votes and edit history (all keyed by message id) still apply.
 */
public final class MoveTools {
	private MoveTools() {}

	/** @return false if message/post missing, not admin, or already in that post */
	public static boolean moveMessage(UUID message, UUID targetPost, UUID admin) {
		Message current = MessageIndex.getInstance().get(message);
		Post target = targetPost == null ? null : PostDAO.getInstance().get(new Post(targetPost));
		if (current == null || target == null || !ContentTools.isAdmin(admin) || targetPost.equals(current.thread())) return false;
		Post source = MessageIndex.getInstance().getPostOf(current);
		boolean wasHidden = source.isHidden(message);
		source.removeMessage(current);
		Message moved = new Message(current.id(), current.poster(), targetPost, current.timestamp(), current.message());
		target.messages.insert(moved);
		if (wasHidden) target.setHidden(moved, true); // keep moderation state
		return true;
	}
}
