package notifications;

import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import relations.RelationStore;
import sorteddata.SortedDataSubject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: subscribe to a post, get notified about new replies.
 * OBSERVER pattern twice:
 *  - every Post notifies MessageIndex about new messages
 *  - MessageIndex forwards them to us (addMessageListener), we fan out to subscribers
 * Notifications are kept newest-first in a Deque (addFirst is O(1)).
 */
public final class NotificationTools {
	private static final RelationStore<UUID, UUID> subscriptions = new RelationStore<>(); // user -> post
	private static final Map<UUID, Deque<Notification>> inbox = new HashMap<>();
	private static final Map<UUID, Integer> unread = new HashMap<>();

	// the listener is registered once, the first time this class is used
	private static final SortedDataSubject<Message> LISTENER = NotificationTools::onMessage;
	static {
		MessageIndex.getInstance().addMessageListener(LISTENER);
	}

	private NotificationTools() {}

	/** @return false if user/post missing or already subscribed */
	public static boolean subscribe(UUID user, UUID post) {
		if (UserDAO.getInstance().getByUUID(user) == null || PostDAO.getInstance().get(new Post(post)) == null) return false;
		return subscriptions.add(user, post);
	}

	public static boolean unsubscribe(UUID user, UUID post) {
		return subscriptions.remove(user, post);
	}

	public static boolean isSubscribed(UUID user, UUID post) {
		return subscriptions.contains(user, post);
	}

	public static Set<UUID> getSubscribers(UUID post) {
		return subscriptions.sourcesOf(post);
	}

	// called for every new message anywhere: notify that post's subscribers (not the author)
	private static void onMessage(Message message) {
		if (message.thread() == null) return;
		for (UUID user : subscriptions.sourcesOf(message.thread())) {
			if (user.equals(message.poster())) continue; // do not notify people about their own message
			inbox.computeIfAbsent(user, k -> new ArrayDeque<>())
					.addFirst(new Notification(user, message.id(), message.thread(), message.timestamp()));
			unread.merge(user, 1, Integer::sum);
		}
	}

	/** @return newest first (a copy) */
	public static List<Notification> getNotifications(UUID user) {
		return new ArrayList<>(inbox.getOrDefault(user, new ArrayDeque<>()));
	}

	public static int getUnreadCount(UUID user) {
		return unread.getOrDefault(user, 0);
	}

	public static void markAllRead(UUID user) {
		unread.remove(user);
	}

	/** Account deletion. */
	public static void forgetUser(UUID user) {
		subscriptions.removeSource(user);
		inbox.remove(user);
		unread.remove(user);
	}

	/** raw store, for persistence (subscriptions are saved; notifications are temporary) */
	public static RelationStore<UUID, UUID> subscriptions() {
		return subscriptions;
	}

	public static void clear() {
		subscriptions.clear();
		inbox.clear();
		unread.clear();
	}
}
