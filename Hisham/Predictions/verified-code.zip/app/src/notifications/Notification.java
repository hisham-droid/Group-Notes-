package notifications;

import java.util.UUID;

/**
 * "Something happened that you subscribed to."
 * @param user      who receives it
 * @param message   the new message
 * @param post      where it happened
 * @param timestamp when the message was posted
 */
public record Notification(UUID user, UUID message, UUID post, long timestamp) {}
