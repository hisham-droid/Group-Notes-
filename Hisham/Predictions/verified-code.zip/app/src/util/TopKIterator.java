package util;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * HACKATHON (Task 4, reusable): ITERATOR over the best `amount` groups, best first.
 * Works for ANY "rank things by a strategy and return the top k" question:
 * reports, reactions, votes, leaderboards...
 * <p>
 * @param <G> the group being ranked (e.g. MessageReactions)
 * @param <T> what the iterator returns (e.g. Message)
 * Cost: O(m) to heapify + O(log m) per next().
 */
public class TopKIterator<G, T> implements Iterator<T> {
	private final PriorityQueue<G> queue;
	private final Function<G, T> toResult; // returning null means "skip this one" (e.g. deleted)
	private int remaining;
	private T next;

	public TopKIterator(Collection<G> groups, Comparator<G> order, Predicate<G> include, Function<G, T> toResult, int amount) {
		if (amount <= 0) throw new IllegalArgumentException("amount must be positive, was " + amount);
		this.queue = new PriorityQueue<>(Math.max(1, groups.size()), order);
		for (G group : groups) if (include.test(group)) queue.add(group);
		this.toResult = toResult;
		this.remaining = amount;
		advance();
	}

	private void advance() {
		next = null;
		while (remaining > 0 && !queue.isEmpty()) {
			T candidate = toResult.apply(queue.poll());
			if (candidate != null) {
				next = candidate;
				remaining--;
				return;
			}
		}
	}

	@Override
	public boolean hasNext() {
		return next != null;
	}

	@Override
	public T next() {
		if (next == null) throw new NoSuchElementException();
		T result = next;
		advance();
		return result;
	}
}
