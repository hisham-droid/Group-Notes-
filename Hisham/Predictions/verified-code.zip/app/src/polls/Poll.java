package polls;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A poll attached to a post. Each user has at most ONE vote (an option index).
 * counts[i] is kept in sync so results are O(options), not O(voters).
 */
public class Poll {
	private final UUID id;
	private final UUID post;
	private final UUID creator;
	private final List<String> options;
	private final int[] counts;
	private final Map<UUID, Integer> voteByUser = new HashMap<>();

	public Poll(UUID id, UUID post, UUID creator, List<String> options) {
		this.id = id;
		this.post = post;
		this.creator = creator;
		this.options = List.copyOf(options);
		this.counts = new int[options.size()];
	}

	/** @return false if the option index is invalid or the user already voted */
	boolean vote(UUID user, int option) {
		if (!validOption(option) || voteByUser.containsKey(user)) return false;
		voteByUser.put(user, option);
		counts[option]++;
		return true;
	}

	/** @return false if the user had not voted, the option is invalid, or it is the same option */
	boolean changeVote(UUID user, int option) {
		Integer previous = voteByUser.get(user);
		if (previous == null || !validOption(option) || previous == option) return false;
		counts[previous]--;
		counts[option]++;
		voteByUser.put(user, option);
		return true;
	}

	boolean removeVote(UUID user) {
		Integer previous = voteByUser.remove(user);
		if (previous == null) return false;
		counts[previous]--;
		return true;
	}

	/** @return option index, or -1 if the user has not voted */
	public int getVote(UUID user) {
		return voteByUser.getOrDefault(user, -1);
	}

	public int[] getResults() {
		return counts.clone(); // a copy: callers cannot change our counts
	}

	private boolean validOption(int option) {
		return option >= 0 && option < options.size();
	}

	public UUID getId() { return id; }
	public UUID getPost() { return post; }
	public UUID getCreator() { return creator; }
	public List<String> getOptions() { return options; }
	public Map<UUID, Integer> getVotes() { return Collections.unmodifiableMap(voteByUser); }
}
