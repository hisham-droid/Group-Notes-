package polls;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Post;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: polls (vote once, may change or retract the vote).
 */
public final class PollTools {
	private static final Map<UUID, Poll> polls = new HashMap<>();

	private PollTools() {}

	/**
	 * @param options at least 2 non-blank, distinct (case-insensitive) options
	 * @return the new poll's id, or null if the post/user is missing or the options are invalid
	 */
	public static UUID createPoll(UUID post, UUID creator, List<String> options) {
		if (post == null || PostDAO.getInstance().get(new Post(post)) == null) return null;
		if (UserDAO.getInstance().getByUUID(creator) == null || !validOptions(options)) return null;
		Poll poll = new Poll(UUID.randomUUID(), post, creator, options);
		polls.put(poll.getId(), poll);
		return poll.getId();
	}

	private static boolean validOptions(List<String> options) {
		if (options == null || options.size() < 2) return false;
		HashSet<String> seen = new HashSet<>();
		for (String option : options) {
			if (option == null || option.isBlank() || !seen.add(option.trim().toLowerCase())) return false;
		}
		return true;
	}

	/** @return false if poll/user missing, option invalid, or already voted (use changeVote) */
	public static boolean vote(UUID poll, UUID user, int option) {
		Poll p = polls.get(poll);
		return p != null && UserDAO.getInstance().getByUUID(user) != null && p.vote(user, option);
	}

	public static boolean changeVote(UUID poll, UUID user, int option) {
		Poll p = polls.get(poll);
		return p != null && p.changeVote(user, option);
	}

	public static boolean removeVote(UUID poll, UUID user) {
		Poll p = polls.get(poll);
		return p != null && p.removeVote(user);
	}

	/** @return option index, -1 if no vote or unknown poll */
	public static int getVote(UUID poll, UUID user) {
		Poll p = polls.get(poll);
		return p == null ? -1 : p.getVote(user);
	}

	/** @return vote count per option (copy), or null for an unknown poll */
	public static int[] getResults(UUID poll) {
		Poll p = polls.get(poll);
		return p == null ? null : p.getResults();
	}

	/** @return indices of the leading option(s) (several on a tie; empty if no votes) */
	public static List<Integer> getWinners(UUID poll) {
		int[] results = getResults(poll);
		List<Integer> winners = new ArrayList<>();
		if (results == null) return winners;
		int best = 0;
		for (int count : results) best = Math.max(best, count);
		if (best == 0) return winners;
		for (int i = 0; i < results.length; i++) if (results[i] == best) winners.add(i);
		return winners;
	}

	public static Poll getPoll(UUID poll) {
		return polls.get(poll);
	}

	/** Account deletion: their votes disappear from every poll. */
	public static void removeVotesBy(UUID user) {
		for (Poll poll : polls.values()) poll.removeVote(user);
	}

	/** persistence */
	public static Collection<Poll> all() {
		return Collections.unmodifiableCollection(polls.values());
	}

	/** persistence: put back a saved poll (votes are restored with restoreVote) */
	public static void restore(Poll poll) {
		polls.put(poll.getId(), poll);
	}

	public static void restoreVote(UUID poll, UUID user, int option) {
		Poll p = polls.get(poll);
		if (p != null) p.vote(user, option);
	}

	public static void clear() {
		polls.clear();
	}
}
