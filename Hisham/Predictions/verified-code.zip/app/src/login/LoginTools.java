package login;

import dao.UserDAO;
import dao.model.User;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED theme: login security.
 *  - lockout: after MAX_FAILURES wrong passwords in a row, the account is locked for LOCK_MILLIS
 *  - history: the last HISTORY_SIZE login attempts per user (newest first, a bounded Deque)
 * Uses UserDAO.login for the actual check, so the existing rules are reused, not copied.
 */
public final class LoginTools {
	public static final int MAX_FAILURES = 3;
	public static final long LOCK_MILLIS = 5 * 60 * 1000L;
	public static final int HISTORY_SIZE = 10;

	/** One login attempt. */
	public record LoginAttempt(UUID user, long timestamp, boolean success) {}

	private static final Map<UUID, Integer> failuresInARow = new HashMap<>();
	private static final Map<UUID, Long> lockedUntil = new HashMap<>();
	private static final Map<UUID, Deque<LoginAttempt>> history = new HashMap<>();

	private LoginTools() {}

	/** @return the user on success; null if unknown, locked, or wrong password */
	public static User login(String username, String password, long now) {
		User user = username == null ? null : UserDAO.getInstance().get(new User(username));
		if (user == null || user.id() == null) return null;
		if (isLocked(user.id(), now)) {
			record(user.id(), now, false);
			return null;
		}
		boolean ok = UserDAO.getInstance().login(username, password) != null;
		record(user.id(), now, ok);
		if (ok) {
			failuresInARow.remove(user.id());
			return user;
		}
		int failures = failuresInARow.merge(user.id(), 1, Integer::sum);
		if (failures >= MAX_FAILURES) {
			lockedUntil.put(user.id(), now + LOCK_MILLIS);
			failuresInARow.remove(user.id());
		}
		return null;
	}

	public static boolean isLocked(UUID user, long now) {
		Long until = lockedUntil.get(user);
		return until != null && now < until;
	}

	/** Admin unlocks an account early. */
	public static boolean unlock(UUID admin, UUID user) {
		User a = UserDAO.getInstance().getByUUID(admin);
		if (a == null || a.role() != User.Role.Admin) return false;
		failuresInARow.remove(user);
		return lockedUntil.remove(user) != null;
	}

	/** @return newest first */
	public static List<LoginAttempt> getHistory(UUID user) {
		return new ArrayList<>(history.getOrDefault(user, new ArrayDeque<>()));
	}

	private static void record(UUID user, long now, boolean success) {
		Deque<LoginAttempt> attempts = history.computeIfAbsent(user, k -> new ArrayDeque<>());
		attempts.addFirst(new LoginAttempt(user, now, success));
		if (attempts.size() > HISTORY_SIZE) attempts.removeLast(); // keep it bounded
	}

	public static void clear() {
		failuresInARow.clear();
		lockedUntil.clear();
		history.clear();
	}
}
