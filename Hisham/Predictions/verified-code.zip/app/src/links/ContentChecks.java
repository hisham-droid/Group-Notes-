package links;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PREDICTED small themes:
 *  - extract links from a message (attachments / previews)
 *  - duplicate-message detection: the same user posting the same text again within a time window
 */
public final class ContentChecks {
	private static final Pattern URL = Pattern.compile("https?://[^\\s]+");
	private static final Map<UUID, Map<String, Long>> lastPosted = new HashMap<>(); // user -> normalised text -> time

	private ContentChecks() {}

	/** @return every http(s) link in the text, in order (trailing . , ) ! ? removed) */
	public static List<String> extractLinks(String text) {
		List<String> links = new ArrayList<>();
		if (text == null) return links;
		Matcher m = URL.matcher(text);
		while (m.find()) links.add(m.group().replaceAll("[.,)!?]+$", ""));
		return links;
	}

	/**
	 * Records the post and says whether it duplicates one from the same user within the window.
	 * Text is compared ignoring case and repeated spaces.
	 */
	public static boolean isDuplicate(UUID user, String text, long now, long windowMillis) {
		String key = text == null ? "" : text.trim().replaceAll("\\s+", " ").toLowerCase();
		Map<String, Long> mine = lastPosted.computeIfAbsent(user, k -> new HashMap<>());
		Long previous = mine.put(key, now);
		return previous != null && now - previous < windowMillis;
	}

	public static void clear() {
		lastPosted.clear();
	}
}
