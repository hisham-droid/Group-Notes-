package sorteddata;

import java.util.Comparator;

/**
 * HACKATHON: the practice base shipped with SortedArrayList here (O(n) inserts).
 * Switching this one line to AVLTree makes every DAO and every Post use the
 * O(log n) tree, and AVLTree is the one that supports remove() in O(log n).
 */
public class SortedDataFactory {
	public static <T> SortedData<T> makeSortedData(Comparator<T> comparator) {
		return new sorteddata.avltree.AVLTree<>(comparator);
	}
}
