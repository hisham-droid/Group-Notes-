package sorteddata.bstree;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

/**
 * HACKATHON (Task 2 prediction): BSTree.getRange used to return null.
 * Same algorithm as AVLIterator: a stack holds the path still to visit.
 *  - forwards: start at the first element >= begin (or the smallest if begin == null)
 *  - backwards: start at the last element <= begin (or the largest if begin == null)
 *  - stop after `count` elements (negative = unlimited)
 */
class BSIterator<T> implements Iterator<T> {
	private final Stack<BSNodeFilled<T>> stack = new Stack<>();
	private final boolean backwards;
	private int remaining;

	BSIterator(T begin, BSNode<T> root, Comparator<T> comparator, int count, boolean backwards) {
		this.backwards = backwards;
		this.remaining = count;
		BSNode<T> current = root;
		while (current instanceof BSNodeFilled<T> node) {
			int cmp = begin == null ? (backwards ? 1 : -1) : comparator.compare(begin, node.value);
			if (cmp == 0) {               // exact match: it is the first result
				stack.push(node);
				break;
			}
			boolean goLeft = cmp < 0;
			// a node is a future result if it lies on the side we are moving towards
			if (goLeft != backwards) stack.push(node);
			current = goLeft ? node.left : node.right;
		}
	}

	@Override
	public boolean hasNext() {
		return remaining != 0 && !stack.isEmpty();
	}

	@Override
	public T next() {
		if (!hasNext()) throw new NoSuchElementException();
		if (remaining > 0) remaining--;
		BSNodeFilled<T> node = stack.pop();
		// the next result is the extreme node of the subtree on the "moving" side
		BSNode<T> child = backwards ? node.left : node.right;
		while (child instanceof BSNodeFilled<T> filled) {
			stack.push(filled);
			child = backwards ? filled.right : filled.left;
		}
		return node.value;
	}
}
