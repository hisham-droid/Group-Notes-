package sorteddata;

import java.util.Comparator;
import java.util.Iterator;
import java.util.function.Predicate;

/**
 * HACKATHON (Task 2, simple alternative): build a NEW SortedData containing only
 * the elements that pass a filter. O(n log n) per call, no extra state to keep in sync.
 * Use this if you cannot (or do not want to) implement remove() on the tree.
 */
public final class SortedDataViews {
	private SortedDataViews() {}

	public static <T> SortedData<T> filter(SortedData<T> source, Comparator<T> comparator, Predicate<T> keep) {
		SortedData<T> result = SortedDataFactory.makeSortedData(comparator);
		for (Iterator<T> it = source.getAll(); it.hasNext(); ) {
			T element = it.next();
			if (keep.test(element)) result.insert(element);
		}
		return result;
	}
}
