package sorteddata.sortedarraylist;

import sorteddata.SortedData;

import java.util.*;

public class SortedArrayList<T> extends SortedData<T> {
	private final Comparator<T> comparator;
	private final ArrayList<T> list;

	public SortedArrayList(Comparator<T> comparator) {
		this.comparator = comparator;
		this.list = new ArrayList<>();
	}

	private int binarySearch(T value) {
		int s = 0, e = list.size();
		while (e > s) {
			int m = (s + e) / 2;
			if (comparator.compare(value, list.get(m)) > 0) {
				s = m + 1;
			} else {
				e = m;
			}
		}
		return s;
	}

	@Override
	public boolean insert(T value) {
		int i = binarySearch(value);
		if (i < list.size() && comparator.compare(list.get(i), value) == 0)
			return false;
		list.add(i, value);
		notifyAdded(value); // HACKATHON: tell listeners (Observer)
		return true;
	}

	@Override
	public T get(T value) {
		int i = binarySearch(value);
		return i < list.size() && comparator.compare(list.get(i), value) == 0 ? list.get(i) : null;
	}

	@Override
	public Iterator<T> getRange(T start, int count, boolean backwards) {
		// HACKATHON: backwards iteration (was "does not yet support backwards iteration").
		// Start at the last element <= start (floor) and walk towards index 0. O(log n) to find the start.
		if (backwards) {
			int i = start == null ? list.size() - 1 : binarySearch(start);
			if (start != null && (i >= list.size() || comparator.compare(list.get(i), start) > 0)) i--; // step back to the floor
			int first = i;
			return new Iterator<>() {
				private int index = first;
				private int remaining = count;

				@Override
				public boolean hasNext() {
					return index >= 0 && remaining != 0;
				}

				@Override
				public T next() {
					if (!hasNext()) throw new NoSuchElementException();
					if (remaining > 0) remaining--;
					return list.get(index--);
				}
			};
		}
		return new SortedArrayListIterator<>(list, comparator, start, count);
	}

	@Override
	public String toString() {
		StringBuilder out = new StringBuilder("SortedArrayList[");
		for (int i = 0; i < list.size(); i++) {
			if (i != 0) out.append(", ");
			out.append(list.get(i).toString());
		}
		return out.append("]").toString();
	}

	private static final Random random = new Random();

	// HACKATHON: return null out of range (like AVLTree) instead of throwing
	public T getAtIndex(int i) {
		return i >= 0 && i < list.size() ? list.get(i) : null;
	}

	@Override
	public T getRandom() {
		if (list.isEmpty()) return null;
		return list.get(random.nextInt(list.size()));
	}

	public Iterator<T> getAll() {
		return new SortedArrayListIterator<>(list, comparator, null, -1);
	}

	// HACKATHON: O(log n) search + O(n) shift, same cost profile as insert
	@Override
	public boolean remove(T value) {
		int i = binarySearch(value);
		if (i < list.size() && comparator.compare(list.get(i), value) == 0) {
			list.remove(i);
			return true;
		}
		return false;
	}

	@Override
	public int size() {
		return list.size();
	}

	// HACKATHON: binarySearch already returns "how many are smaller"
	@Override
	public int rank(T value) {
		return binarySearch(value);
	}

	@Override
	public T floor(T value) {
		int i = binarySearch(value);
		if (i < list.size() && comparator.compare(list.get(i), value) == 0) return list.get(i);
		return i == 0 ? null : list.get(i - 1);
	}

	@Override
	public T ceiling(T value) {
		int i = binarySearch(value);
		return i < list.size() ? list.get(i) : null;
	}
}
