package sorteddata;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * HACKATHON (Task 2 prediction): range queries on any SortedData.
 */
public final class SortedDataRanges {
	private SortedDataRanges() {}

	/**
	 * Elements x with  from <= x < toExclusive, in order. Lazily stops at the first
	 * element past the range, so it costs O(log n + k) for k results on an AVL tree.
	 * @param toExclusive null means "no upper bound"
	 */
	public static <T> Iterator<T> range(SortedData<T> data, T from, T toExclusive, Comparator<T> comparator) {
		Iterator<T> source = data.getRange(from, -1, false); // starts at the first element >= from
		return new Iterator<>() {
			private T next = advance();

			private T advance() {
				if (!source.hasNext()) return null;
				T candidate = source.next();
				if (toExclusive != null && comparator.compare(candidate, toExclusive) >= 0) return null;
				return candidate;
			}

			@Override
			public boolean hasNext() {
				return next != null;
			}

			@Override
			public T next() {
				if (next == null) throw new NoSuchElementException();
				T result = next;
				next = advance();
				return result;
			}
		};
	}

	/** Number of elements with from <= x < toExclusive, in O(log n) using rank. */
	public static <T> int count(SortedData<T> data, T from, T toExclusive) {
		int upper = toExclusive == null ? data.size() : data.rank(toExclusive);
		return Math.max(0, upper - data.rank(from));
	}
}
