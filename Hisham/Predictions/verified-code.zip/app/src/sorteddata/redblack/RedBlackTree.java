package sorteddata.redblack;

import sorteddata.SortedData;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Stack;

/**
 * HACKATHON (Task 2 prediction, "implement a red-black tree"): a LEFT-LEANING red-black tree
 * (Sedgewick). It is the easiest correct red-black variant: insert is 3 cases on the way back up.
 * Rules it keeps:
 *  1. links are red or black; red links only lean LEFT
 *  2. no node has two red links in a row
 *  3. every path from the root to an empty link has the same number of black links
 * => height <= 2 log2(n), so every operation is O(log n), like AVL.
 * Each node also stores its subtree size, for getAtIndex / rank in O(log n).
 * (Mutable, unlike the AVL tree. Delete is not implemented: remove() throws, like SortedData's default.)
 */
public class RedBlackTree<T> extends SortedData<T> {
	private static final boolean RED = true;
	private static final boolean BLACK = false;
	private static final Random random = new Random();

	private static final class Node<T> {
		T value;
		Node<T> left, right;
		boolean color = RED; // the link from the parent; new nodes are always red
		int size = 1;

		Node(T value) {
			this.value = value;
		}
	}

	private final Comparator<T> comparator;
	private Node<T> root;

	public RedBlackTree(Comparator<T> comparator) {
		this.comparator = comparator;
	}

	// ------------------------------------------------------------ helpers

	private static boolean isRed(Node<?> node) {
		return node != null && node.color == RED;
	}

	private static int size(Node<?> node) {
		return node == null ? 0 : node.size;
	}

	// right-leaning red link -> lean it left
	private Node<T> rotateLeft(Node<T> h) {
		Node<T> x = h.right;
		h.right = x.left;
		x.left = h;
		x.color = h.color;
		h.color = RED;
		x.size = h.size;
		h.size = 1 + size(h.left) + size(h.right);
		return x;
	}

	// two left reds in a row -> rotate right
	private Node<T> rotateRight(Node<T> h) {
		Node<T> x = h.left;
		h.left = x.right;
		x.right = h;
		x.color = h.color;
		h.color = RED;
		x.size = h.size;
		h.size = 1 + size(h.left) + size(h.right);
		return x;
	}

	// both children red -> push the red up (this is the 2-3 tree "split")
	private void flipColors(Node<T> h) {
		h.color = RED;
		h.left.color = BLACK;
		h.right.color = BLACK;
	}

	// ------------------------------------------------------------ SortedData

	@Override
	public boolean insert(T value) {
		if (get(value) != null) return false; // no duplicates
		root = insert(root, value);
		root.color = BLACK;
		notifyAdded(value);
		return true;
	}

	private Node<T> insert(Node<T> h, T value) {
		if (h == null) return new Node<>(value);
		if (comparator.compare(value, h.value) < 0) h.left = insert(h.left, value);
		else h.right = insert(h.right, value);

		// fix-up on the way back up: the three cases, in this order
		if (isRed(h.right) && !isRed(h.left)) h = rotateLeft(h);
		if (isRed(h.left) && isRed(h.left.left)) h = rotateRight(h);
		if (isRed(h.left) && isRed(h.right)) flipColors(h);
		h.size = 1 + size(h.left) + size(h.right);
		return h;
	}

	@Override
	public T get(T value) {
		Node<T> node = root;
		while (node != null) {
			int cmp = comparator.compare(value, node.value);
			if (cmp == 0) return node.value;
			node = cmp < 0 ? node.left : node.right;
		}
		return null;
	}

	@Override
	public T getAtIndex(int i) {
		if (i < 0 || i >= size()) return null;
		Node<T> node = root;
		while (true) {
			int leftSize = size(node.left);
			if (i < leftSize) node = node.left;
			else if (i == leftSize) return node.value;
			else {
				i -= leftSize + 1;
				node = node.right;
			}
		}
	}

	@Override
	public int rank(T value) {
		int result = 0;
		Node<T> node = root;
		while (node != null) {
			if (comparator.compare(value, node.value) <= 0) node = node.left;
			else {
				result += size(node.left) + 1;
				node = node.right;
			}
		}
		return result;
	}

	@Override
	public T floor(T target) {
		T best = null;
		Node<T> node = root;
		while (node != null) {
			int cmp = comparator.compare(target, node.value);
			if (cmp == 0) return node.value;
			if (cmp < 0) node = node.left;
			else {
				best = node.value; // candidate; maybe something bigger on the right is still <= target
				node = node.right;
			}
		}
		return best;
	}

	@Override
	public T ceiling(T target) {
		T best = null;
		Node<T> node = root;
		while (node != null) {
			int cmp = comparator.compare(target, node.value);
			if (cmp == 0) return node.value;
			if (cmp > 0) node = node.right;
			else {
				best = node.value;
				node = node.left;
			}
		}
		return best;
	}

	@Override
	public T getRandom() {
		return size() == 0 ? null : getAtIndex(random.nextInt(size()));
	}

	@Override
	public int size() {
		return size(root);
	}

	/** Same contract as AVLTree.getRange (stack-based in-order walk). */
	@Override
	public Iterator<T> getRange(T start, int count, boolean backwards) {
		Stack<Node<T>> stack = new Stack<>();
		Node<T> current = root;
		while (current != null) {
			int cmp = start == null ? (backwards ? 1 : -1) : comparator.compare(start, current.value);
			if (cmp == 0) {
				stack.push(current);
				break;
			}
			boolean goLeft = cmp < 0;
			if (goLeft != backwards) stack.push(current);
			current = goLeft ? current.left : current.right;
		}
		return new Iterator<>() {
			private int remaining = count;

			@Override
			public boolean hasNext() {
				return remaining != 0 && !stack.isEmpty();
			}

			@Override
			public T next() {
				if (!hasNext()) throw new NoSuchElementException();
				if (remaining > 0) remaining--;
				Node<T> node = stack.pop();
				Node<T> child = backwards ? node.left : node.right;
				while (child != null) {
					stack.push(child);
					child = backwards ? child.right : child.left;
				}
				return node.value;
			}
		};
	}

	// ------------------------------------------------------------ invariant check (for tests)

	/** @return true if all three red-black rules and the size fields hold */
	public boolean isValid() {
		return !isRed(root) && blackHeight(root) >= 0;
	}

	// returns the black height, or -1 if any rule is broken below this node
	private int blackHeight(Node<T> node) {
		if (node == null) return 0;
		if (isRed(node.right)) return -1;                       // rule 1: no right-leaning red
		if (isRed(node) && isRed(node.left)) return -1;          // rule 2: no two reds in a row
		if (node.size != 1 + size(node.left) + size(node.right)) return -1;
		int l = blackHeight(node.left), r = blackHeight(node.right);
		if (l < 0 || r < 0 || l != r) return -1;                 // rule 3: perfect black balance
		return l + (isRed(node) ? 0 : 1);
	}
}
