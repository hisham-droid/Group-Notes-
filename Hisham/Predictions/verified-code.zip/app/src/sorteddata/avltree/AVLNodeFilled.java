package sorteddata.avltree;

import java.util.Comparator;

class AVLNodeFilled<T> extends AVLNode<T> {
	final AVLNode<T> left, right;
	final T value;
	private final int height, balance, size;
	public AVLNodeFilled(Comparator<T> comparator, T value, AVLNode<T> left, AVLNode<T> right) {
		super(comparator);
		this.value = value;
		this.left = left;
		this.right = right;
		this.size = left.size() + right.size() + 1;
		this.height = Math.max(left.height(), right.height())+1;

		this.balance = left.height() - right.height();
	}

	public int height() {
		return height;
	}
	public int balanceFactor() {
		return balance;
	}
	public int size() {
		return size;
	}

	public String toString() {
		if (left instanceof AVLNodeEmpty<T> && right instanceof AVLNodeEmpty<T>)
			return value.toString();
		else
			return "%s -> (%s, %s)".formatted(value.toString(), left.toString(), right.toString());
	}

	public AVLNodeFilled<T> insert(T element) {
		if (comparator.compare(element, value) < 0) {
			AVLNodeFilled<T> subtree = left.insert(element);
			AVLNodeFilled<T> result = new AVLNodeFilled<>(comparator, value, subtree, right);

			if (result.balance < 2)
				return result;
			if (subtree.balance < 0)
				result = new AVLNodeFilled<>(comparator, value, subtree.leftRotate(), right);
			return result.rightRotate();
		} else if (comparator.compare(element, value) > 0) {
			AVLNodeFilled<T> subtree = right.insert(element);
			AVLNodeFilled<T> result = new AVLNodeFilled<>(comparator, value, left, subtree);

			if (result.balance > -2)
				return result;
			if (subtree.balance > 0)
				result = new AVLNodeFilled<>(comparator, value, left, subtree.rightRotate());
			return result.leftRotate();
		}
		return this;
	}

	/**
	 * Executes a left rotation on the current node, as defined
	 * by the AVL Tree algorithm.
	 * @return the new node taking this node's place after rotation
	 */
	private AVLNodeFilled<T> leftRotate() {
		AVLNodeFilled<T> rightFilled = (AVLNodeFilled<T>) right;
		AVLNodeFilled<T> newLeft = new AVLNodeFilled<>(comparator, value, left, rightFilled.left);
		return new AVLNodeFilled<>(comparator, rightFilled.value, newLeft, rightFilled.right);
	}

	/**
	 * Executes a right rotation on the current node, as defined
	 * by the AVL Tree algorithm.
	 * @return the new node taking this node's place after rotation
	 */
	private AVLNodeFilled<T> rightRotate() {
		AVLNodeFilled<T> leftFilled = (AVLNodeFilled<T>) left;
		AVLNodeFilled<T> newRight = new AVLNodeFilled<>(comparator, value, leftFilled.right, right);
		return new AVLNodeFilled<>(comparator, leftFilled.value, leftFilled.left, newRight);
	}

	public T getAtIndex(int i) {
		if (i < left.size()) return left.getAtIndex(i);
		else if (i == left.size()) return value;
		return right.getAtIndex(i - left.size() - 1);
	}

	public boolean contains(T element) {
		if (comparator.compare(value, element) < 0) {
			return right.contains(element);
		} else if (comparator.compare(element, value) < 0) {
			return left.contains(element);
		}
		return true;
	}

	public T get(T element) {
		if (comparator.compare(value, element) < 0) {
			return right.get(element);
		} else if (comparator.compare(element, value) < 0) {
			return left.get(element);
		}
		return value;
	}

	// ---------------------------------------------------------------------
	// HACKATHON: immutable AVL delete
	// NOTE: in THIS codebase balance = left.height - right.height
	//       (positive = left-heavy). If your base uses right - left, flip the signs.
	// ---------------------------------------------------------------------
	public AVLNode<T> delete(T element) {
		int cmp = comparator.compare(element, value);
		AVLNodeFilled<T> result;
		if (cmp < 0) {
			// target is in the left subtree: rebuild this node with the new left side
			result = new AVLNodeFilled<>(comparator, value, left.delete(element), right);
		} else if (cmp > 0) {
			// target is in the right subtree
			result = new AVLNodeFilled<>(comparator, value, left, right.delete(element));
		} else {
			// found it. Case 1 and 2: zero or one child -> the child replaces this node
			if (left instanceof AVLNodeEmpty<T>) return right;
			if (right instanceof AVLNodeEmpty<T>) return left;
			// Case 3: two children -> copy the in-order successor (smallest on the right)
			// into this position, then delete the successor from the right subtree
			T successor = ((AVLNodeFilled<T>) right).minValue();
			result = new AVLNodeFilled<>(comparator, successor, left, right.delete(successor));
		}
		return result.rebalance();
	}

	/** @return the smallest value in this subtree (keep going left) */
	private T minValue() {
		AVLNodeFilled<T> current = this;
		while (current.left instanceof AVLNodeFilled<T> next) current = next;
		return current.value;
	}

	/**
	 * Restores the AVL property at this node after a delete.
	 * Same four cases as insertion (LL, LR, RR, RL), but a delete can leave a
	 * child with balance 0, which is why we test "< 0" / "> 0" (not "<= 0").
	 */
	private AVLNodeFilled<T> rebalance() {
		if (balance > 1) { // left-heavy
			AVLNodeFilled<T> l = (AVLNodeFilled<T>) left;
			AVLNodeFilled<T> node = this;
			if (l.balance < 0) // left-right case: rotate the child first
				node = new AVLNodeFilled<>(comparator, value, l.leftRotate(), right);
			return node.rightRotate();
		}
		if (balance < -1) { // right-heavy
			AVLNodeFilled<T> r = (AVLNodeFilled<T>) right;
			AVLNodeFilled<T> node = this;
			if (r.balance > 0) // right-left case
				node = new AVLNodeFilled<>(comparator, value, left, r.rightRotate());
			return node.leftRotate();
		}
		return this; // already balanced
	}

	// ---------------------------------------------------------------------
	// HACKATHON: order statistics. Each node stores size, so we can count
	// "how many are smaller" on the way down without visiting every node.
	// ---------------------------------------------------------------------
	public int rank(T element) {
		if (comparator.compare(element, value) <= 0) return left.rank(element);   // everything here is in the left subtree
		return left.size() + 1 + right.rank(element);                              // whole left side + this node + part of the right
	}

	public T floor(T target) {
		int cmp = comparator.compare(target, value);
		if (cmp == 0) return value;
		if (cmp < 0) return left.floor(target);
		T better = right.floor(target);          // maybe something on the right is still <= target
		return better != null ? better : value;
	}

	public T ceiling(T target) {
		int cmp = comparator.compare(target, value);
		if (cmp == 0) return value;
		if (cmp > 0) return right.ceiling(target);
		T better = left.ceiling(target);
		return better != null ? better : value;
	}
}
