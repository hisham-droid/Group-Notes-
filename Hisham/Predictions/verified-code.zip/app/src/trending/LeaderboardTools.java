package trending;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import reactions.MessageReactions;
import reactions.ReactionStore;
import util.TopKIterator;
import votes.VoteTools;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * PREDICTED theme: leaderboards / karma. Factory picks what to count per user:
 *  "MESSAGES"  messages written
 *  "POSTS"     posts started
 *  "KARMA"     sum of vote scores of their messages
 *  "REACTIONS" reactions received on their messages
 * One pass over the data (O(n)) builds the totals, then TopKIterator picks the best.
 * Deleted users are skipped.
 */
public final class LeaderboardTools {
	private LeaderboardTools() {}

	private record Entry(User user, int value) {}

	public static Iterator<User> getTopUsers(String strategy, int amount) {
		Map<UUID, Integer> totals = new HashMap<>();
		switch (strategy == null ? "" : strategy) {
			case "MESSAGES" -> forEachMessage(m -> add(totals, m.poster(), 1));
			case "POSTS" -> PostDAO.getInstance().getAll().forEachRemaining(p -> add(totals, p.poster, 1));
			case "KARMA" -> forEachMessage(m -> add(totals, m.poster(), VoteTools.getScore(m.id())));
			case "REACTIONS" -> forEachMessage(m -> {
				MessageReactions r = ReactionStore.getInstance().find(m.id());
				add(totals, m.poster(), r == null ? 0 : r.total());
			});
			default -> throw new IllegalArgumentException("Unknown strategy: " + strategy);
		}
		java.util.List<Entry> entries = new java.util.ArrayList<>();
		totals.forEach((id, value) -> {
			User u = UserDAO.getInstance().getByUUID(id);
			if (u != null) entries.add(new Entry(u, value));
		});
		return new TopKIterator<>(entries, Comparator.comparingInt(Entry::value).reversed(),
				e -> e.value() > 0, Entry::user, amount);
	}

	private static void add(Map<UUID, Integer> totals, UUID user, int amount) {
		if (user != null) totals.merge(user, amount, Integer::sum);
	}

	private static void forEachMessage(java.util.function.Consumer<Message> action) {
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) it.next().messages.getAll().forEachRemaining(action);
	}
}
