package trending;

import dao.PostDAO;
import dao.model.Post;
import queries.MessageQueries;
import util.TopKIterator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * PREDICTED theme: trending posts = most messages in the last `windowMillis`.
 * Per post the count is O(log n) (rank on the tree), so the whole query is O(P log n + k log P).
 */
public final class TrendingTools {
	private TrendingTools() {}

	private record Activity(Post post, int count) {}

	/** @return up to `amount` posts with recent activity, most active first */
	public static Iterator<Post> getTrendingPosts(long now, long windowMillis, int amount) {
		if (windowMillis <= 0) throw new IllegalArgumentException("window must be positive");
		List<Activity> activity = new ArrayList<>();
		for (Iterator<Post> it = PostDAO.getInstance().getAll(); it.hasNext(); ) {
			Post post = it.next();
			activity.add(new Activity(post, MessageQueries.countMessagesBetween(post.id, now - windowMillis, now, false)));
		}
		return new TopKIterator<>(activity, Comparator.comparingInt(Activity::count).reversed(),
				a -> a.count() > 0, Activity::post, amount);
	}

	/**
	 * Factory for post rankings: "BUSY" (most messages ever) or "ACTIVE" (latest message first).
	 */
	public static Iterator<Post> getTopPosts(String strategy, int amount) {
		Comparator<Post> order = switch (strategy == null ? "" : strategy) {
			case "BUSY" -> Comparator.comparingInt((Post p) -> p.messages.size()).reversed();
			case "ACTIVE" -> Comparator.comparingLong(TrendingTools::lastActivity).reversed();
			default -> throw new IllegalArgumentException("Unknown strategy: " + strategy);
		};
		List<Post> posts = new ArrayList<>();
		PostDAO.getInstance().getAll().forEachRemaining(posts::add);
		return new TopKIterator<>(posts, order, p -> p.messages.size() > 0, p -> p, amount);
	}

	private static long lastActivity(Post post) {
		Iterator<dao.model.Message> last = post.messages.getRange(null, 1, true); // newest message
		return last.hasNext() ? last.next().timestamp() : Long.MIN_VALUE;
	}
}
