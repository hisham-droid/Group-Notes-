package posts;

import dao.MessageIndex;
import dao.PostDAO;
import dao.model.Message;
import dao.model.Post;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * PREDICTED theme: merge two posts / split a post (admin).
 * Messages keep their ids, so reports, reactions, votes and edits stay attached.
 * A message's post id (thread) is part of the immutable record, so each move is
 * remove + insert of a copy with the new thread (same idea as MoveTools).
 */
public final class PostTools {
	private PostTools() {}

	/** Moves every message of `source` into `target`, then deletes `source`. Admin only. */
	public static boolean mergePosts(UUID source, UUID target, UUID admin) {
		Post from = find(source), to = find(target);
		if (from == null || to == null || source.equals(target) || !isAdmin(admin)) return false;
		for (Message m : snapshot(from.messages.getAll())) moveInto(from, to, m);
		PostDAO.getInstance().remove(from);
		return true;
	}

	/**
	 * Moves `firstMessage` and every LATER message of its post into a new post.
	 * @return the new post's id, or null if not allowed
	 */
	public static UUID splitPost(UUID firstMessage, String newTopic, UUID admin) {
		Message first = MessageIndex.getInstance().get(firstMessage);
		if (first == null || newTopic == null || !isAdmin(admin)) return null;
		Post from = MessageIndex.getInstance().getPostOf(first);
		Post to = new Post(UUID.randomUUID(), first.poster(), newTopic);
		PostDAO.getInstance().add(to);
		// getRange(first, -1, false) = first and everything after it, in order
		for (Message m : snapshot(from.messages.getRange(first, -1, false))) moveInto(from, to, m);
		return to.id;
	}

	// copy first: we must not change a tree while iterating it
	private static List<Message> snapshot(Iterator<Message> it) {
		List<Message> list = new ArrayList<>();
		it.forEachRemaining(list::add);
		return list;
	}

	private static void moveInto(Post from, Post to, Message m) {
		boolean hidden = from.isHidden(m.id()), deleted = from.isDeleted(m.id());
		from.removeMessage(m);
		Message moved = new Message(m.id(), m.poster(), to.id, m.timestamp(), m.message());
		to.messages.insert(moved);
		if (hidden) to.setHidden(moved, true);
		if (deleted) to.setDeleted(moved, true);
	}

	private static Post find(UUID id) {
		return id == null ? null : PostDAO.getInstance().get(new Post(id));
	}

	private static boolean isAdmin(UUID user) {
		return accounts.Permissions.isAdmin(user); // one shared permission check
	}
}
