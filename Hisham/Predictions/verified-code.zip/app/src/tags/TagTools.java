package tags;

import dao.PostDAO;
import dao.UserDAO;
import dao.model.Post;
import dao.model.User;
import relations.RelationStore;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

/**
 * PREDICTED Task 1 theme: tags / hashtags on posts.
 * Stored as a RelationStore post -> tag, so both "tags of a post" and "posts with a tag" are O(1).
 * Tags are normalised (trimmed, lower-case, leading # removed) so "#Exam" and "exam" are the same.
 */
public final class TagTools {
	private static final int MAX_TAG_LENGTH = 30;
	private static final RelationStore<UUID, String> tags = new RelationStore<>();

	private TagTools() {}

	/** @return the normalised tag, or null if it is not valid (1-30 letters/digits) */
	public static String normalise(String tag) {
		if (tag == null) return null;
		String t = tag.trim().toLowerCase();
		if (t.startsWith("#")) t = t.substring(1);
		if (t.isEmpty() || t.length() > MAX_TAG_LENGTH) return null;
		for (char c : t.toCharArray()) if (!Character.isLetterOrDigit(c)) return null;
		return t;
	}

	/** Post author or Admin only. @return false if invalid, not allowed, or already tagged */
	public static boolean addTag(UUID post, UUID user, String tag) {
		String t = normalise(tag);
		if (t == null || !canEdit(post, user)) return false;
		return tags.add(post, t);
	}

	public static boolean removeTag(UUID post, UUID user, String tag) {
		String t = normalise(tag);
		if (t == null || !canEdit(post, user)) return false;
		return tags.remove(post, t);
	}

	/** @return tags of a post, alphabetically */
	public static Set<String> getTags(UUID post) {
		return new TreeSet<>(tags.targetsOf(post));
	}

	/** @return posts with this tag (any order) */
	public static Set<UUID> getPostsWithTag(String tag) {
		String t = normalise(tag);
		return t == null ? Set.of() : tags.sourcesOf(t);
	}

	/** @return the most used tags, most posts first (ties alphabetical) */
	public static List<String> getPopularTags(int amount) {
		if (amount <= 0) throw new IllegalArgumentException("amount must be positive");
		List<String> all = new ArrayList<>();
		for (UUID post : tags.sources()) all.addAll(tags.targetsOf(post));
		List<String> unique = new ArrayList<>(new TreeSet<>(all));
		unique.sort(Comparator.comparingInt((String t) -> tags.countSources(t)).reversed().thenComparing(Comparator.naturalOrder()));
		return unique.subList(0, Math.min(amount, unique.size()));
	}

	/** raw store, for persistence */
	public static RelationStore<UUID, String> store() {
		return tags;
	}

	public static void clear() {
		tags.clear();
	}

	private static boolean canEdit(UUID post, UUID user) {
		Post p = post == null ? null : PostDAO.getInstance().get(new Post(post));
		User u = UserDAO.getInstance().getByUUID(user);
		return p != null && u != null && (u.role() == User.Role.Admin || u.id().equals(p.poster));
	}
}
