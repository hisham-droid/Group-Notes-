import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;

import java.util.*;

import static org.junit.Assert.*;

/**
 * PREDICTION (reactions variant of Task 5, black-box) for ReactionTools.getTopMessages.
 * Uses ReactionType.values()[i] so it compiles with any real enum constants (needs >= 2).
 */
public class ReactionToolsGetTopMessagesTests {
	private final List<User> users = new ArrayList<>();
	private final List<Message> messages = new ArrayList<>();
	private ReactionType first, second;

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		ReactionStore.getInstance().clear();
		users.clear();
		messages.clear();
		first = ReactionType.values()[0];
		second = ReactionType.values()[1];
		for (int i = 0; i < 5; i++) {
			User u = new User(UUID.randomUUID(), User.Role.Member, "user" + i, "password");
			UserDAO.getInstance().add(u);
			users.add(u);
		}
		Post post = new Post(UUID.randomUUID(), users.get(0).id(), "t");
		PostDAO.getInstance().add(post);
		for (int i = 0; i < 4; i++) {
			Message m = new Message(UUID.randomUUID(), users.get(0).id(), post.id, i, "m" + i);
			post.messages.insert(m);
			messages.add(m);
		}
	}

	private void react(int message, int user, ReactionType type, long time) {
		assertTrue("setup", ReactionTools.addReaction(messages.get(message).id(), users.get(user).id(), type, time));
	}

	private List<Message> top(String strategy, int amount) {
		List<Message> l = new ArrayList<>();
		ReactionTools.getTopMessages(strategy, amount).forEachRemaining(l::add);
		return l;
	}

	private List<Message> expected(int... i) {
		List<Message> l = new ArrayList<>();
		for (int x : i) l.add(messages.get(x));
		return l;
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class) public void unknownStrategy() { top("BEST", 1); }
	@Test(timeout = 1000, expected = IllegalArgumentException.class) public void nullStrategy() { top(null, 1); }
	@Test(timeout = 1000, expected = IllegalArgumentException.class) public void zeroAmount() { top("MOST", 0); }

	@Test(timeout = 1000) public void emptyWhenNoReactions() {
		assertTrue(top("MOST", 3).isEmpty());
	}

	@Test(timeout = 1000) public void mostOrdersByTotal() {
		react(2, 1, first, 1);
		react(0, 1, first, 1); react(0, 2, second, 1); react(0, 3, first, 1);
		react(3, 1, second, 1); react(3, 2, second, 1);
		assertEquals(expected(0, 3, 2), top("MOST", 5));
		assertEquals(expected(0, 3), top("MOST", 2));
	}

	@Test(timeout = 1000) public void perTypeCountsOnlyThatType() {
		react(0, 1, first, 1); react(0, 2, first, 1);
		react(1, 1, second, 1); react(1, 2, second, 1); react(1, 3, second, 1);
		react(2, 1, first, 1);
		assertEquals(expected(0, 2), top(first.name(), 5));
		assertEquals(expected(1), top(second.name(), 5));
	}

	@Test(timeout = 1000) public void newestFirst() {
		react(0, 1, first, 300); react(1, 1, first, 100); react(2, 1, first, 200);
		assertEquals(expected(0, 2, 1), top("NEWEST", 5));
	}

	@Test(timeout = 1000) public void removedReactionsDoNotCount() {
		react(0, 1, first, 1); react(0, 2, first, 1);
		react(1, 1, first, 1);
		ReactionTools.removeReaction(messages.get(0).id(), users.get(1).id());
		ReactionTools.removeReaction(messages.get(0).id(), users.get(2).id());
		assertEquals(expected(1), top("MOST", 5));
	}

	@Test(timeout = 1000) public void eachMessageOnce() {
		for (int u = 1; u < 5; u++) react(0, u, first, u);
		assertEquals(expected(0), top("MOST", 5));
	}
}
