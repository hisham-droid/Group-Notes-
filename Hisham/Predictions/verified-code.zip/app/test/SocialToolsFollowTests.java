import dao.PostDAO;
import dao.UserDAO;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import relations.SocialTools;

import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * PREDICTION (follow variant of Task 5, white-box): branch coverage of SocialTools.follow,
 * usersExist and RelationStore.add.
 * Branch map:
 *  follow: !usersExist -> missingFollower / missingFollowee; self -> selfFollow; else -> RelationStore.add
 *  usersExist (&&): follower missing (short-circuit) -> missingFollower; followee missing -> missingFollowee
 *  RelationStore.add: forward set new/existing (computeIfAbsent) -> follow / secondFollowBySameUser;
 *                     pair already there -> followTwice
 */
public class SocialToolsFollowTests {
	private User a, b, c;

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		SocialTools.clearAll();
		a = new User(UUID.randomUUID(), User.Role.Member, "aaaa", "password");
		b = new User(UUID.randomUUID(), User.Role.Member, "bbbb", "password");
		c = new User(UUID.randomUUID(), User.Role.Member, "cccc", "password");
		UserDAO.getInstance().add(a);
		UserDAO.getInstance().add(b);
		UserDAO.getInstance().add(c);
	}

	@Test(timeout = 1000) public void follow() {
		assertTrue(SocialTools.follow(a.id(), b.id()));
		assertTrue(SocialTools.isFollowing(a.id(), b.id()));
		assertFalse("not symmetric", SocialTools.isFollowing(b.id(), a.id()));
		assertEquals(Set.of(a.id()), SocialTools.getFollowers(b.id()));
	}

	@Test(timeout = 1000) public void secondFollowBySameUser() {
		SocialTools.follow(a.id(), b.id());
		assertTrue(SocialTools.follow(a.id(), c.id()));
		assertEquals(1, SocialTools.followerCount(c.id()));
	}

	@Test(timeout = 1000) public void followTwice() {
		SocialTools.follow(a.id(), b.id());
		assertFalse(SocialTools.follow(a.id(), b.id()));
		assertEquals(1, SocialTools.followerCount(b.id()));
	}

	@Test(timeout = 1000) public void selfFollow() {
		assertFalse(SocialTools.follow(a.id(), a.id()));
	}

	@Test(timeout = 1000) public void missingFollower() {
		assertFalse(SocialTools.follow(UUID.randomUUID(), b.id()));
		assertEquals(0, SocialTools.followerCount(b.id()));
	}

	@Test(timeout = 1000) public void missingFollowee() {
		assertFalse(SocialTools.follow(a.id(), UUID.randomUUID()));
	}
}
