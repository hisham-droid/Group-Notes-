import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;

import java.util.UUID;

import static org.junit.Assert.*;

/**
 * PREDICTION (reactions variant of Task 5): branch coverage of ReactionTools.addReaction.
 * Branches: type == null | message missing | user missing | already reacted | success
 * (+ MessageReactions.add: first reaction on message vs. existing group; counts.merge new vs existing key)
 */
public class ReactionToolsAddReactionTests {
	private User user, other;
	private Message message;

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		ReactionStore.getInstance().clear();
		user = new User(UUID.randomUUID(), User.Role.Member, "reactor", "password");
		other = new User(UUID.randomUUID(), User.Role.Member, "reactor2", "password");
		UserDAO.getInstance().add(user);
		UserDAO.getInstance().add(other);
		Post post = new Post(UUID.randomUUID(), user.id(), "topic");
		PostDAO.getInstance().add(post);
		message = new Message(UUID.randomUUID(), user.id(), post.id, 1, "hi");
		post.messages.insert(message);
	}

	@Test public void success() {
		assertTrue(ReactionTools.addReaction(message.id(), user.id(), ReactionType.values()[0], 5));
		assertEquals(ReactionType.values()[0], ReactionTools.getReaction(message.id(), user.id()));
		assertEquals(1, ReactionTools.countReactions(message.id(), ReactionType.values()[0]));
	}
	@Test public void sameTypeFromSecondUserIncrementsCount() {
		ReactionType type = ReactionType.values()[0];
		ReactionTools.addReaction(message.id(), user.id(), type, 5);
		assertTrue(ReactionTools.addReaction(message.id(), other.id(), type, 6));
		assertEquals(2, ReactionTools.countReactions(message.id(), type));
	}
	@Test public void alreadyReacted() {
		ReactionTools.addReaction(message.id(), user.id(), ReactionType.values()[0], 5);
		assertFalse(ReactionTools.addReaction(message.id(), user.id(), ReactionType.values()[1], 6));
		assertEquals("count must not change", 0, ReactionTools.countReactions(message.id(), ReactionType.values()[1]));
	}
	@Test public void nullType() {
		assertFalse(ReactionTools.addReaction(message.id(), user.id(), null, 5));
	}
	@Test public void missingMessage() {
		assertFalse(ReactionTools.addReaction(UUID.randomUUID(), user.id(), ReactionType.values()[0], 5));
	}
	@Test public void missingUser() {
		assertFalse(ReactionTools.addReaction(message.id(), UUID.randomUUID(), ReactionType.values()[0], 5));
		assertFalse(ReactionTools.hasReacted(message.id(), user.id()));
	}
}
