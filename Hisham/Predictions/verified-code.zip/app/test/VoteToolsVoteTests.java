import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import votes.VoteTools;

import java.util.UUID;

import static org.junit.Assert.*;

/**
 * PREDICTION (votes variant of Task 5, white-box): branch coverage of VoteTools.vote
 * and the helpers it calls.
 * Branch map:
 *  vote:  direction != UP && != DOWN -> badDirection*; !exists -> missingMessage / missingUser; else -> MessageVotes.set
 *  ||  :  direction == UP (first operand false) -> upvote; == DOWN -> downvote; neither -> badDirectionZero / Two
 *  exists (&&): message missing -> missingMessage (short-circuit); user missing -> missingUser
 *  computeIfAbsent: first vote on message -> upvote; existing group -> secondUserVotes
 *  MessageVotes.set: previous == null -> upvote; previous == same -> sameVoteTwice; previous == other -> switchVote
 *  count(): direction > 0 -> upvote; else -> downvote
 */
public class VoteToolsVoteTests {
	private User voter, other;
	private Message message;

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		VoteTools.clear();
		voter = new User(UUID.randomUUID(), User.Role.Member, "voter", "password");
		other = new User(UUID.randomUUID(), User.Role.Member, "otherVoter", "password");
		UserDAO.getInstance().add(voter);
		UserDAO.getInstance().add(other);
		Post post = new Post(UUID.randomUUID(), voter.id(), "topic");
		PostDAO.getInstance().add(post);
		message = new Message(UUID.randomUUID(), voter.id(), post.id, 1, "hi");
		post.messages.insert(message);
	}

	@Test(timeout = 1000) public void upvote() {
		assertTrue(VoteTools.vote(message.id(), voter.id(), VoteTools.UP, 5));
		assertEquals(1, VoteTools.getScore(message.id()));
	}

	@Test(timeout = 1000) public void downvote() {
		assertTrue(VoteTools.vote(message.id(), voter.id(), VoteTools.DOWN, 5));
		assertEquals(-1, VoteTools.getScore(message.id()));
	}

	@Test(timeout = 1000) public void secondUserVotes() {
		VoteTools.vote(message.id(), voter.id(), VoteTools.UP, 5);
		assertTrue(VoteTools.vote(message.id(), other.id(), VoteTools.UP, 6));
		assertEquals(2, VoteTools.getScore(message.id()));
	}

	@Test(timeout = 1000) public void sameVoteTwice() {
		VoteTools.vote(message.id(), voter.id(), VoteTools.UP, 5);
		assertFalse(VoteTools.vote(message.id(), voter.id(), VoteTools.UP, 6));
		assertEquals("score must not change", 1, VoteTools.getScore(message.id()));
	}

	@Test(timeout = 1000) public void switchVote() {
		VoteTools.vote(message.id(), voter.id(), VoteTools.UP, 5);
		assertTrue(VoteTools.vote(message.id(), voter.id(), VoteTools.DOWN, 6));
		assertEquals(-1, VoteTools.getScore(message.id()));
		assertEquals(0, VoteTools.getUpvotes(message.id()));
	}

	@Test(timeout = 1000) public void badDirectionZero() {
		assertFalse(VoteTools.vote(message.id(), voter.id(), 0, 5));
		assertEquals(0, VoteTools.getVote(message.id(), voter.id()));
	}

	@Test(timeout = 1000) public void badDirectionTwo() {
		assertFalse(VoteTools.vote(message.id(), voter.id(), 2, 5));
	}

	@Test(timeout = 1000) public void missingMessage() {
		assertFalse(VoteTools.vote(UUID.randomUUID(), voter.id(), VoteTools.UP, 5));
	}

	@Test(timeout = 1000) public void missingUser() {
		assertFalse(VoteTools.vote(message.id(), UUID.randomUUID(), VoteTools.UP, 5));
		assertEquals(0, VoteTools.getScore(message.id()));
	}
}
