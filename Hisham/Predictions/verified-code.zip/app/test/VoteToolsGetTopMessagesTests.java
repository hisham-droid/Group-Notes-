import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import votes.VoteTools;

import java.util.*;

import static org.junit.Assert.*;

/** PREDICTION (votes variant of Task 5, black-box) for VoteTools.getTopMessages. */
public class VoteToolsGetTopMessagesTests {
	private final List<User> users = new ArrayList<>();
	private final List<Message> messages = new ArrayList<>();

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		VoteTools.clear();
		users.clear();
		messages.clear();
		for (int i = 0; i < 5; i++) {
			User u = new User(UUID.randomUUID(), User.Role.Member, "user" + i, "password");
			UserDAO.getInstance().add(u);
			users.add(u);
		}
		Post post = new Post(UUID.randomUUID(), users.get(0).id(), "t");
		PostDAO.getInstance().add(post);
		for (int i = 0; i < 4; i++) {
			Message m = new Message(UUID.randomUUID(), users.get(0).id(), post.id, i, "m" + i);
			post.messages.insert(m);
			messages.add(m);
		}
	}

	private void vote(int message, int user, int direction, long time) {
		assertTrue("setup", VoteTools.vote(messages.get(message).id(), users.get(user).id(), direction, time));
	}

	private List<Message> top(String strategy, int amount) {
		List<Message> l = new ArrayList<>();
		VoteTools.getTopMessages(strategy, amount).forEachRemaining(l::add);
		return l;
	}

	private List<Message> expected(int... i) {
		List<Message> l = new ArrayList<>();
		for (int x : i) l.add(messages.get(x));
		return l;
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class) public void unknownStrategy() { top("HOT", 1); }
	@Test(timeout = 1000, expected = IllegalArgumentException.class) public void negativeAmount() { top("TOP", -2); }

	@Test(timeout = 1000) public void topByScoreNotByVoteCount() {
		vote(0, 1, 1, 1); vote(0, 2, 1, 1); vote(0, 3, -1, 1);          // score 1, 3 votes
		vote(1, 1, 1, 1); vote(1, 2, 1, 1);                             // score 2, 2 votes
		vote(2, 1, -1, 1);                                              // score -1
		assertEquals(expected(1, 0, 2), top("TOP", 5));
		assertEquals(expected(1), top("TOP", 1));
	}

	@Test(timeout = 1000) public void switchedVotesAreCountedOnce() {
		vote(0, 1, 1, 1);
		vote(0, 1, -1, 2);                     // switch: score -1, not 0
		vote(1, 1, 1, 3);
		assertEquals(expected(1, 0), top("TOP", 5));
	}

	@Test(timeout = 1000) public void switchesReplaceTheOldVote() {
		vote(0, 1, 1, 1); vote(0, 1, -1, 2);   // user 1 switches up -> down
		vote(0, 2, 1, 3); vote(0, 2, -1, 4);   // user 2 switches up -> down: score must be -2 (not 0)
		vote(1, 3, -1, 5);                     // score -1
		assertEquals(expected(1, 0), top("TOP", 5));
	}

	@Test(timeout = 1000) public void controversialNeedsBothSides() {
		vote(0, 1, 1, 1); vote(0, 2, 1, 1); vote(0, 3, 1, 1);            // all up
		vote(1, 1, 1, 1); vote(1, 2, -1, 1);                            // 1 vs 1
		vote(2, 1, 1, 1); vote(2, 2, 1, 1); vote(2, 3, -1, 1); vote(2, 4, -1, 1); // 2 vs 2
		assertEquals(expected(2, 1, 0), top("CONTROVERSIAL", 5));
	}

	@Test(timeout = 1000) public void newestVoteFirst() {
		vote(0, 1, 1, 50); vote(1, 1, 1, 70); vote(2, 1, -1, 60);
		assertEquals(expected(1, 2, 0), top("NEWEST", 5));
	}

	@Test(timeout = 1000) public void retractedVotesExcluded() {
		vote(0, 1, 1, 1);
		VoteTools.removeVote(messages.get(0).id(), users.get(1).id());
		vote(1, 1, 1, 1);
		assertEquals(expected(1), top("TOP", 5));
	}
}
