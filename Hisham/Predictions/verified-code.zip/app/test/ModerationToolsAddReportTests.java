import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.UUID;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Task 5 (white-box): branch-complete coverage of ModerationTools.addReport and every
 * helper our team wrote that it calls. Each test names the branch it covers.
 *
 * Branch map (decision -> tests):
 *  addReport:                 exists? false -> unknownMessage..., true -> validReport
 *  messageAndUserExist (&&):  message missing (short-circuit) -> unknownMessage; user missing -> unknownUser
 *  MessageIndex.get:          id == null -> nullMessage; not indexed -> unknownMessage;
 *                             thread == null -> messageWithoutThread; post gone -> postRemovedFromDAO;
 *                             message gone from post -> messageRemovedFromPost; found -> validReport
 *  UserDAO.getByUUID:         id == null -> nullUser; missing -> unknownUser; found -> validReport
 *  MessageReports.add:        new reporter -> validReport; same reporter -> duplicateReport
 *  ReportStore.add:           first report on message -> validReport; existing group -> secondUserCanReport
 */
@RunWith(JUnit4.class)
public class ModerationToolsAddReportTests {
	private User reporter;
	private User otherReporter;
	private Post post;
	private Message message;

	@Before
	public void setUp() {
		// fresh state for every test (the DAOs and store are singletons)
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		ReportStore.getInstance().clear();

		reporter = new User(UUID.randomUUID(), User.Role.Member, "reporter", "password");
		otherReporter = new User(UUID.randomUUID(), User.Role.Member, "otherReporter", "password");
		UserDAO.getInstance().add(reporter);
		UserDAO.getInstance().add(otherReporter);

		post = new Post(UUID.randomUUID(), reporter.id(), "topic");
		PostDAO.getInstance().add(post);
		message = new Message(UUID.randomUUID(), reporter.id(), post.id, 1000, "hello");
		post.messages.insert(message);
	}

	@Test(timeout = 1000)
	public void validReport() {
		assertTrue("A first report on an existing message must succeed",
				ModerationTools.addReport(message.id(), reporter.id(), 2000));
		assertTrue(ModerationTools.hasReported(message.id(), reporter.id()));
	}

	@Test(timeout = 1000)
	public void secondUserCanReport() {
		ModerationTools.addReport(message.id(), reporter.id(), 2000);
		assertTrue("A different user may report the same message",
				ModerationTools.addReport(message.id(), otherReporter.id(), 2001));
	}

	@Test(timeout = 1000)
	public void duplicateReport() {
		ModerationTools.addReport(message.id(), reporter.id(), 2000);
		assertFalse("The same user cannot report the same message twice",
				ModerationTools.addReport(message.id(), reporter.id(), 3000));
	}

	@Test(timeout = 1000)
	public void unknownMessage() {
		assertFalse(ModerationTools.addReport(UUID.randomUUID(), reporter.id(), 2000));
	}

	@Test(timeout = 1000)
	public void nullMessage() {
		assertFalse(ModerationTools.addReport(null, reporter.id(), 2000));
	}

	@Test(timeout = 1000)
	public void unknownUser() {
		assertFalse(ModerationTools.addReport(message.id(), UUID.randomUUID(), 2000));
		assertFalse("A failed report must not be stored",
				ModerationTools.hasReported(message.id(), reporter.id()));
	}

	@Test(timeout = 1000)
	public void nullUser() {
		assertFalse(ModerationTools.addReport(message.id(), null, 2000));
	}

	@Test(timeout = 1000)
	public void messageWithoutThread() {
		Message orphan = new Message(UUID.randomUUID(), reporter.id(), null, 5, "no thread");
		post.messages.insert(orphan); // indexed, but it does not belong to a stored post
		assertFalse(ModerationTools.addReport(orphan.id(), reporter.id(), 2000));
	}

	@Test(timeout = 1000)
	public void postRemovedFromDAO() {
		PostDAO.getInstance().clear(); // the message's post no longer exists
		assertFalse(ModerationTools.addReport(message.id(), reporter.id(), 2000));
	}

	@Test(timeout = 1000)
	public void messageRemovedFromPost() {
		post.messages.remove(message); // post exists, message does not
		assertFalse(ModerationTools.addReport(message.id(), reporter.id(), 2000));
	}
}
