import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Task 5 (black-box): tests ONLY what the Task 4 spec promises for getReportedMessages.
 * Deliberately NOT tested (unspecified, a correct implementation may differ):
 *  - the order of tied messages
 *  - what next() does after the end (NoSuchElementException is not in the spec)
 *  - case-insensitive strategy names
 */
@RunWith(JUnit4.class)
public class ModerationToolsGetReportsTests {
	private final List<User> users = new ArrayList<>();
	private final List<Message> messages = new ArrayList<>();

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		ReportStore.getInstance().clear();
		users.clear();
		messages.clear();

		for (int i = 0; i < 5; i++) {
			User user = new User(UUID.randomUUID(), i == 0 ? User.Role.Admin : User.Role.Member, "user" + i, "password");
			UserDAO.getInstance().add(user);
			users.add(user);
		}
		Post post = new Post(UUID.randomUUID(), users.get(0).id(), "topic");
		PostDAO.getInstance().add(post);
		for (int i = 0; i < 5; i++) {
			Message message = new Message(UUID.randomUUID(), users.get(0).id(), post.id, i, "message " + i);
			post.messages.insert(message);
			messages.add(message);
		}
	}

	// ---------------------------------------------------------------- helpers

	private void report(int message, int user, long timestamp) {
		assertTrue("test setup failed", ModerationTools.addReport(messages.get(message).id(), users.get(user).id(), timestamp));
	}

	private void unreport(int message, int user) {
		assertTrue("test setup failed", ModerationTools.removeReport(messages.get(message).id(), users.get(user).id(), 0));
	}

	private List<Message> collect(String strategy, int amount) {
		List<Message> result = new ArrayList<>();
		Iterator<Message> iterator = ModerationTools.getReportedMessages(strategy, amount);
		while (iterator.hasNext()) result.add(iterator.next());
		return result;
	}

	private List<Message> expected(int... indices) {
		List<Message> result = new ArrayList<>();
		for (int i : indices) result.add(messages.get(i));
		return result;
	}

	// ---------------------------------------------------------------- invalid input

	@Test(timeout = 1000, expected = IllegalArgumentException.class)
	public void unknownStrategyThrows() {
		ModerationTools.getReportedMessages("NEWEST", 3);
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class)
	public void nullStrategyThrows() {
		ModerationTools.getReportedMessages(null, 3);
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class)
	public void emptyStrategyThrows() {
		ModerationTools.getReportedMessages("", 3);
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class)
	public void zeroAmountThrows() {
		report(0, 1, 10);
		ModerationTools.getReportedMessages("MOST", 0);
	}

	@Test(timeout = 1000, expected = IllegalArgumentException.class)
	public void negativeAmountThrows() {
		report(0, 1, 10);
		ModerationTools.getReportedMessages("OLDEST", -1);
	}

	// ---------------------------------------------------------------- empty results

	@Test(timeout = 1000)
	public void noReportsGivesEmptyIterator() {
		assertTrue(collect("MOST", 3).isEmpty());
		assertTrue(collect("OLDEST", 3).isEmpty());
	}

	@Test(timeout = 1000)
	public void fullyRetractedMessageIsExcluded() {
		report(0, 1, 10);
		report(1, 1, 20);
		unreport(0, 1);
		assertEquals(expected(1), collect("MOST", 5));
		assertEquals(expected(1), collect("OLDEST", 5));
	}

	// ---------------------------------------------------------------- MOST

	@Test(timeout = 1000)
	public void mostOrdersByActiveReportCount() {
		report(2, 1, 10);                                    // 1 report
		report(0, 1, 10); report(0, 2, 10); report(0, 3, 10); // 3 reports
		report(4, 1, 10); report(4, 2, 10);                   // 2 reports
		assertEquals(expected(0, 4, 2), collect("MOST", 5));
	}

	@Test(timeout = 1000)
	public void mostIgnoresRetractedReports() {
		report(0, 1, 10); report(0, 2, 10); report(0, 3, 10); // 3, then 1 after retractions
		report(1, 1, 10); report(1, 2, 10);                   // 2
		unreport(0, 2);
		unreport(0, 3);
		assertEquals(expected(1, 0), collect("MOST", 5));
	}

	// ---------------------------------------------------------------- OLDEST

	@Test(timeout = 1000)
	public void oldestOrdersByOldestReport() {
		report(0, 1, 300);
		report(1, 1, 100);
		report(2, 1, 200);
		report(2, 2, 50); // message 2's oldest report is 50
		assertEquals(expected(2, 1, 0), collect("OLDEST", 5));
	}

	@Test(timeout = 1000)
	public void oldestUsesOldestActiveReport() {
		report(0, 1, 100);
		report(1, 1, 50);
		report(1, 2, 500);
		unreport(1, 1); // message 1's oldest ACTIVE report is now 500
		assertEquals(expected(0, 1), collect("OLDEST", 5));
	}

	@Test(timeout = 1000)
	public void strategiesGiveDifferentOrders() {
		report(0, 1, 10);                                      // oldest, fewest
		report(1, 1, 20); report(1, 2, 21); report(1, 3, 22);  // newest, most
		assertEquals(expected(0, 1), collect("OLDEST", 5));
		assertEquals(expected(1, 0), collect("MOST", 5));
	}

	// ---------------------------------------------------------------- amount

	@Test(timeout = 1000)
	public void amountLimitsResults() {
		report(0, 1, 10); report(0, 2, 11); report(0, 3, 12);
		report(1, 1, 20); report(1, 2, 21);
		report(2, 1, 30);
		assertEquals(expected(0), collect("MOST", 1));
		assertEquals(expected(0, 1), collect("MOST", 2));
		assertEquals(expected(0, 1), collect("OLDEST", 2));
	}

	@Test(timeout = 1000)
	public void amountLargerThanAvailableReturnsAll() {
		report(3, 1, 10);
		report(4, 1, 20);
		assertEquals(expected(3, 4), collect("OLDEST", 100));
	}

	@Test(timeout = 1000)
	public void amountExactlyAvailable() {
		report(3, 1, 10);
		report(4, 1, 20);
		assertEquals(expected(3, 4), collect("OLDEST", 2));
	}

	// ---------------------------------------------------------------- uniqueness, ties, hidden

	@Test(timeout = 1000)
	public void messageReportedManyTimesAppearsOnce() {
		for (int user = 1; user < 5; user++) report(0, user, 10 + user);
		assertEquals(expected(0), collect("MOST", 10));
		assertEquals(expected(0), collect("OLDEST", 10));
	}

	@Test(timeout = 1000)
	public void tiesMayBeInAnyOrder() {
		report(0, 1, 10); report(1, 1, 10); report(2, 1, 10); // same count AND same timestamp
		Set<Message> most = new HashSet<>(collect("MOST", 5));
		assertEquals(new HashSet<>(expected(0, 1, 2)), most);
		assertEquals(3, collect("OLDEST", 5).size());
	}

	@Test(timeout = 1000)
	public void hiddenMessagesAreStillReported() {
		report(0, 1, 10);
		assertTrue(ModerationTools.setHidden(messages.get(0).id(), users.get(0).id(), true));
		assertEquals(expected(0), collect("MOST", 5));
	}

	@Test(timeout = 1000)
	public void hasNextDoesNotConsume() {
		report(0, 1, 10);
		Iterator<Message> iterator = ModerationTools.getReportedMessages("MOST", 5);
		assertTrue(iterator.hasNext());
		assertTrue(iterator.hasNext());
		assertEquals(messages.get(0), iterator.next());
		assertFalse(iterator.hasNext());
	}
}
