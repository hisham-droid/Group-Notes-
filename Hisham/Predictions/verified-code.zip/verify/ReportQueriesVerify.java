import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.ModerationTools;
import moderation.ReportQueries;
import moderation.ReportStore;
import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class ReportQueriesVerify {
	private <T> List<T> list(Iterator<T> it) { List<T> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }
	@Test public void extendedStrategies() {
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear();
		List<User> u = new ArrayList<>();
		for (int i = 0; i < 4; i++) { User x = new User(UUID.randomUUID(), User.Role.Member, "user" + i, "pass"); UserDAO.getInstance().add(x); u.add(x); }
		Post p = new Post(UUID.randomUUID()); PostDAO.getInstance().add(p);
		List<Message> m = new ArrayList<>();
		for (int i = 0; i < 4; i++) { Message x = new Message(UUID.randomUUID(), null, p.id, i, "m"); p.messages.insert(x); m.add(x); }
		ModerationTools.addReport(m.get(0).id(), u.get(0).id(), 100); ModerationTools.addReport(m.get(0).id(), u.get(1).id(), 900);
		ModerationTools.addReport(m.get(1).id(), u.get(0).id(), 50); ModerationTools.addReport(m.get(1).id(), u.get(1).id(), 60);
		ModerationTools.addReport(m.get(2).id(), u.get(0).id(), 500);
		assertEquals(List.of(m.get(0), m.get(2), m.get(1)), list(ReportQueries.getReportedMessages("NEWEST", 5)));
		assertEquals(List.of(m.get(1), m.get(0), m.get(2)), list(ReportQueries.getReportedMessages("MOST_THEN_OLDEST", 5)));
		assertEquals(List.of(m.get(2)), list(ReportQueries.getReportedMessages("LEAST", 1)));
		assertEquals(List.of(m.get(1), m.get(0), m.get(2)), list(ReportQueries.getReportedMessages("OLDEST", 5)));
		ModerationTools.removeReport(m.get(0).id(), u.get(1).id(), 0); // m0 newest now 100
		assertEquals(List.of(m.get(2), m.get(0), m.get(1)), list(ReportQueries.getReportedMessages("NEWEST", 5)));
		try { ReportQueries.getReportedMessages("newest", 1); fail(); } catch (IllegalArgumentException expected) {}
		try { ReportQueries.getReportedMessages("MOST", 0); fail(); } catch (IllegalArgumentException expected) {}
	}
}
