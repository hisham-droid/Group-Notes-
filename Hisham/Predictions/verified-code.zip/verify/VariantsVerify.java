import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;
import relations.SocialTools;

import java.util.*;
import static org.junit.Assert.*;
import static reactions.ReactionType.*;

public class VariantsVerify {
	User a, b, c; Post post; Message m1, m2, m3;

	@Before public void setUp() {
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReactionStore.getInstance().clear(); SocialTools.clearAll();
		a = new User(UUID.randomUUID(), User.Role.Member, "aaaa", "pass");
		b = new User(UUID.randomUUID(), User.Role.Member, "bbbb", "pass");
		c = new User(UUID.randomUUID(), User.Role.Admin, "cccc", "pass");
		for (User u : List.of(a, b, c)) UserDAO.getInstance().add(u);
		post = new Post(UUID.randomUUID(), a.id(), "t"); PostDAO.getInstance().add(post);
		m1 = new Message(UUID.randomUUID(), a.id(), post.id, 1, "x");
		m2 = new Message(UUID.randomUUID(), b.id(), post.id, 2, "y");
		m3 = new Message(UUID.randomUUID(), c.id(), post.id, 3, "z");
		post.messages.insert(m1); post.messages.insert(m2); post.messages.insert(m3);
	}
	private List<Message> list(Iterator<Message> it) { List<Message> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }

	@Test public void reactionBasics() {
		assertTrue(ReactionTools.addReaction(m1.id(), a.id(), LIKE, 1));
		assertFalse("second reaction", ReactionTools.addReaction(m1.id(), a.id(), LOVE, 2));
		assertFalse("null type", ReactionTools.addReaction(m1.id(), b.id(), null, 2));
		assertFalse("no msg", ReactionTools.addReaction(UUID.randomUUID(), b.id(), LIKE, 2));
		assertFalse("no user", ReactionTools.addReaction(m1.id(), UUID.randomUUID(), LIKE, 2));
		assertEquals(LIKE, ReactionTools.getReaction(m1.id(), a.id()));
		assertNull(ReactionTools.getReaction(m1.id(), b.id()));
		assertEquals(1, ReactionTools.countReactions(m1.id(), LIKE));
		assertTrue(ReactionTools.changeReaction(m1.id(), a.id(), SAD, 3));
		assertFalse("same type", ReactionTools.changeReaction(m1.id(), a.id(), SAD, 3));
		assertFalse("never reacted", ReactionTools.changeReaction(m1.id(), b.id(), SAD, 3));
		assertEquals(0, ReactionTools.countReactions(m1.id(), LIKE));
		assertEquals(1, ReactionTools.countReactions(m1.id(), SAD));
		assertTrue(ReactionTools.removeReaction(m1.id(), a.id()));
		assertFalse(ReactionTools.removeReaction(m1.id(), a.id()));
		assertFalse(ReactionTools.hasReacted(m1.id(), a.id()));
		assertEquals(0, ReactionTools.countReactions(m1.id(), SAD));
		assertEquals(0, ReactionTools.countReactions(UUID.randomUUID(), SAD));
	}
	@Test public void reactionRanking() {
		ReactionTools.addReaction(m1.id(), a.id(), LIKE, 10);
		ReactionTools.addReaction(m2.id(), a.id(), LIKE, 5);
		ReactionTools.addReaction(m2.id(), b.id(), LIKE, 6);
		ReactionTools.addReaction(m3.id(), a.id(), ANGRY, 1);
		ReactionTools.addReaction(m3.id(), b.id(), ANGRY, 2);
		ReactionTools.addReaction(m3.id(), c.id(), LOVE, 3);
		assertEquals(List.of(m3, m2, m1), list(ReactionTools.getTopMessages("MOST", 5)));
		assertEquals(List.of(m2, m1), list(ReactionTools.getTopMessages("LIKE", 5)));
		assertEquals(List.of(m3), list(ReactionTools.getTopMessages("ANGRY", 5)));
		assertEquals(List.of(m1, m2, m3), list(ReactionTools.getTopMessages("NEWEST", 5)));
		assertEquals(List.of(m3), list(ReactionTools.getTopMessages("MOST", 1)));
		assertTrue(list(ReactionTools.getTopMessages("WOW", 5)).isEmpty());
	}
	@Test(expected = IllegalArgumentException.class) public void badReactionStrategy() { ReactionTools.getTopMessages("like", 1); }
	@Test(expected = IllegalArgumentException.class) public void badReactionAmount() { ReactionTools.getTopMessages("MOST", 0); }

	@Test public void manyReactionsFast() {
		long start = System.nanoTime();
		List<User> users = new ArrayList<>();
		for (int i = 0; i < 2000; i++) { User u = new User(UUID.randomUUID(), User.Role.Member, "user" + i, "pass"); UserDAO.getInstance().add(u); users.add(u); }
		ReactionType[] types = ReactionType.values();
		for (int i = 0; i < 2000; i++) for (int j = 0; j < 10; j++)
			assertTrue(ReactionTools.addReaction(m1.id(), users.get((i + j * 200) % 2000).id(), types[j % types.length], i) || true);
		assertTrue(System.nanoTime() - start < 2_000_000_000L);
	}

	@Test public void socialFollow() {
		assertTrue(SocialTools.follow(a.id(), b.id()));
		assertFalse("twice", SocialTools.follow(a.id(), b.id()));
		assertFalse("self", SocialTools.follow(a.id(), a.id()));
		assertFalse("missing", SocialTools.follow(a.id(), UUID.randomUUID()));
		assertTrue(SocialTools.follow(c.id(), b.id()));
		assertEquals(Set.of(a.id(), c.id()), SocialTools.getFollowers(b.id()));
		assertEquals(2, SocialTools.followerCount(b.id()));
		assertTrue(SocialTools.unfollow(a.id(), b.id()));
		assertFalse(SocialTools.unfollow(a.id(), b.id()));
		assertEquals(Set.of(c.id()), SocialTools.getFollowers(b.id()));
	}
	@Test public void socialBlockFiltersMessages() {
		assertTrue(SocialTools.block(a.id(), b.id()));
		List<Message> seen = list(SocialTools.getMessagesFor(post, a.id()).getAll());
		assertEquals(List.of(m1, m3), seen);
		assertEquals(3, list(SocialTools.getMessagesFor(post, b.id()).getAll()).size());
		assertTrue(SocialTools.unblock(a.id(), b.id()));
		assertEquals(3, list(SocialTools.getMessagesFor(post, a.id()).getAll()).size());
	}
	@Test public void socialBookmarks() {
		assertTrue(SocialTools.bookmark(a.id(), post.id));
		assertFalse(SocialTools.bookmark(a.id(), post.id));
		assertFalse(SocialTools.bookmark(a.id(), UUID.randomUUID()));
		assertTrue(SocialTools.isBookmarked(a.id(), post.id));
		assertEquals(Set.of(post.id), SocialTools.getBookmarks(a.id()));
	}
}
