import accounts.Permissions;
import audit.AdminActions;
import boards.Board;
import censor.Censor;
import censor.CensorFactory;
import content.ContentTools;
import content.MoveTools;
import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import dms.DirectMessage;
import dms.DirectMessageTools;
import edits.EditTools;
import links.ContentChecks;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;
import relations.SocialTools;
import scheduled.ScheduledMessages;
import search.SearchTools;
import search.Trie;
import stats.StatsTools;
import trending.LeaderboardTools;
import trending.TrendingTools;
import votes.VoteTools;

import java.time.LocalDate;
import java.util.*;
import static org.junit.Assert.*;

public class ExtrasVerify {
	User a, b, admin; Post p1, p2;

	@Before public void setUp() {
		SearchTools.init();
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear(); ReactionStore.getInstance().clear();
		VoteTools.clear(); SearchTools.clear(); AdminActions.clear(); DirectMessageTools.clear(); ScheduledMessages.clear(); ContentChecks.clear();
		SocialTools.clearAll(); Permissions.clear(); EditTools.clear();
		a = new User(UUID.randomUUID(), User.Role.Member, "alice", "pass");
		b = new User(UUID.randomUUID(), User.Role.Member, "bob1", "pass");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "admin", "pass");
		for (User u : List.of(a, b, admin)) UserDAO.getInstance().add(u);
		p1 = new Post(UUID.randomUUID(), a.id(), "one"); p2 = new Post(UUID.randomUUID(), b.id(), "two");
		PostDAO.getInstance().add(p1); PostDAO.getInstance().add(p2);
	}
	private <T> List<T> list(Iterator<T> it) { List<T> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }
	private Message msg(Post p, User u, long t, String text) { Message m = new Message(UUID.randomUUID(), u.id(), p.id, t, text); p.messages.insert(m); return m; }

	@Test public void searchInvertedIndex() {
		Message m1 = msg(p1, a, 1, "Design patterns are great");
		Message m2 = msg(p1, b, 2, "I love design, and PATTERNS!");
		msg(p2, a, 3, "nothing here");
		assertEquals(List.of(m2, m1), SearchTools.search("patterns design"));
		assertEquals(List.of(m1), SearchTools.search("great"));
		assertTrue(SearchTools.search("missing").isEmpty());
		assertTrue(SearchTools.search("   ").isEmpty());
		EditTools.editMessage(m1.id(), a.id(), "Design only", 10);
		assertEquals("edited text no longer matches", List.of(m2), SearchTools.search("patterns"));
		assertEquals("new words after an edit are found", List.of(m1.id()), SearchTools.search("only").stream().map(Message::id).toList());
		ContentTools.removeMessage(m2.id(), admin.id());
		assertTrue(SearchTools.search("patterns").isEmpty());
	}
	@Test public void trie() {
		Trie t = new Trie();
		for (String w : List.of("alice", "Alan", "albert", "bob")) t.add(w);
		assertEquals(List.of("Alan", "albert", "alice"), t.startingWith("AL", 10));
		assertEquals(List.of("Alan"), t.startingWith("al", 1));
		assertTrue(t.contains("ALICE")); assertTrue(t.remove("alice")); assertFalse(t.contains("alice")); assertFalse(t.remove("zzz"));
		assertEquals(List.of("admin", "alice"), SearchTools.autocompleteUsername("a", 5));
	}
	@Test public void trendingAndTopPosts() {
		msg(p1, a, 100, "x"); msg(p1, b, 900, "x");
		msg(p2, a, 950, "x"); msg(p2, b, 960, "x"); msg(p2, a, 970, "x");
		assertEquals(List.of(p2, p1), list(TrendingTools.getTrendingPosts(1000, 200, 5)));
		assertEquals(List.of(p2), list(TrendingTools.getTrendingPosts(1000, 60, 5)));
		assertTrue(list(TrendingTools.getTrendingPosts(5000, 100, 5)).isEmpty());
		assertEquals(List.of(p2, p1), list(TrendingTools.getTopPosts("BUSY", 5)));
		msg(p1, a, 2000, "late");
		assertEquals(List.of(p1, p2), list(TrendingTools.getTopPosts("ACTIVE", 5)));
	}
	@Test(expected = IllegalArgumentException.class) public void topPostsBad() { TrendingTools.getTopPosts("HOT", 1); }

	@Test public void leaderboard() {
		Message m1 = msg(p1, a, 1, "x"); Message m2 = msg(p1, b, 2, "y"); msg(p1, b, 3, "z");
		assertEquals(List.of(b, a), list(LeaderboardTools.getTopUsers("MESSAGES", 5)));
		VoteTools.vote(m1.id(), b.id(), VoteTools.UP, 1); VoteTools.vote(m1.id(), admin.id(), VoteTools.UP, 1);
		VoteTools.vote(m2.id(), a.id(), VoteTools.DOWN, 1);
		assertEquals(List.of(a), list(LeaderboardTools.getTopUsers("KARMA", 5))); // b has -1: excluded (not > 0)
		ReactionTools.addReaction(m2.id(), a.id(), ReactionType.LIKE, 1);
		assertEquals(List.of(b), list(LeaderboardTools.getTopUsers("REACTIONS", 5)));
		assertEquals(Set.of(a, b), new HashSet<>(list(LeaderboardTools.getTopUsers("POSTS", 5))));
	}
	@Test public void stats() {
		assertNull(StatsTools.busiestPost());
		assertEquals(0, StatsTools.averageMessageLength(), 1e-9);
		long day = 86_400_000L;
		msg(p1, a, 0, "ab"); msg(p1, b, 10, "abcd"); msg(p2, a, day + 5, "abcdef");
		assertEquals(3, StatsTools.totalMessages());
		assertEquals(Map.of(a.id(), 2, b.id(), 1), StatsTools.messagesPerUser());
		assertEquals(Map.of(LocalDate.of(1970, 1, 1), 2, LocalDate.of(1970, 1, 2), 1), StatsTools.messagesPerDay());
		assertEquals(4.0, StatsTools.averageMessageLength(), 1e-9);
		assertEquals(p1, StatsTools.busiestPost());
	}
	@Test public void censor() {
		Censor star = new Censor(Set.of("darn", "heck"), CensorFactory.create("STAR"));
		assertEquals("**** it, what the ****! classic", star.apply("Darn it, what the heck! classic"));
		assertEquals("d*** it", new Censor(Set.of("darn"), CensorFactory.create("FIRST")).apply("darn it"));
		assertEquals(" it", new Censor(Set.of("darn"), CensorFactory.create("REMOVE")).apply("darn it"));
		Censor chained = new Censor(Set.of("heck"), CensorFactory.create("REPLACE"), star);
		assertEquals("**** [censored]", new Censor(Set.of("gosh"), CensorFactory.create("REPLACE"), star).apply("darn gosh"));
		assertTrue(chained.containsBanned("oh DARN"));
		assertFalse(chained.containsBanned("darning"));
		assertNull(star.apply(null));
	}
	@Test(expected = IllegalArgumentException.class) public void censorBad() { CensorFactory.create("blur"); }

	@Test public void auditAndUndo() {
		Message m = msg(p1, a, 1, "x");
		assertFalse("member", AdminActions.run(a.id(), AdminActions.hide(m.id(), true), 1));
		assertTrue(AdminActions.run(admin.id(), AdminActions.hide(m.id(), true), 2));
		assertTrue(AdminActions.run(admin.id(), AdminActions.lock(p1.id, true), 3));
		assertFalse("missing target not logged", AdminActions.run(admin.id(), AdminActions.lock(UUID.randomUUID(), true), 4));
		assertTrue(p1.isHidden(m.id())); assertTrue(p1.isLocked());
		assertTrue(AdminActions.undo(admin.id(), 5));
		assertFalse(p1.isLocked()); assertTrue(p1.isHidden(m.id()));
		assertTrue(AdminActions.undo(admin.id(), 6));
		assertFalse(p1.isHidden(m.id()));
		assertFalse(AdminActions.undo(admin.id(), 7));
		assertEquals(List.of("HIDE " + m.id(), "LOCK " + p1.id, "UNDO LOCK " + p1.id, "UNDO HIDE " + m.id()),
				AdminActions.getLog().stream().map(e -> e.action()).toList());
	}
	@Test public void directMessages() {
		DirectMessage d1 = DirectMessageTools.send(a.id(), b.id(), "hi", 1);
		DirectMessage d2 = DirectMessageTools.send(b.id(), a.id(), "hey", 2);
		DirectMessage d3 = DirectMessageTools.send(a.id(), b.id(), "how are you", 3);
		assertNull("self", DirectMessageTools.send(a.id(), a.id(), "x", 4));
		assertNull("blank", DirectMessageTools.send(a.id(), b.id(), " ", 4));
		assertNull("missing", DirectMessageTools.send(a.id(), UUID.randomUUID(), "x", 4));
		assertEquals(List.of(d1, d2, d3), DirectMessageTools.getConversation(b.id(), a.id()));
		assertEquals(List.of(d3, d2), DirectMessageTools.getLatest(a.id(), b.id(), 2));
		assertTrue("third party sees nothing", DirectMessageTools.getConversation(admin.id(), a.id()).isEmpty());
		assertEquals(List.of(b.id()), DirectMessageTools.getPartners(a.id()));
		SocialTools.block(b.id(), a.id());
		assertNull("blocked", DirectMessageTools.send(a.id(), b.id(), "please", 5));
		assertNotNull("other direction fine", DirectMessageTools.send(b.id(), a.id(), "no", 6));
	}
	@Test public void scheduled() {
		UUID s1 = ScheduledMessages.schedule(p1.id, a.id(), "later", 500);
		UUID s2 = ScheduledMessages.schedule(p1.id, a.id(), "sooner", 100);
		UUID s3 = ScheduledMessages.schedule(p1.id, a.id(), "cancel me", 200);
		assertNull(ScheduledMessages.schedule(UUID.randomUUID(), a.id(), "x", 1));
		assertTrue(ScheduledMessages.cancel(s3));
		assertFalse(ScheduledMessages.cancel(s3));
		assertTrue(ScheduledMessages.publishDue(50).isEmpty());
		assertEquals(List.of(s2), ScheduledMessages.publishDue(300).stream().map(Message::id).toList());
		assertEquals(1, ScheduledMessages.pendingCount());
		assertEquals(List.of(s1), ScheduledMessages.publishDue(1000).stream().map(Message::id).toList());
		assertEquals(2, p1.messages.size());
	}
	@Test public void boards() {
		Board root = new Board("All");
		Board study = root.addChild(new Board("Study"));
		Board exams = study.addChild(new Board("Exams"));
		Board social = root.addChild(new Board("Social"));
		root.addPost(p1.id); exams.addPost(p2.id);
		assertEquals(2, root.countPosts()); assertEquals(1, study.countPosts());
		assertEquals(List.of(p2.id), study.getAllPosts());
		assertSame(exams, root.find("exams"));
		assertTrue(root.movePost(p2.id, social));
		assertEquals(0, study.countPosts()); assertEquals(List.of(p2.id), social.getAllPosts());
		assertFalse(root.movePost(UUID.randomUUID(), social));
	}
	@Test public void linksDuplicatesMovePermissions() {
		assertEquals(List.of("https://anu.edu.au/x", "http://a.b"), ContentChecks.extractLinks("see https://anu.edu.au/x, and (http://a.b)."));
		assertFalse(ContentChecks.isDuplicate(a.id(), "Hello  World", 0, 1000));
		assertTrue(ContentChecks.isDuplicate(a.id(), "hello world", 500, 1000));
		assertFalse("other user", ContentChecks.isDuplicate(b.id(), "hello world", 500, 1000));
		assertFalse("after window", ContentChecks.isDuplicate(a.id(), "hello world", 2000, 1000));

		Message m = msg(p1, a, 5, "move me");
		ModerationTools.addReport(m.id(), b.id(), 1);
		p1.setHidden(m, true);
		assertFalse("member", MoveTools.moveMessage(m.id(), p2.id, a.id()));
		assertFalse("same post", MoveTools.moveMessage(m.id(), p1.id, admin.id()));
		assertTrue(MoveTools.moveMessage(m.id(), p2.id, admin.id()));
		assertEquals(0, p1.messages.size()); assertEquals(1, p2.messages.size());
		assertEquals(p2.id, MessageIndex.getInstance().get(m.id()).thread());
		assertTrue("moderation state kept", p2.isHidden(m.id()));
		assertTrue("reports kept", ModerationTools.hasReported(m.id(), b.id()));

		assertFalse(Permissions.canModerate(a.id()));
		assertFalse("member cannot appoint", Permissions.setModerator(b.id(), a.id(), true));
		assertTrue(Permissions.setModerator(admin.id(), a.id(), true));
		assertTrue(Permissions.canModerate(a.id()));
		assertTrue(Permissions.canModerate(admin.id()));
		assertFalse("cannot target admin", Permissions.setModerator(admin.id(), admin.id(), true));
		assertTrue(Permissions.setModerator(admin.id(), a.id(), false));
		assertFalse(Permissions.canModerate(a.id()));
	}
}
