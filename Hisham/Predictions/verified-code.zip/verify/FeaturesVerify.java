import accounts.AccountTools;
import bans.BanTools;
import content.ContentTools;
import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import edits.EditTools;
import friends.FriendTools;
import mentions.MentionTools;
import moderation.ModerationTools;
import moderation.ReportStore;
import notifications.NotificationTools;
import org.junit.Before;
import org.junit.Test;
import polls.PollTools;
import ratelimit.RateLimiter;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;
import readtracking.ReadTracker;
import relations.SocialTools;
import tags.TagTools;
import votes.VoteTools;

import java.util.*;
import static org.junit.Assert.*;

public class FeaturesVerify {
	User a, b, c, admin; Post post; Message m1, m2, m3;

	@Before public void setUp() {
		MentionTools.init();
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear(); ReactionStore.getInstance().clear();
		VoteTools.clear(); NotificationTools.clear(); TagTools.clear(); PollTools.clear(); ReadTracker.clear(); BanTools.clear();
		FriendTools.clear(); MentionTools.clear(); EditTools.clear(); SocialTools.clearAll();
		a = new User(UUID.randomUUID(), User.Role.Member, "alice", "pass1");
		b = new User(UUID.randomUUID(), User.Role.Member, "bobby", "pass2");
		c = new User(UUID.randomUUID(), User.Role.Member, "carol", "pass3");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "admin", "pass4");
		for (User u : List.of(a, b, c, admin)) UserDAO.getInstance().add(u);
		post = new Post(UUID.randomUUID(), a.id(), "t"); PostDAO.getInstance().add(post);
		m1 = new Message(UUID.randomUUID(), a.id(), post.id, 10, "hi");
		m2 = new Message(UUID.randomUUID(), b.id(), post.id, 20, "yo");
		m3 = new Message(UUID.randomUUID(), c.id(), post.id, 30, "hey");
		post.messages.insert(m1); post.messages.insert(m2); post.messages.insert(m3);
	}
	private <T> List<T> list(Iterator<T> it) { List<T> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }

	@Test public void votes() {
		assertTrue(VoteTools.vote(m1.id(), a.id(), VoteTools.UP, 1));
		assertFalse("same vote twice", VoteTools.vote(m1.id(), a.id(), VoteTools.UP, 2));
		assertFalse("bad direction", VoteTools.vote(m1.id(), b.id(), 2, 2));
		assertFalse("bad direction 0", VoteTools.vote(m1.id(), b.id(), 0, 2));
		assertFalse("missing msg", VoteTools.vote(UUID.randomUUID(), b.id(), 1, 2));
		assertFalse("missing user", VoteTools.vote(m1.id(), UUID.randomUUID(), 1, 2));
		assertTrue(VoteTools.vote(m1.id(), b.id(), VoteTools.DOWN, 3));
		assertTrue(VoteTools.vote(m1.id(), c.id(), VoteTools.UP, 4));
		assertEquals(1, VoteTools.getScore(m1.id()));
		assertTrue("switch", VoteTools.vote(m1.id(), b.id(), VoteTools.UP, 5));
		assertEquals(3, VoteTools.getScore(m1.id()));
		assertEquals(3, VoteTools.getUpvotes(m1.id())); assertEquals(0, VoteTools.getDownvotes(m1.id()));
		assertEquals(1, VoteTools.getVote(m1.id(), b.id()));
		assertTrue(VoteTools.removeVote(m1.id(), b.id()));
		assertFalse(VoteTools.removeVote(m1.id(), b.id()));
		assertEquals(0, VoteTools.getVote(m1.id(), b.id()));
		VoteTools.vote(m2.id(), a.id(), VoteTools.UP, 10); VoteTools.vote(m2.id(), b.id(), VoteTools.DOWN, 11);
		VoteTools.vote(m2.id(), c.id(), VoteTools.DOWN, 12); VoteTools.vote(m2.id(), admin.id(), VoteTools.UP, 13);
		VoteTools.vote(m3.id(), a.id(), VoteTools.DOWN, 6);
		assertEquals(List.of(m1, m2, m3), list(VoteTools.getTopMessages("TOP", 5)));
		assertEquals(m2, VoteTools.getTopMessages("CONTROVERSIAL", 5).next());
		assertEquals(List.of(m2, m3), list(VoteTools.getTopMessages("NEWEST", 2)));
	}
	@Test(expected = IllegalArgumentException.class) public void votesBadStrategy() { VoteTools.getTopMessages("BEST", 1); }

	@Test public void postLikes() {
		assertTrue(SocialTools.likePost(a.id(), post.id));
		assertFalse(SocialTools.likePost(a.id(), post.id));
		assertFalse(SocialTools.likePost(a.id(), UUID.randomUUID()));
		assertTrue(SocialTools.likePost(b.id(), post.id));
		assertEquals(2, SocialTools.getPostLikeCount(post.id));
		assertTrue(SocialTools.unlikePost(a.id(), post.id));
		assertFalse(SocialTools.hasLikedPost(a.id(), post.id));
		assertEquals(1, SocialTools.getPostLikeCount(post.id));
	}

	@Test public void subscriptionsNotify() {
		assertTrue(NotificationTools.subscribe(a.id(), post.id));
		assertFalse(NotificationTools.subscribe(a.id(), post.id));
		assertFalse(NotificationTools.subscribe(a.id(), UUID.randomUUID()));
		assertTrue(NotificationTools.subscribe(b.id(), post.id));
		Message fromB = ContentTools.reply(post.id, b.id(), "new!", 100);
		assertEquals(1, NotificationTools.getUnreadCount(a.id()));
		assertEquals(0, NotificationTools.getUnreadCount(b.id())); // not notified about own message
		assertEquals(fromB.id(), NotificationTools.getNotifications(a.id()).get(0).message());
		Message second = ContentTools.reply(post.id, c.id(), "again", 101);
		assertEquals(second.id(), NotificationTools.getNotifications(a.id()).get(0).message()); // newest first
		assertEquals(2, NotificationTools.getUnreadCount(a.id()));
		NotificationTools.markAllRead(a.id());
		assertEquals(0, NotificationTools.getUnreadCount(a.id()));
		assertEquals(2, NotificationTools.getNotifications(a.id()).size());
		assertTrue(NotificationTools.unsubscribe(a.id(), post.id));
		ContentTools.reply(post.id, c.id(), "more", 102);
		assertEquals(0, NotificationTools.getUnreadCount(a.id()));
		// an edit is NOT a new message
		int before = NotificationTools.getUnreadCount(b.id());
		assertTrue(EditTools.editMessage(m3.id(), c.id(), "hey (edited)", 200));
		assertEquals(before, NotificationTools.getUnreadCount(b.id()));
	}

	@Test public void tags() {
		assertTrue(TagTools.addTag(post.id, a.id(), "#Exam"));
		assertFalse("same tag normalised", TagTools.addTag(post.id, a.id(), "exam"));
		assertFalse("not author", TagTools.addTag(post.id, b.id(), "uml"));
		assertTrue("admin may", TagTools.addTag(post.id, admin.id(), "uml"));
		assertFalse("invalid", TagTools.addTag(post.id, a.id(), "two words"));
		assertFalse("empty", TagTools.addTag(post.id, a.id(), "#"));
		assertEquals(new TreeSet<>(Set.of("exam", "uml")), TagTools.getTags(post.id));
		assertEquals(Set.of(post.id), TagTools.getPostsWithTag("EXAM"));
		Post p2 = new Post(UUID.randomUUID(), b.id(), "t2"); PostDAO.getInstance().add(p2);
		TagTools.addTag(p2.id, b.id(), "uml");
		assertEquals(List.of("uml", "exam"), TagTools.getPopularTags(5));
		assertEquals(List.of("uml"), TagTools.getPopularTags(1));
		assertTrue(TagTools.removeTag(post.id, a.id(), "UML"));
		assertEquals(Set.of(p2.id), TagTools.getPostsWithTag("uml"));
	}

	@Test public void polls() {
		assertNull("one option", PollTools.createPoll(post.id, a.id(), List.of("yes")));
		assertNull("duplicate options", PollTools.createPoll(post.id, a.id(), List.of("Yes", "yes")));
		assertNull("blank", PollTools.createPoll(post.id, a.id(), List.of("yes", " ")));
		assertNull("no post", PollTools.createPoll(UUID.randomUUID(), a.id(), List.of("y", "n")));
		UUID poll = PollTools.createPoll(post.id, a.id(), List.of("red", "green", "blue"));
		assertNotNull(poll);
		assertTrue(PollTools.vote(poll, a.id(), 0));
		assertFalse("twice", PollTools.vote(poll, a.id(), 1));
		assertFalse("bad option", PollTools.vote(poll, b.id(), 3));
		assertFalse("negative option", PollTools.vote(poll, b.id(), -1));
		assertTrue(PollTools.vote(poll, b.id(), 1));
		assertTrue(PollTools.vote(poll, c.id(), 1));
		assertArrayEquals(new int[]{1, 2, 0}, PollTools.getResults(poll));
		assertEquals(List.of(1), PollTools.getWinners(poll));
		assertTrue(PollTools.changeVote(poll, c.id(), 0));
		assertFalse("same option", PollTools.changeVote(poll, c.id(), 0));
		assertFalse("never voted", PollTools.changeVote(poll, admin.id(), 0));
		assertEquals(List.of(0), PollTools.getWinners(poll));
		assertTrue(PollTools.removeVote(poll, c.id()));
		assertEquals(List.of(0, 1), PollTools.getWinners(poll)); // tie
		assertEquals(-1, PollTools.getVote(poll, c.id()));
		int[] r = PollTools.getResults(poll); r[0] = 99;
		assertArrayEquals("results are a copy", new int[]{1, 1, 0}, PollTools.getResults(poll));
		assertNull(PollTools.getResults(UUID.randomUUID()));
	}

	@Test public void readTracking() {
		assertEquals(3, ReadTracker.getUnreadCount(a.id(), post.id));
		assertTrue(ReadTracker.markRead(a.id(), post.id, 20));
		assertEquals(1, ReadTracker.getUnreadCount(a.id(), post.id));
		assertTrue(ReadTracker.markRead(a.id(), post.id, 15)); // never goes backwards
		assertEquals(20, ReadTracker.getLastRead(a.id(), post.id));
		post.messages.insert(new Message(UUID.randomUUID(), b.id(), post.id, 40, "new"));
		assertEquals(2, ReadTracker.getUnreadCount(a.id(), post.id));
		post.setHidden(m3, true);
		assertEquals("members do not count hidden", 1, ReadTracker.getUnreadCount(a.id(), post.id));
		assertEquals("admins do", 4, ReadTracker.getUnreadCount(admin.id(), post.id));
		assertFalse(ReadTracker.markRead(a.id(), UUID.randomUUID(), 1));
	}

	@Test public void bans() {
		assertFalse("member cannot ban", BanTools.ban(a.id(), b.id(), 1000));
		assertFalse("cannot ban admins", BanTools.ban(admin.id(), admin.id(), 1000));
		assertTrue(BanTools.ban(admin.id(), b.id(), 1000));
		assertTrue(BanTools.isBanned(b.id(), 999));
		assertFalse("expired", BanTools.isBanned(b.id(), 1000));
		assertNull("banned cannot reply", ContentTools.reply(post.id, b.id(), "x", 500));
		assertNotNull("after ban", ContentTools.reply(post.id, b.id(), "x", 1500));
		assertTrue(BanTools.unban(admin.id(), b.id()));
		assertFalse(BanTools.unban(admin.id(), b.id()));
		assertFalse(BanTools.isBanned(b.id(), 0));
	}

	@Test public void friends() {
		assertTrue(FriendTools.sendRequest(a.id(), b.id()));
		assertFalse("again", FriendTools.sendRequest(a.id(), b.id()));
		assertFalse("self", FriendTools.sendRequest(a.id(), a.id()));
		assertEquals(Set.of(a.id()), FriendTools.getIncomingRequests(b.id()));
		assertFalse("wrong direction", FriendTools.accept(a.id(), b.id()));
		assertTrue(FriendTools.accept(b.id(), a.id()));
		assertTrue(FriendTools.areFriends(a.id(), b.id()) && FriendTools.areFriends(b.id(), a.id()));
		assertFalse("already friends", FriendTools.sendRequest(b.id(), a.id()));
		assertTrue(FriendTools.sendRequest(c.id(), a.id()));
		assertTrue("mutual request auto-accepts", FriendTools.sendRequest(a.id(), c.id()));
		assertEquals(Set.of(b.id(), c.id()), FriendTools.getFriends(a.id()));
		assertTrue(FriendTools.removeFriend(a.id(), b.id()));
		assertFalse(FriendTools.areFriends(b.id(), a.id()));
		assertTrue(FriendTools.sendRequest(admin.id(), c.id()));
		assertTrue(FriendTools.decline(c.id(), admin.id()));
		assertTrue(FriendTools.getIncomingRequests(c.id()).isEmpty());
	}

	@Test public void mentions() {
		assertEquals(List.of("alice", "Bobby"), MentionTools.extractUsernames("hi @alice and @Bobby, also @alice again, email x@y.com"));
		Message m = ContentTools.reply(post.id, c.id(), "ping @ALICE and @nobodyhere", 50);
		Message n = ContentTools.reply(post.id, b.id(), "@alice again", 60);
		assertEquals(List.of(n, m), MentionTools.getMentions(a.id()));
		assertTrue(MentionTools.getMentions(b.id()).isEmpty());
		ContentTools.removeMessage(n.id(), admin.id());
		assertEquals(List.of(m), MentionTools.getMentions(a.id()));
		EditTools.editMessage(m3.id(), c.id(), "now mentioning @bobby", 70);
		assertEquals("mention added by an edit", 1, MentionTools.getMentions(b.id()).size());
	}

	@Test public void edits() {
		assertFalse("not author", EditTools.editMessage(m1.id(), b.id(), "hacked", 50));
		assertFalse("same text", EditTools.editMessage(m1.id(), a.id(), "hi", 50));
		assertFalse("null text", EditTools.editMessage(m1.id(), a.id(), null, 50));
		assertTrue(EditTools.editMessage(m1.id(), a.id(), "hello", 50));
		assertTrue(EditTools.editMessage(m1.id(), a.id(), "hello!", 60));
		assertEquals("hello!", MessageIndex.getInstance().get(m1.id()).message());
		assertEquals("hello!", list(post.getVisibleMessages(false).getAll()).get(0).message());
		assertEquals(3, list(post.messages.getAll()).size());
		assertEquals(List.of("hi", "hello"), EditTools.getHistory(m1.id()).stream().map(e -> e.text()).toList());
		assertTrue(EditTools.undoLastEdit(m1.id(), a.id()));
		assertEquals("hello", MessageIndex.getInstance().get(m1.id()).message());
		assertEquals(1, EditTools.getEditCount(m1.id()));
		assertTrue(ModerationTools.addReport(m1.id(), b.id(), 1)); // still reportable by id after edits
	}

	@Test public void rateLimit() {
		RateLimiter limiter = new RateLimiter(3, 1000);
		assertTrue(limiter.tryAcquire(a.id(), 0));
		assertTrue(limiter.tryAcquire(a.id(), 100));
		assertTrue(limiter.tryAcquire(a.id(), 200));
		assertFalse(limiter.tryAcquire(a.id(), 300));
		assertTrue("other users independent", limiter.tryAcquire(b.id(), 300));
		assertEquals(0, limiter.remaining(a.id(), 999));
		assertTrue("first one expired", limiter.tryAcquire(a.id(), 1000));
		assertFalse(limiter.tryAcquire(a.id(), 1050));
		assertEquals(3, limiter.remaining(c.id(), 0));
	}
	@Test(expected = IllegalArgumentException.class) public void rateLimitBadArgs() { new RateLimiter(0, 10); }

	@Test public void accountDeletionAndChanges() {
		ModerationTools.addReport(m2.id(), a.id(), 1);
		ReactionTools.addReaction(m2.id(), a.id(), ReactionType.LIKE, 1);
		VoteTools.vote(m2.id(), a.id(), VoteTools.UP, 1);
		SocialTools.follow(b.id(), a.id());
		FriendTools.sendRequest(a.id(), c.id());
		assertFalse("wrong password", AccountTools.deleteAccount(a.id(), "nope"));
		assertTrue(AccountTools.deleteAccount(a.id(), "pass1"));
		assertNull(UserDAO.getInstance().getByUUID(a.id()));
		assertNull(UserDAO.getInstance().get(new User("alice")));
		assertEquals("[deleted]", AccountTools.displayName(m1.poster()));
		assertTrue("messages survive", list(post.messages.getAll()).contains(m1));
		assertFalse(ModerationTools.hasReported(m2.id(), a.id()));
		assertEquals(0, ReactionTools.countReactions(m2.id(), ReactionType.LIKE));
		assertEquals(0, VoteTools.getScore(m2.id()));
		assertTrue(SocialTools.getFollowers(a.id()).isEmpty());
		assertTrue(FriendTools.getIncomingRequests(c.id()).isEmpty());
		assertFalse("cannot delete twice", AccountTools.deleteAccount(a.id(), "pass1"));
		// changes keep the same UUID
		assertTrue(AccountTools.changePassword(b.id(), "pass2", "newpass"));
		assertFalse(AccountTools.changePassword(b.id(), "pass2", "x"));
		assertEquals("bobby", UserDAO.getInstance().login("bobby", "newpass").username());
		assertFalse("taken", AccountTools.changeUsername(b.id(), "CAROL"));
		assertFalse("invalid", AccountTools.changeUsername(b.id(), "b!"));
		assertTrue(AccountTools.changeUsername(b.id(), "robert"));
		assertEquals(b.id(), UserDAO.getInstance().getByUUID(b.id()).id());
		assertEquals("robert", AccountTools.displayName(b.id()));
		assertNull(UserDAO.getInstance().get(new User("bobby")));
		assertFalse("member cannot promote", AccountTools.setRole(c.id(), b.id(), User.Role.Admin));
		assertTrue(AccountTools.setRole(admin.id(), b.id(), User.Role.Admin));
		assertTrue(ModerationTools.setHidden(m3.id(), b.id(), true));
	}
}
