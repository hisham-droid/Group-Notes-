import accounts.Permissions;
import audit.AdminActions;
import bans.BanTools;
import boards.BoardTools;
import content.ContentTools;
import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import dms.DirectMessageTools;
import edits.EditTools;
import friends.FriendTools;
import mentions.MentionTools;
import moderation.ReportStore;
import notifications.NotificationTools;
import org.junit.Test;
import persistentdata.DataManager;
import persistentdata.features.Features;
import persistentdata.features.PersistentFeature;
import persistentdata.io.IOFactory;
import polls.PollTools;
import reactions.ReactionStore;
import reactions.ReactionTools;
import reactions.ReactionType;
import readtracking.ReadTracker;
import relations.SocialTools;
import scheduled.ScheduledMessages;
import search.SearchTools;
import tags.TagTools;
import votes.VoteTools;

import java.io.*;
import java.util.*;
import static org.junit.Assert.*;

public class AllPersistenceVerify {
	static class MemoryIO implements IOFactory {
		final Map<String, StringWriter> files = new HashMap<>();
		public Writer writer(String f) { StringWriter w = new StringWriter(); files.put(f, w); return w; }
		public Reader reader(String f) { StringWriter w = files.get(f); return w == null ? null : new StringReader(w.toString()); }
	}

	@Test public void everyFeatureSurvivesSaveAndLoad() {
		MentionTools.init(); SearchTools.init();
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear();
		for (PersistentFeature f : Features.all()) f.clear();
		NotificationTools.clear(); MentionTools.clear(); SearchTools.clear();

		User a = new User(UUID.randomUUID(), User.Role.Member, "alice", "pass");
		User b = new User(UUID.randomUUID(), User.Role.Member, "bobby", "pass");
		User admin = new User(UUID.randomUUID(), User.Role.Admin, "admin", "pass");
		for (User u : List.of(a, b, admin)) UserDAO.getInstance().add(u);
		Post post = new Post(UUID.randomUUID(), a.id(), "topic"); PostDAO.getInstance().add(post);
		Post other = new Post(UUID.randomUUID(), b.id(), "other"); PostDAO.getInstance().add(other);
		Message m1 = ContentTools.reply(post.id, a.id(), "hello @bobby, design patterns", 10);
		Message m2 = ContentTools.reply(post.id, b.id(), "second, with \"quotes\"", 20);
		Message m3 = ContentTools.reply(post.id, a.id(), "third", 30);

		ContentTools.deleteMessage(m2.id(), b.id());
		ContentTools.setPinned(m3.id(), admin.id(), true);
		ContentTools.setLocked(other.id, admin.id(), true);
		ReactionTools.addReaction(m1.id(), b.id(), ReactionType.LOVE, 11);
		VoteTools.vote(m1.id(), b.id(), VoteTools.UP, 12); VoteTools.vote(m1.id(), admin.id(), VoteTools.DOWN, 13);
		EditTools.editMessage(m3.id(), a.id(), "third, edited", 40);
		EditTools.editMessage(m3.id(), a.id(), "third, edited twice", 41);
		SocialTools.follow(b.id(), a.id()); SocialTools.block(a.id(), b.id()); SocialTools.bookmark(b.id(), post.id); SocialTools.likePost(b.id(), post.id);
		NotificationTools.subscribe(b.id(), post.id);
		FriendTools.sendRequest(a.id(), b.id()); FriendTools.sendRequest(admin.id(), a.id()); FriendTools.accept(a.id(), admin.id());
		TagTools.addTag(post.id, a.id(), "#Exam");
		UUID poll = PollTools.createPoll(post.id, a.id(), List.of("red", "green, blue", "yellow"));
		PollTools.vote(poll, b.id(), 1); PollTools.vote(poll, admin.id(), 2);
		ReadTracker.markRead(b.id(), post.id, 20);
		BanTools.ban(admin.id(), b.id(), 5000);
		Permissions.setModerator(admin.id(), a.id(), true);
		DirectMessageTools.send(a.id(), admin.id(), "psst, a secret\nwith newline", 50);
		UUID sched = ScheduledMessages.schedule(post.id, a.id(), "future", 9999);
		AdminActions.run(admin.id(), AdminActions.lock(post.id, true), 60);
		AdminActions.undo(admin.id(), 61);
		BoardTools.createBoard("Study", "All"); BoardTools.createBoard("Exams", "Study");
		BoardTools.root().find("Exams").addPost(post.id);
		Message r1 = threads.ThreadTools.reply(m1.id(), b.id(), "a reply", 70);
		access.AccessTools.setPrivate(other.id, b.id(), true);
		access.AccessTools.invite(other.id, b.id(), a.id());

		MemoryIO io = new MemoryIO();
		DataManager dm = new DataManager(io);
		dm.writeAll();

		// wipe EVERYTHING
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear(); MessageIndex.getInstance().clear();
		for (PersistentFeature f : Features.all()) f.clear();
		NotificationTools.clear(); MentionTools.clear(); SearchTools.clear();
		assertNull(UserDAO.getInstance().getByUUID(a.id()));

		dm.readAll();

		Post p = PostDAO.getInstance().get(new Post(post.id));
		assertTrue(p.isDeleted(m2.id()));
		assertFalse(new ArrayList<Message>() {{ p.getVisibleMessages(false).getAll().forEachRemaining(this::add); }}.contains(m2));
		assertEquals("third, edited twice", MessageIndex.getInstance().get(m3.id()).message());
		assertTrue(p.isPinned(MessageIndex.getInstance().get(m3.id())));
		assertTrue(PostDAO.getInstance().get(new Post(other.id)).isLocked());
		assertFalse("undo was saved too", p.isLocked());
		assertEquals(ReactionType.LOVE, ReactionTools.getReaction(m1.id(), b.id()));
		assertEquals(0, VoteTools.getScore(m1.id()));
		assertEquals(1, VoteTools.getUpvotes(m1.id()));
		assertEquals(List.of("third", "third, edited"), EditTools.getHistory(m3.id()).stream().map(e -> e.text()).toList());
		assertTrue(SocialTools.isFollowing(b.id(), a.id()));
		assertTrue(SocialTools.isBlocked(a.id(), b.id()));
		assertTrue(SocialTools.isBookmarked(b.id(), post.id));
		assertEquals(1, SocialTools.getPostLikeCount(post.id));
		assertTrue(NotificationTools.isSubscribed(b.id(), post.id));
		assertEquals(Set.of(a.id()), FriendTools.getIncomingRequests(b.id()));
		assertTrue(FriendTools.areFriends(admin.id(), a.id()));
		assertEquals(Set.of("exam"), TagTools.getTags(post.id));
		assertEquals(List.of("red", "green, blue", "yellow"), PollTools.getPoll(poll).getOptions());
		assertArrayEquals(new int[]{0, 1, 1}, PollTools.getResults(poll));
		assertEquals(20, ReadTracker.getLastRead(b.id(), post.id));
		assertTrue(BanTools.isBanned(b.id(), 100));
		assertTrue(Permissions.canModerate(a.id()));
		assertEquals("psst, a secret\nwith newline", DirectMessageTools.getConversation(a.id(), admin.id()).get(0).text());
		assertEquals(1, ScheduledMessages.pendingCount());
		assertEquals(sched, ScheduledMessages.publishDue(10_000).get(0).id());
		assertEquals(List.of("LOCK " + post.id, "UNDO LOCK " + post.id), AdminActions.getLog().stream().map(e -> e.action()).toList());
		assertEquals(List.of(post.id), BoardTools.root().find("Study").getAllPosts());
		assertEquals(m1.id(), threads.ThreadTools.getParent(r1.id()));
		assertTrue(access.AccessTools.isPrivate(other.id));
		assertTrue(access.AccessTools.canView(other.id, a.id()));
		assertFalse(access.AccessTools.canView(other.id, null));
		// derived data rebuilt automatically
		assertEquals(1, MentionTools.getMentions(b.id()).size());
		assertEquals(1, SearchTools.search("design patterns").size());
		assertEquals(32, io.files.size()); // users, posts, messages, reports, hidden + 27 feature files
	}
}
