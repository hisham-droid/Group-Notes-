import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import persistentdata.DataManager;
import persistentdata.io.ComputerIOFactory;
import persistentdata.io.IOFactory;

import java.io.*;
import java.nio.file.Files;
import java.util.*;
import static org.junit.Assert.*;

public class PersistenceVerify {
	// in-memory "disk": file name -> contents
	static class MemoryIO implements IOFactory {
		final Map<String, StringWriter> files = new HashMap<>();
		public Writer writer(String f) { StringWriter w = new StringWriter(); files.put(f, w); return w; }
		public Reader reader(String f) { StringWriter w = files.get(f); return w == null ? null : new StringReader(w.toString()); }
	}

	User member, admin; Post post, emptyPost; Message m1, m2, m3;

	@Before public void setUp() {
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear();
		member = new User(UUID.randomUUID(), User.Role.Member, "memberA", "pa,ss\"word\nx");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "adminA", "pass");
		UserDAO.getInstance().add(member); UserDAO.getInstance().add(admin);
		post = new Post(UUID.randomUUID(), member.id(), "Topic, with \"quotes\"");
		emptyPost = new Post(UUID.randomUUID()); // null poster + topic
		PostDAO.getInstance().add(post); PostDAO.getInstance().add(emptyPost);
		m1 = new Message(UUID.randomUUID(), member.id(), post.id, 1, "hello, world");
		m2 = new Message(UUID.randomUUID(), null, post.id, 2, "line1\nline2 \"q\"");
		m3 = new Message(UUID.randomUUID(), admin.id(), post.id, 3, "third");
		post.messages.insert(m1); post.messages.insert(m2); post.messages.insert(m3);
		ModerationTools.addReport(m1.id(), member.id(), 100);
		ModerationTools.addReport(m1.id(), admin.id(), 50);
		ModerationTools.addReport(m2.id(), member.id(), 75);
		ModerationTools.setHidden(m2.id(), admin.id(), true);
	}

	private void assertStateRestored() {
		assertEquals(member, UserDAO.getInstance().getByUUID(member.id()));
		assertEquals(admin, UserDAO.getInstance().getByUUID(admin.id()));
		Post p = PostDAO.getInstance().get(new Post(post.id));
		assertNotSame(post, p); // really reloaded
		assertEquals(post.topic, p.topic);
		Post e = PostDAO.getInstance().get(new Post(emptyPost.id));
		assertNull(e.poster); assertNull(e.topic);
		List<Message> all = new ArrayList<>(); p.messages.getAll().forEachRemaining(all::add);
		assertEquals(List.of(m1, m2, m3), all);
		List<Message> vis = new ArrayList<>(); p.getVisibleMessages(false).getAll().forEachRemaining(vis::add);
		assertEquals(List.of(m1, m3), vis);
		assertTrue(p.isHidden(m2.id()));
		assertTrue(ModerationTools.hasReported(m1.id(), member.id()));
		assertTrue(ModerationTools.hasReported(m1.id(), admin.id()));
		assertTrue(ModerationTools.hasReported(m2.id(), member.id()));
		List<Message> oldest = new ArrayList<>(); ModerationTools.getReportedMessages("OLDEST", 5).forEachRemaining(oldest::add);
		assertEquals(List.of(m1, m2), oldest);
	}

	@Test public void roundTripInMemory() {
		MemoryIO io = new MemoryIO();
		DataManager dm = new DataManager(io);
		dm.writeAll();
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear(); MessageIndex.getInstance().clear();
		dm.readAll();
		assertStateRestored();
		System.out.println("---- reports.txt ----\n" + io.files.get("reports") + "\n---- hidden.txt ----\n" + io.files.get("hidden") + "\n---- messages.txt ----\n" + io.files.get("messages"));
	}

	@Test public void roundTripOnDisk() throws IOException {
		File dir = Files.createTempDirectory("hack").toFile();
		File sub = new File(dir, "saved"); // does not exist yet: must be created
		DataManager dm = new DataManager(new ComputerIOFactory(sub));
		dm.writeAll();
		dm.readAll();
		assertStateRestored();
		assertTrue(new File(sub, "reports.txt").exists());
	}

	@Test public void readingWithNoFilesGivesEmptyApp() throws IOException {
		File dir = Files.createTempDirectory("empty").toFile();
		new DataManager(new ComputerIOFactory(dir)).readAll();
		assertFalse(UserDAO.getInstance().getAll().hasNext());
		assertFalse(ModerationTools.getReportedMessages("MOST", 1).hasNext());
	}

	@Test public void removedReportsAreNotSaved() {
		ModerationTools.removeReport(m2.id(), member.id(), 0);
		MemoryIO io = new MemoryIO();
		DataManager dm = new DataManager(io);
		dm.writeAll(); dm.readAll();
		assertFalse(ModerationTools.hasReported(m2.id(), member.id()));
	}
}
