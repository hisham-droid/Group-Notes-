import dao.MessageIndex;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import sorteddata.SortedData;

import java.util.*;
import static org.junit.Assert.*;

public class ModerationVerify {
	User member, member2, member3, admin;
	Post post;
	Message m1, m2, m3;

	@Before
	public void setUp() {
		UserDAO.getInstance().clear();
		PostDAO.getInstance().clear();
		ReportStore.getInstance().clear();
		member = new User(UUID.randomUUID(), User.Role.Member, "memberA", "pass");
		member2 = new User(UUID.randomUUID(), User.Role.Member, "memberB", "pass");
		member3 = new User(UUID.randomUUID(), User.Role.Member, "memberC", "pass");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "adminA", "pass");
		for (User u : List.of(member, member2, member3, admin)) UserDAO.getInstance().add(u);
		post = new Post(UUID.randomUUID(), member.id(), "topic");
		PostDAO.getInstance().add(post);
		// null poster on purpose: tests in the wild do this
		m1 = new Message(UUID.randomUUID(), null, post.id, 10, "a");
		m2 = new Message(UUID.randomUUID(), null, post.id, 10, "b");
		m3 = new Message(UUID.randomUUID(), member.id(), post.id, 30, "c");
		post.messages.insert(m1); post.messages.insert(m2); post.messages.insert(m3);
	}

	private List<Message> list(Iterator<Message> it) { List<Message> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }
	private List<Message> list(SortedData<Message> d) { return list(d.getAll()); }

	// ----- indexes -----
	@Test public void userIndex() {
		assertSame(admin, UserDAO.getInstance().getByUUID(admin.id()));
		User reg = UserDAO.getInstance().register("newUser1", "abcd");
		assertSame(reg, UserDAO.getInstance().getByUUID(reg.id()));
		UserDAO.getInstance().clear();
		assertNull(UserDAO.getInstance().getByUUID(admin.id()));
		assertNull(UserDAO.getInstance().getByUUID(null));
	}
	@Test public void messageIndexStaleAfterClear() {
		assertSame(m1, MessageIndex.getInstance().get(m1.id()));
		PostDAO.getInstance().clear();
		assertNull(MessageIndex.getInstance().get(m1.id()));
		assertNull(MessageIndex.getInstance().get(UUID.randomUUID()));
		assertNull(MessageIndex.getInstance().get(null));
	}
	@Test public void messageInPostNotInDaoDoesNotExist() {
		Post loose = new Post(UUID.randomUUID());
		Message m = new Message(UUID.randomUUID(), null, loose.id, 1, "x");
		loose.messages.insert(m);
		assertFalse(ModerationTools.addReport(m.id(), member.id(), 1));
		PostDAO.getInstance().add(loose); // once the post is stored, it exists
		assertTrue(ModerationTools.addReport(m.id(), member.id(), 1));
	}

	// ----- Task 1 -----
	@Test public void addReportRules() {
		assertTrue(ModerationTools.addReport(m1.id(), member.id(), 5));
		assertFalse("duplicate", ModerationTools.addReport(m1.id(), member.id(), 6));
		assertFalse("no message", ModerationTools.addReport(UUID.randomUUID(), member.id(), 5));
		assertFalse("no user", ModerationTools.addReport(m1.id(), UUID.randomUUID(), 5));
		assertFalse("both missing", ModerationTools.addReport(UUID.randomUUID(), UUID.randomUUID(), 5));
		assertTrue(ModerationTools.addReport(m1.id(), member2.id(), 5));
		assertTrue(ModerationTools.hasReported(m1.id(), member.id()));
		assertFalse(ModerationTools.hasReported(m2.id(), member.id()));
	}
	@Test public void removeReportRules() {
		assertFalse("nothing to remove", ModerationTools.removeReport(m1.id(), member.id(), 0));
		ModerationTools.addReport(m1.id(), member.id(), 5);
		assertFalse("unknown user", ModerationTools.removeReport(m1.id(), UUID.randomUUID(), 0));
		assertFalse("unknown msg", ModerationTools.removeReport(UUID.randomUUID(), member.id(), 0));
		assertTrue(ModerationTools.removeReport(m1.id(), member.id(), 0));
		assertFalse(ModerationTools.hasReported(m1.id(), member.id()));
		assertFalse("twice", ModerationTools.removeReport(m1.id(), member.id(), 0));
		assertTrue("can report again after removing", ModerationTools.addReport(m1.id(), member.id(), 7));
	}
	@Test public void reportsSurviveHiding() {
		ModerationTools.addReport(m1.id(), member.id(), 5);
		assertTrue(ModerationTools.setHidden(m1.id(), admin.id(), true));
		assertTrue(ModerationTools.hasReported(m1.id(), member.id()));
		assertEquals(List.of(m1), list(ModerationTools.getReportedMessages("MOST", 5)));
	}
	@Test public void manyReportsAreFast() {
		long start = System.nanoTime();
		List<Message> msgs = new ArrayList<>();
		for (int i = 0; i < 20_000; i++) {
			Message m = new Message(UUID.randomUUID(), member.id(), post.id, 100 + i, "spam");
			post.messages.insert(m); msgs.add(m);
		}
		for (Message m : msgs) {
			assertTrue(ModerationTools.addReport(m.id(), member.id(), 1));
			assertTrue(ModerationTools.addReport(m.id(), member2.id(), 2));
			assertTrue(ModerationTools.hasReported(m.id(), member.id()));
			assertTrue(ModerationTools.removeReport(m.id(), member.id(), 3));
		}
		assertTrue("too slow", System.nanoTime() - start < 3_000_000_000L);
	}

	// ----- Task 2 -----
	@Test public void setHiddenRules() {
		assertFalse("member cannot hide", ModerationTools.setHidden(m1.id(), member.id(), true));
		assertFalse("unknown msg", ModerationTools.setHidden(UUID.randomUUID(), admin.id(), true));
		assertFalse("unknown user", ModerationTools.setHidden(m1.id(), UUID.randomUUID(), true));
		assertEquals(3, list(post.getVisibleMessages(false)).size());
		assertTrue(ModerationTools.setHidden(m1.id(), admin.id(), true));
		assertTrue("hiding twice is still fine", ModerationTools.setHidden(m1.id(), admin.id(), true));
		assertEquals(List.of(m2, m3).size(), list(post.getVisibleMessages(false)).size());
		assertFalse(list(post.getVisibleMessages(false)).contains(m1));
		assertEquals(3, list(post.getVisibleMessages(true)).size());
		assertTrue(ModerationTools.setHidden(m1.id(), admin.id(), false));
		assertEquals(list(post.messages), list(post.getVisibleMessages(false)));
	}
	@Test public void newMessagesVisibleByDefaultAndOrderKept() {
		ModerationTools.setHidden(m2.id(), admin.id(), true);
		Message m4 = new Message(UUID.randomUUID(), member.id(), post.id, 20, "d");
		post.messages.insert(m4);
		List<Message> visible = list(post.getVisibleMessages(false));
		assertTrue(visible.contains(m4));
		List<Message> sorted = new ArrayList<>(visible);
		sorted.sort(dao.MessageComparator.getInstance());
		assertEquals(sorted, visible);
	}

	// ----- Task 4 -----
	@Test(expected = IllegalArgumentException.class) public void badStrategy() { ModerationTools.getReportedMessages("NEWEST", 1); }
	@Test(expected = IllegalArgumentException.class) public void lowercaseStrategy() { ModerationTools.getReportedMessages("most", 1); }
	@Test(expected = IllegalArgumentException.class) public void nullStrategy() { ModerationTools.getReportedMessages(null, 1); }
	@Test(expected = IllegalArgumentException.class) public void zeroAmount() { ModerationTools.getReportedMessages("MOST", 0); }
	@Test(expected = IllegalArgumentException.class) public void negativeAmount() { ModerationTools.getReportedMessages("OLDEST", -3); }
	@Test(expected = NoSuchElementException.class) public void nextOnEmpty() { ModerationTools.getReportedMessages("MOST", 3).next(); }

	@Test public void mostOrdering() {
		ModerationTools.addReport(m1.id(), member.id(), 1);
		ModerationTools.addReport(m2.id(), member.id(), 1);
		ModerationTools.addReport(m2.id(), member2.id(), 1);
		ModerationTools.addReport(m3.id(), member.id(), 1);
		ModerationTools.addReport(m3.id(), member2.id(), 1);
		ModerationTools.addReport(m3.id(), member3.id(), 1);
		assertEquals(List.of(m3, m2, m1), list(ModerationTools.getReportedMessages("MOST", 10)));
		assertEquals(List.of(m3, m2), list(ModerationTools.getReportedMessages("MOST", 2)));
		ModerationTools.removeReport(m3.id(), member.id(), 0);
		ModerationTools.removeReport(m3.id(), member2.id(), 0);
		assertEquals(List.of(m2, m1, m3).subList(0, 1), list(ModerationTools.getReportedMessages("MOST", 1)));
	}
	@Test public void oldestOrderingUsesOldestActive() {
		ModerationTools.addReport(m1.id(), member.id(), 100);
		ModerationTools.addReport(m2.id(), member.id(), 50);
		ModerationTools.addReport(m2.id(), member2.id(), 500);
		ModerationTools.addReport(m3.id(), member.id(), 75);
		assertEquals(List.of(m2, m3, m1), list(ModerationTools.getReportedMessages("OLDEST", 10)));
		ModerationTools.removeReport(m2.id(), member.id(), 0); // m2's oldest is now 500
		assertEquals(List.of(m3, m1, m2), list(ModerationTools.getReportedMessages("OLDEST", 10)));
	}
	@Test public void zeroReportsExcludedAndNoDuplicates() {
		ModerationTools.addReport(m1.id(), member.id(), 1);
		ModerationTools.addReport(m1.id(), member2.id(), 2);
		ModerationTools.addReport(m2.id(), member.id(), 3);
		ModerationTools.removeReport(m2.id(), member.id(), 0);
		assertEquals(List.of(m1), list(ModerationTools.getReportedMessages("OLDEST", 10)));
		assertEquals(List.of(m1), list(ModerationTools.getReportedMessages("MOST", 10)));
	}
	@Test public void iteratorsAreIndependent() {
		ModerationTools.addReport(m1.id(), member.id(), 1);
		Iterator<Message> a = ModerationTools.getReportedMessages("MOST", 5);
		Iterator<Message> b = ModerationTools.getReportedMessages("MOST", 5);
		assertEquals(m1, a.next());
		assertTrue(b.hasNext());
		assertTrue(b.hasNext()); // hasNext must not consume
		assertEquals(m1, b.next());
		assertFalse(a.hasNext());
	}
}
