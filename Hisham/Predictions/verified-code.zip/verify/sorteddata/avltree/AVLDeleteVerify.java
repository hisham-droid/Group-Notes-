package sorteddata.avltree;

import org.junit.Test;
import java.lang.reflect.Field;
import java.util.*;
import static org.junit.Assert.*;

public class AVLDeleteVerify {
	// walks the tree checking: BST order, |balance| <= 1, height/size fields correct
	private static <T> int check(AVLNode<T> node, Comparator<T> c, T lo, T hi) {
		if (node instanceof AVLNodeEmpty) return 0;
		AVLNodeFilled<T> n = (AVLNodeFilled<T>) node;
		if (lo != null) assertTrue(c.compare(n.value, lo) > 0);
		if (hi != null) assertTrue(c.compare(n.value, hi) < 0);
		int lh = check(n.left, c, lo, n.value), rh = check(n.right, c, n.value, hi);
		assertTrue("unbalanced at " + n.value, Math.abs(lh - rh) <= 1);
		assertEquals(Math.max(lh, rh) + 1, n.height());
		assertEquals(n.left.size() + n.right.size() + 1, n.size());
		return n.height();
	}
	@SuppressWarnings("unchecked")
	private static AVLNode<Integer> root(AVLTree<Integer> t) throws Exception {
		Field f = AVLTree.class.getDeclaredField("root"); f.setAccessible(true);
		return (AVLNode<Integer>) f.get(t);
	}

	@Test
	public void randomisedAgainstTreeSet() throws Exception {
		Random r = new Random(42);
		for (int round = 0; round < 200; round++) {
			AVLTree<Integer> tree = new AVLTree<Integer>(Comparator.<Integer>naturalOrder());
			TreeSet<Integer> expected = new TreeSet<>();
			for (int op = 0; op < 300; op++) {
				int v = r.nextInt(100);
				if (r.nextBoolean()) assertEquals(expected.add(v), tree.insert(v));
				else assertEquals(expected.remove(v), tree.remove(v));
				check(root(tree), Comparator.naturalOrder(), null, null);
				assertEquals(expected.size(), tree.size());
			}
			List<Integer> got = new ArrayList<>();
			tree.getAll().forEachRemaining(got::add);
			assertEquals(new ArrayList<>(expected), got);
		}
	}

	@Test
	public void deleteIsImmutable() {
		AVLTree<Integer> a = new AVLTree<Integer>(Comparator.<Integer>naturalOrder());
		for (int i = 0; i < 10; i++) a.insert(i);
		AVLTree<Integer> b = a.clone();
		b.remove(5);
		assertNotNull(a.get(5));
		assertNull(b.get(5));
	}

	@Test
	public void largeDeleteIsFast() {
		AVLTree<Integer> t = new AVLTree<Integer>(Comparator.<Integer>naturalOrder());
		long start = System.nanoTime();
		for (int i = 0; i < 200_000; i++) t.insert(i);
		for (int i = 0; i < 200_000; i += 2) t.remove(i);
		assertEquals(100_000, t.size());
		assertTrue("too slow", System.nanoTime() - start < 3_000_000_000L);
	}
}
