import content.ContentTools;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import org.junit.Before;
import org.junit.Test;
import queries.MessageQueries;
import userstate.AdminState;
import userstate.MemberState;

import java.util.*;
import static org.junit.Assert.*;

public class ContentVerify {
	User author, other, admin; Post post; Message m1, m2, m3;

	@Before public void setUp() {
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear();
		author = new User(UUID.randomUUID(), User.Role.Member, "author", "pass");
		other = new User(UUID.randomUUID(), User.Role.Member, "other", "pass");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "admin", "pass");
		for (User u : List.of(author, other, admin)) UserDAO.getInstance().add(u);
		post = new Post(UUID.randomUUID(), author.id(), "t"); PostDAO.getInstance().add(post);
		m1 = new Message(UUID.randomUUID(), author.id(), post.id, 10, "one");
		m2 = new Message(UUID.randomUUID(), other.id(), post.id, 20, "two");
		m3 = new Message(UUID.randomUUID(), author.id(), post.id, 30, "three");
		post.messages.insert(m1); post.messages.insert(m2); post.messages.insert(m3);
	}
	private List<Message> list(Iterator<Message> it) { List<Message> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }
	private List<Message> visible() { return list(post.getVisibleMessages(false).getAll()); }

	@Test public void softDeleteRules() {
		assertFalse("other member cannot delete", ContentTools.deleteMessage(m1.id(), other.id()));
		assertFalse("unknown user", ContentTools.deleteMessage(m1.id(), UUID.randomUUID()));
		assertFalse("unknown message", ContentTools.deleteMessage(UUID.randomUUID(), author.id()));
		assertTrue("author can delete", ContentTools.deleteMessage(m1.id(), author.id()));
		assertEquals(List.of(m2, m3), visible());
		assertEquals(3, list(post.getVisibleMessages(true).getAll()).size());
		assertTrue("admin can delete", ContentTools.deleteMessage(m2.id(), admin.id()));
		assertEquals(List.of(m3), visible());
		assertTrue(ContentTools.restoreMessage(m1.id(), author.id()));
		assertEquals(List.of(m1, m3), visible());
	}
	@Test public void hiddenAndDeletedCombine() {
		post.setHidden(m1, true);
		post.setDeleted(m1, true);
		post.setHidden(m1, false);
		assertFalse("still deleted", visible().contains(m1));
		post.setDeleted(m1, false);
		assertEquals(List.of(m1, m2, m3), visible());
	}
	@Test public void hardDelete() {
		assertFalse("member cannot hard delete", ContentTools.removeMessage(m2.id(), author.id()));
		assertTrue(ContentTools.removeMessage(m2.id(), admin.id()));
		assertEquals(List.of(m1, m3), list(post.messages.getAll()));
		assertEquals(List.of(m1, m3), visible());
		assertFalse("gone now", ContentTools.removeMessage(m2.id(), admin.id()));
		assertEquals(-1, MessageQueries.getPosition(m2.id()));
	}
	@Test public void lockingRulesAndUserState() {
		assertFalse("member cannot lock", ContentTools.setLocked(post.id, author.id(), true));
		assertFalse("unknown post", ContentTools.setLocked(UUID.randomUUID(), admin.id(), true));
		assertNotNull(ContentTools.reply(post.id, other.id(), "before lock", 40));
		assertTrue(ContentTools.setLocked(post.id, admin.id(), true));
		assertNull("member blocked", ContentTools.reply(post.id, other.id(), "after lock", 50));
		assertNotNull("admin allowed", ContentTools.reply(post.id, admin.id(), "admin note", 60));
		assertFalse("MemberState blocked", new MemberState(other).addReply(post, "x"));
		assertTrue("AdminState allowed", new AdminState(admin).addReply(post, "y"));
		assertTrue(ContentTools.setLocked(post.id, admin.id(), false));
		assertTrue(new MemberState(other).addReply(post, "z"));
		assertNull("null text", ContentTools.reply(post.id, other.id(), null, 1));
	}
	@Test public void pinnedFirst() {
		assertFalse("member cannot pin", ContentTools.setPinned(m3.id(), author.id(), true));
		assertTrue(ContentTools.setPinned(m3.id(), admin.id(), true));
		assertTrue(ContentTools.setPinned(m2.id(), admin.id(), true));
		assertEquals(List.of(m2, m3, m1), list(ContentTools.getMessagesPinnedFirst(post.id, false)));
		post.setHidden(m2, true);
		assertEquals("hidden pin not shown to members", List.of(m3, m1), list(ContentTools.getMessagesPinnedFirst(post.id, false)));
		assertEquals(List.of(m2, m3, m1), list(ContentTools.getMessagesPinnedFirst(post.id, true)));
		assertTrue(ContentTools.setPinned(m3.id(), admin.id(), false));
		assertEquals(List.of(m1, m3), list(ContentTools.getMessagesPinnedFirst(post.id, false)));
		assertFalse(ContentTools.getMessagesPinnedFirst(UUID.randomUUID(), true).hasNext());
	}
	@Test public void replaceKeepsFlagsAndOrder() {
		post.setPinned(m2, true); post.setHidden(m2, true);
		Message edited = new Message(m2.id(), m2.poster(), m2.thread(), m2.timestamp(), "two (edited)");
		post.replaceMessage(m2, edited);
		List<Message> all = list(post.messages.getAll());
		assertEquals(3, all.size());
		assertEquals("two (edited)", all.get(1).message());
		assertTrue(post.isPinned(edited));
		assertFalse(visible().contains(edited));
		post.setHidden(edited, false);
		assertEquals("two (edited)", visible().get(1).message());
	}
	@Test public void timeQueriesPositionPages() {
		for (int i = 0; i < 20; i++) post.messages.insert(new Message(UUID.randomUUID(), other.id(), post.id, 100 + i, "m" + i));
		assertEquals(List.of(m1, m2), list(MessageQueries.getMessagesBetween(post.id, 10, 20, true)));
		assertEquals(List.of(m2), list(MessageQueries.getMessagesBetween(post.id, 11, 29, true)));
		assertEquals(2, MessageQueries.countMessagesBetween(post.id, 10, 20, true));
		assertEquals(5, MessageQueries.countMessagesBetween(post.id, 100, 104, true));
		assertEquals(23, MessageQueries.countMessagesBetween(post.id, Long.MIN_VALUE, Long.MAX_VALUE, true));
		assertEquals(0, MessageQueries.countMessagesBetween(post.id, 50, 40, true));
		post.setHidden(m2, true);
		assertEquals(1, MessageQueries.countMessagesBetween(post.id, 10, 20, false));
		assertEquals(0, MessageQueries.getPosition(m1.id()));
		assertEquals(2, MessageQueries.getPosition(m3.id()));
		assertEquals(-1, MessageQueries.getPosition(UUID.randomUUID()));
		assertEquals(List.of(m1, m2, m3), MessageQueries.getPage(post.id, 0, 3, true));
		assertEquals("last page is partial (23 items: indices 21, 22)", 2, MessageQueries.getPage(post.id, 7, 3, true).size());
		assertEquals(List.of(m3), MessageQueries.getPage(post.id, 1, 2, true).subList(0, 1));
		assertTrue(MessageQueries.getPage(post.id, 50, 3, true).isEmpty());
	}
	@Test(expected = IllegalArgumentException.class) public void badPage() { MessageQueries.getPage(post.id, 0, 0, true); }
}
