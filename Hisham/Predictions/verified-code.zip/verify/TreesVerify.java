import org.junit.Test;
import sorteddata.SortedData;
import sorteddata.SortedDataRanges;
import sorteddata.avltree.AVLTree;
import sorteddata.bstree.BSTree;
import sorteddata.redblack.RedBlackTree;
import sorteddata.sortedarraylist.SortedArrayList;

import java.util.*;
import static org.junit.Assert.*;

public class TreesVerify {
	private static final Comparator<Integer> C = Comparator.naturalOrder();
	private static List<Integer> list(Iterator<Integer> it) { List<Integer> l = new ArrayList<>(); it.forEachRemaining(l::add); return l; }

	// expected result of getRange using a TreeSet as the reference
	private static List<Integer> expectedRange(TreeSet<Integer> set, Integer begin, int count, boolean backwards) {
		NavigableSet<Integer> view = begin == null ? (backwards ? set.descendingSet() : set)
				: (backwards ? set.headSet(begin, true).descendingSet() : set.tailSet(begin, true));
		List<Integer> l = new ArrayList<>();
		for (Integer v : view) { if (count >= 0 && l.size() >= count) break; l.add(v); }
		return l;
	}

	@Test public void orderStatisticsAndRangesMatchTreeSet() {
		Random r = new Random(7);
		for (int round = 0; round < 100; round++) {
			TreeSet<Integer> ref = new TreeSet<>();
			List<SortedData<Integer>> all = List.of(new AVLTree<Integer>(C), new SortedArrayList<Integer>(C), new RedBlackTree<Integer>(C), new BSTree<Integer>(C));
			for (int i = 0; i < 80; i++) {
				int v = r.nextInt(200);
				boolean added = ref.add(v);
				for (SortedData<Integer> d : all) assertEquals(added, d.insert(v));
			}
			for (int q = 0; q < 40; q++) {
				int x = r.nextInt(220) - 10;
				for (SortedData<Integer> d : all.subList(0, 3)) { // BSTree has no rank (not required)
					assertEquals(d.getClass().getSimpleName(), ref.headSet(x).size(), d.rank(x));
					assertEquals(ref.floor(x), d.floor(x));
					assertEquals(ref.ceiling(x), d.ceiling(x));
				}
				int count = r.nextInt(12) - 1; boolean back = r.nextBoolean(); Integer begin = r.nextInt(5) == 0 ? null : x;
				List<Integer> exp = expectedRange(ref, begin, count, back);
				for (SortedData<Integer> d : all) {
					assertEquals(d.getClass().getSimpleName() + " begin=" + begin + " count=" + count + " back=" + back,
							exp, list(d.getRange(begin, count, back)));
				}
				int lo = r.nextInt(200), hi = lo + r.nextInt(60);
				List<Integer> between = new ArrayList<>(ref.subSet(lo, true, hi, false));
				for (SortedData<Integer> d : all.subList(0, 3)) {
					assertEquals(between, list(SortedDataRanges.range(d, lo, hi, C)));
					assertEquals(between.size(), SortedDataRanges.count(d, lo, hi));
				}
				for (int i = 0; i < ref.size(); i += 7) assertEquals(new ArrayList<>(ref).get(i), all.get(2).getAtIndex(i));
			}
			assertTrue(((RedBlackTree<Integer>) all.get(2)).isValid());
		}
	}

	@Test public void redBlackStaysValidAndFast() {
		RedBlackTree<Integer> t = new RedBlackTree<>(C);
		long start = System.nanoTime();
		for (int i = 0; i < 500_000; i++) t.insert(i);          // degenerate order: worst case for a plain BST
		assertTrue(System.nanoTime() - start < 3_000_000_000L);
		assertTrue(t.isValid());
		assertEquals(500_000, t.size());
		assertEquals(Integer.valueOf(123_456), t.get(123_456));
		assertNull(t.get(-1));
		assertFalse(t.insert(5));
	}

	@Test public void bstreeRangeOnDegenerateSmallTree() {
		BSTree<Integer> t = new BSTree<>(C);
		for (int i = 0; i < 10; i++) t.insert(i);
		assertEquals(List.of(3, 4, 5), list(t.getRange(3, 3, false)));
		assertEquals(List.of(3, 2, 1, 0), list(t.getRange(3, -1, true)));
		assertEquals(List.of(), list(new BSTree<Integer>(C).getAll()));
	}
}
