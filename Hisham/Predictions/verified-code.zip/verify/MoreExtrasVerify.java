import access.AccessTools;
import dao.PostDAO;
import dao.UserDAO;
import dao.model.Message;
import dao.model.Post;
import dao.model.User;
import login.LoginTools;
import moderation.ModerationTools;
import moderation.ReportStore;
import org.junit.Before;
import org.junit.Test;
import posts.PostTools;
import sorteddata.sortedarraylist.SortedArrayList;
import textformat.TextFormat;
import threads.ThreadTools;

import java.util.*;
import static org.junit.Assert.*;

public class MoreExtrasVerify {
	User a, b, admin; Post p1, p2;

	@Before public void setUp() {
		UserDAO.getInstance().clear(); PostDAO.getInstance().clear(); ReportStore.getInstance().clear();
		ThreadTools.clear(); AccessTools.clear(); LoginTools.clear();
		a = new User(UUID.randomUUID(), User.Role.Member, "alice", "pass1");
		b = new User(UUID.randomUUID(), User.Role.Member, "bobby", "pass2");
		admin = new User(UUID.randomUUID(), User.Role.Admin, "admin", "pass3");
		for (User u : List.of(a, b, admin)) UserDAO.getInstance().add(u);
		p1 = new Post(UUID.randomUUID(), a.id(), "one"); p2 = new Post(UUID.randomUUID(), b.id(), "two");
		PostDAO.getInstance().add(p1); PostDAO.getInstance().add(p2);
	}
	private Message msg(Post p, User u, long t, String text) { Message m = new Message(UUID.randomUUID(), u.id(), p.id, t, text); p.messages.insert(m); return m; }

	@Test public void repliesAndThreads() {
		Message root = msg(p1, a, 1, "root");
		Message r1 = ThreadTools.reply(root.id(), b.id(), "r1", 2);
		Message r2 = ThreadTools.reply(root.id(), a.id(), "r2", 5);
		Message r11 = ThreadTools.reply(r1.id(), a.id(), "r1.1", 3);
		assertNull(ThreadTools.reply(UUID.randomUUID(), a.id(), "x", 1));
		assertNull(ThreadTools.reply(root.id(), UUID.randomUUID(), "x", 1));
		assertEquals(List.of(r1, r2), ThreadTools.getReplies(root.id()));
		assertEquals(List.of("root:0", "r1:1", "r1.1:2", "r2:1"),
				ThreadTools.getThread(root.id()).stream().map(e -> e.message().message() + ":" + e.depth()).toList());
		assertEquals(2, ThreadTools.getDepth(r11.id()));
		assertEquals(root.id(), ThreadTools.getParent(r1.id()));
		assertNull(ThreadTools.getParent(root.id()));
		assertEquals(4, p1.messages.size()); // replies are normal messages in the post
		assertEquals("> root\n\nagreed", ThreadTools.quote(root.id(), "agreed"));
	}
	@Test public void privatePosts() {
		assertTrue(AccessTools.canView(p2.id, null));
		assertFalse("not owner", AccessTools.setPrivate(p2.id, a.id(), true));
		assertTrue(AccessTools.setPrivate(p2.id, b.id(), true));
		assertFalse(AccessTools.canView(p2.id, null));
		assertFalse(AccessTools.canView(p2.id, a.id()));
		assertTrue("owner", AccessTools.canView(p2.id, b.id()));
		assertTrue("admin", AccessTools.canView(p2.id, admin.id()));
		assertTrue(AccessTools.invite(p2.id, b.id(), a.id()));
		assertFalse("twice", AccessTools.invite(p2.id, b.id(), a.id()));
		assertTrue(AccessTools.canView(p2.id, a.id()));
		assertTrue(AccessTools.uninvite(p2.id, b.id(), a.id()));
		assertFalse(AccessTools.canView(p2.id, a.id()));
		assertFalse(AccessTools.canView(UUID.randomUUID(), admin.id()));
	}
	@Test public void loginLockoutAndHistory() {
		assertNull(LoginTools.login("alice", "wrong", 0));
		assertNull(LoginTools.login("alice", "wrong", 1));
		assertNotNull("success resets the count", LoginTools.login("ALICE", "pass1", 2));
		assertNull(LoginTools.login("alice", "x", 3)); assertNull(LoginTools.login("alice", "x", 4)); assertNull(LoginTools.login("alice", "x", 5));
		assertTrue(LoginTools.isLocked(a.id(), 6));
		assertNull("locked even with the right password", LoginTools.login("alice", "pass1", 10));
		assertNotNull("lock expired", LoginTools.login("alice", "pass1", 5 + LoginTools.LOCK_MILLIS));
		assertNull(LoginTools.login("nobody", "x", 0));
		List<LoginTools.LoginAttempt> h = LoginTools.getHistory(a.id());
		assertEquals(5 + LoginTools.LOCK_MILLIS, h.get(0).timestamp());
		assertTrue(h.get(0).success());
		for (int i = 0; i < 20; i++) LoginTools.login("bobby", "pass2", i);
		assertEquals(LoginTools.HISTORY_SIZE, LoginTools.getHistory(b.id()).size());
		LoginTools.login("bobby", "x", 100); LoginTools.login("bobby", "x", 101); LoginTools.login("bobby", "x", 102);
		assertFalse("member cannot unlock", LoginTools.unlock(a.id(), b.id()));
		assertTrue(LoginTools.unlock(admin.id(), b.id()));
		assertNotNull(LoginTools.login("bobby", "pass2", 103));
	}
	@Test public void mergeAndSplit() {
		Message x = msg(p1, a, 1, "x"); Message y = msg(p1, a, 2, "y"); Message z = msg(p2, b, 3, "z");
		ModerationTools.addReport(x.id(), b.id(), 1);
		p1.setHidden(y, true);
		assertFalse("member", PostTools.mergePosts(p1.id, p2.id, a.id()));
		assertFalse("same", PostTools.mergePosts(p1.id, p1.id, admin.id()));
		assertTrue(PostTools.mergePosts(p1.id, p2.id, admin.id()));
		assertNull(PostDAO.getInstance().get(new Post(p1.id)));
		assertEquals(3, p2.messages.size());
		assertTrue("reports follow", ModerationTools.hasReported(x.id(), b.id()));
		assertTrue("hidden follows", p2.isHidden(y.id()));
		UUID split = PostTools.splitPost(y.id(), "split off", admin.id());
		assertNotNull(split);
		Post np = PostDAO.getInstance().get(new Post(split));
		assertEquals(2, np.messages.size()); // y and z (later)
		assertEquals(1, p2.messages.size()); // x stays
		assertTrue(np.isHidden(y.id()));
		assertNull(PostTools.splitPost(x.id(), "t", a.id()));
	}
	@Test public void textFormat() {
		assertEquals("great 😄 :unknown:", TextFormat.replaceEmoji("great :smile: :unknown:"));
		assertEquals("bold and italic code see ANU (https://anu.edu.au)", TextFormat.markdownToPlain("**bold** and *italic* `code` see [ANU](https://anu.edu.au)"));
		assertEquals("hello big...", TextFormat.preview("hello big world", 12));
		assertEquals("short", TextFormat.preview("short", 10));
		assertNull(TextFormat.replaceEmoji(null));
	}
	@Test public void sortedArrayListBounds() {
		SortedArrayList<Integer> l = new SortedArrayList<>(Comparator.<Integer>naturalOrder());
		l.insert(1);
		assertNull(l.getAtIndex(-1)); assertNull(l.getAtIndex(1)); assertEquals(Integer.valueOf(1), l.getAtIndex(0));
	}
}
