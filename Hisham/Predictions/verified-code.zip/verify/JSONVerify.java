import org.junit.Test;
import persistentdata.PersistentDataException;
import persistentdata.formatted.*;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;

public class JSONVerify {
	private List<String[]> roundTrip(List<String[]> rows, int cols) {
		StringWriter out = new StringWriter();
		FormattedWriter<String[]> w = new JSONFormattedFactory(cols).writer(out);
		w.putHeader(); for (String[] r : rows) w.putNext(r); w.putFooter();
		FormattedReader<String[]> r = new JSONFormattedFactory(cols).reader(new StringReader(out.toString()));
		List<String[]> back = new ArrayList<>();
		while (r.hasNext()) back.add(r.getNext());
		return back;
	}
	@Test public void tricky() {
		List<String[]> rows = List.of(new String[]{"a,b", "q\"uote", "back\\slash", "new\nline\ttab", "", "\u0001ctl", "ünïcode ✓"},
				new String[]{"1","2","3","4","5","6","7"});
		List<String[]> back = roundTrip(rows, 7);
		assertEquals(2, back.size());
		for (int i = 0; i < 2; i++) assertArrayEquals(rows.get(i), back.get(i));
	}
	@Test public void emptyDocumentAndEmptyFile() {
		assertTrue(roundTrip(List.of(), 3).isEmpty());
		assertFalse(new JSONFormattedFactory(3).reader(new StringReader("")).hasNext());
	}
	@Test(expected = PersistentDataException.class) public void wrongColumns() {
		new JSONFormattedFactory(2).reader(new StringReader("[[\"a\"]]")).getNext();
	}
	@Test public void hasNextIsIdempotent() {
		FormattedReader<String[]> r = new JSONFormattedFactory(1).reader(new StringReader(" [ [ \"x\" ] , [\"y\"] ] "));
		assertTrue(r.hasNext()); assertTrue(r.hasNext());
		assertArrayEquals(new String[]{"x"}, r.getNext());
		assertTrue(r.hasNext());
		assertArrayEquals(new String[]{"y"}, r.getNext());
		assertFalse(r.hasNext()); assertFalse(r.hasNext());
	}
}
